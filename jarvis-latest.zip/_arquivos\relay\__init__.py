"""Relay remoto genérico do Jarvis."""

from .app import RelaySettings, create_relay_app

__all__ = ["RelaySettings", "create_relay_app"]
