from __future__ import annotations

import uvicorn

from .app import RelaySettings, create_relay_app


def main() -> None:
    settings = RelaySettings.from_environment()
    uvicorn.run(
        create_relay_app(settings),
        host=settings.bind_host,
        port=settings.port,
        reload=False,
    )


if __name__ == "__main__":
    main()
