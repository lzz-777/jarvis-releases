using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

internal static class JarvisProgram
{
    private static Mutex instanceMutex;

    [STAThread]
    private static void Main(string[] args)
    {
        bool startupMode = args != null && Array.Exists(args, delegate(string arg)
        {
            return string.Equals(arg, "--startup", StringComparison.OrdinalIgnoreCase);
        });

        bool createdNew;
        instanceMutex = new Mutex(true, "Local\\JarvisDesktopApp", out createdNew);

        if (!createdNew)
        {
            if (!startupMode)
            {
                JarvisPaths.OpenDashboardStandalone();
            }
            return;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new JarvisApplicationContext(!startupMode));
        GC.KeepAlive(instanceMutex);
    }
}

internal static class JarvisPaths
{
    public static readonly string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
    public static readonly string DashboardExe = Path.Combine(BaseDirectory, "jarvis-dashboard.exe");
    public static readonly string RunPy = Path.Combine(BaseDirectory, "run.py");
    public static readonly string PythonW = Path.Combine(BaseDirectory, ".venv", "Scripts", "pythonw.exe");
    public static readonly string Python = Path.Combine(BaseDirectory, ".venv", "Scripts", "python.exe");
    public static readonly string LogFile = Path.Combine(BaseDirectory, "logs", "agent.log");
    public static readonly string PidFile = Path.Combine(BaseDirectory, "data", "jarvis.pid");
    public static readonly string IconFile = Path.Combine(BaseDirectory, "jarvis.ico");
    public static readonly string UpdaterScript = Path.Combine(BaseDirectory, "atualizar.ps1");

    public static string StartupShortcut
    {
        get
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "Jarvis.lnk");
        }
    }

    public static void OpenDashboardStandalone()
    {
        try
        {
            if (File.Exists(DashboardExe))
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = DashboardExe,
                    WorkingDirectory = BaseDirectory,
                    UseShellExecute = true
                });
            }
        }
        catch
        {
        }
    }
}

internal sealed class UpdateInfo
{
    public string Version;
    public string DownloadUrl;
    public string Sha256;
    public string Notes;
    public bool Available;
}

internal static class UpdateManager
{
    public const string CurrentVersion = "5.11.0";
    public const string ManifestUrl = "https://raw.githubusercontent.com/lzz-777/jarvis-releases/main/version.json";
    private const string AllowedPrefix = "https://raw.githubusercontent.com/lzz-777/jarvis-releases/main/";

    public static UpdateInfo Check()
    {
        ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ManifestUrl);
        request.Method = "GET";
        request.Timeout = 6000;
        request.ReadWriteTimeout = 6000;
        request.UserAgent = "Jarvis-Updater/" + CurrentVersion;

        string body;
        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
        using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
        {
            if (response.StatusCode != HttpStatusCode.OK)
            {
                throw new InvalidOperationException("O servidor de atualizações não respondeu corretamente.");
            }
            body = reader.ReadToEnd();
        }

        JavaScriptSerializer serializer = new JavaScriptSerializer();
        Dictionary<string, object> manifest = serializer.Deserialize<Dictionary<string, object>>(body);
        string versionText = Value(manifest, "version");
        string downloadUrl = Value(manifest, "download_url");
        string sha256 = Value(manifest, "sha256").Trim().ToUpperInvariant();
        string notes = Value(manifest, "notes");

        Version publishedVersion;
        Version installedVersion;
        if (!Version.TryParse(versionText, out publishedVersion) || !Version.TryParse(CurrentVersion, out installedVersion))
        {
            throw new InvalidOperationException("O manifesto contém uma versão inválida.");
        }
        if (!downloadUrl.StartsWith(AllowedPrefix, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("O pacote aponta para uma origem não autorizada.");
        }
        if (!Regex.IsMatch(sha256, "^[0-9A-F]{64}$"))
        {
            throw new InvalidOperationException("O manifesto contém um SHA-256 inválido.");
        }

        UpdateInfo info = new UpdateInfo();
        info.Version = versionText;
        info.DownloadUrl = downloadUrl;
        info.Sha256 = sha256;
        info.Notes = notes;
        info.Available = publishedVersion > installedVersion;
        return info;
    }

    public static void Start(UpdateInfo info)
    {
        if (info == null || !info.Available)
        {
            throw new InvalidOperationException("Nenhuma atualização válida foi selecionada.");
        }
        if (!File.Exists(JarvisPaths.UpdaterScript))
        {
            throw new FileNotFoundException("O atualizador não foi encontrado.", JarvisPaths.UpdaterScript);
        }

        ProcessStartInfo startInfo = new ProcessStartInfo();
        startInfo.FileName = "powershell.exe";
        startInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -File " + Quote(JarvisPaths.UpdaterScript)
            + " -PackageUrl " + Quote(info.DownloadUrl)
            + " -ExpectedVersion " + Quote(info.Version)
            + " -ExpectedSha256 " + Quote(info.Sha256);
        startInfo.WorkingDirectory = JarvisPaths.BaseDirectory;
        startInfo.UseShellExecute = false;
        startInfo.CreateNoWindow = true;
        startInfo.WindowStyle = ProcessWindowStyle.Hidden;
        Process.Start(startInfo);
    }

    private static string Value(Dictionary<string, object> values, string key)
    {
        return values != null && values.ContainsKey(key) && values[key] != null ? Convert.ToString(values[key]) : String.Empty;
    }

    private static string Quote(string value)
    {
        return "\"" + (value ?? String.Empty).Replace("\"", "\\\"") + "\"";
    }
}

internal sealed class JarvisApplicationContext : ApplicationContext
{
    private readonly NotifyIcon trayIcon;
    private readonly ToolStripMenuItem statusItem;
    private readonly ToolStripMenuItem startItem;
    private readonly ToolStripMenuItem stopItem;
    private readonly ToolStripMenuItem autoStartItem;
    private readonly ToolStripMenuItem updateItem;
    private readonly System.Windows.Forms.Timer monitorTimer;
    private readonly AgentManager agentManager;
    private bool lastOnline;
    private bool lastBridgeOnline;
    private bool firstStatus = true;
    private DateTime nextUpdateCheck = DateTime.UtcNow.AddSeconds(12);
    private volatile bool updateCheckRunning;
    private volatile bool completedManualCheck;
    private volatile UpdateInfo completedUpdateCheck;
    private volatile string completedUpdateError;
    private string notifiedUpdateVersion = String.Empty;

    public JarvisApplicationContext(bool openDashboard)
    {
        agentManager = new AgentManager();

        ContextMenuStrip menu = new ContextMenuStrip();

        ToolStripMenuItem openItem = new ToolStripMenuItem("Abrir Jarvis");
        openItem.Font = new Font(openItem.Font, FontStyle.Bold);
        openItem.Click += delegate { OpenDashboard(); };
        menu.Items.Add(openItem);

        statusItem = new ToolStripMenuItem("Status: verificando...");
        statusItem.Enabled = false;
        menu.Items.Add(statusItem);
        menu.Items.Add(new ToolStripSeparator());

        startItem = new ToolStripMenuItem("Iniciar Agent");
        startItem.Click += delegate
        {
            agentManager.AutoRestartEnabled = true;
            agentManager.StartAgent();
            RefreshStatus();
        };
        menu.Items.Add(startItem);

        ToolStripMenuItem restartItem = new ToolStripMenuItem("Reiniciar Agent");
        restartItem.Click += delegate
        {
            agentManager.AutoRestartEnabled = true;
            agentManager.RestartAgent();
            RefreshStatus();
        };
        menu.Items.Add(restartItem);

        stopItem = new ToolStripMenuItem("Parar Agent");
        stopItem.Click += delegate
        {
            agentManager.AutoRestartEnabled = false;
            agentManager.StopAgent();
            RefreshStatus();
        };
        menu.Items.Add(stopItem);

        menu.Items.Add(new ToolStripSeparator());

        ToolStripMenuItem logsItem = new ToolStripMenuItem("Ver logs");
        logsItem.Click += delegate { OpenLogs(); };
        menu.Items.Add(logsItem);

        ToolStripMenuItem folderItem = new ToolStripMenuItem("Abrir pasta do Jarvis");
        folderItem.Click += delegate { OpenFolder(); };
        menu.Items.Add(folderItem);

        updateItem = new ToolStripMenuItem("Verificar atualizações");
        updateItem.Click += delegate
        {
            UpdateInfo available = updateItem.Tag as UpdateInfo;
            if (available != null && available.Available)
            {
                ConfirmAndStartUpdate(available);
            }
            else
            {
                StartUpdateCheck(true);
            }
        };
        menu.Items.Add(updateItem);

        autoStartItem = new ToolStripMenuItem("Iniciar com o Windows");
        autoStartItem.CheckOnClick = true;
        autoStartItem.Checked = StartupManager.IsEnabled();
        autoStartItem.Click += delegate
        {
            try
            {
                if (autoStartItem.Checked)
                {
                    StartupManager.Enable();
                }
                else
                {
                    StartupManager.Disable();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível alterar a inicialização automática.\n\n" + ex.Message,
                    "Jarvis", MessageBoxButtons.OK, MessageBoxIcon.Error);
                autoStartItem.Checked = StartupManager.IsEnabled();
            }
        };
        menu.Items.Add(autoStartItem);

        menu.Items.Add(new ToolStripSeparator());

        ToolStripMenuItem exitItem = new ToolStripMenuItem("Sair");
        exitItem.Click += delegate { ExitTray(); };
        menu.Items.Add(exitItem);

        Icon icon = SystemIcons.Application;
        try
        {
            if (File.Exists(JarvisPaths.IconFile))
            {
                icon = new Icon(JarvisPaths.IconFile);
            }
        }
        catch
        {
            icon = SystemIcons.Application;
        }

        trayIcon = new NotifyIcon();
        trayIcon.Icon = icon;
        trayIcon.Text = "Jarvis - iniciando...";
        trayIcon.Visible = true;
        trayIcon.ContextMenuStrip = menu;
        trayIcon.DoubleClick += delegate { OpenDashboard(); };
        trayIcon.BalloonTipClicked += delegate
        {
            UpdateInfo available = updateItem.Tag as UpdateInfo;
            if (available != null && available.Available)
            {
                ConfirmAndStartUpdate(available);
            }
        };

        agentManager.AutoRestartEnabled = true;
        if (agentManager.IsAgentOnline() && !agentManager.IsAgentCompatible())
        {
            agentManager.StopAgent();
            Thread.Sleep(400);
        }
        if (!agentManager.IsAgentOnline())
        {
            agentManager.StartAgent();
        }

        monitorTimer = new System.Windows.Forms.Timer();
        monitorTimer.Interval = 5000;
        monitorTimer.Tick += delegate
        {
            bool online = agentManager.IsAgentOnline();
            bool bridgeOnline = online && agentManager.IsBridgeListening();
            agentManager.RecoverIfNeeded(online, bridgeOnline);
            RefreshStatus(online, bridgeOnline);
            ConsumeUpdateCheck();
            if (DateTime.UtcNow >= nextUpdateCheck)
            {
                StartUpdateCheck(false);
            }
        };
        monitorTimer.Start();

        RefreshStatus();

        if (openDashboard)
        {
            OpenDashboard();
        }
    }

    private void StartUpdateCheck(bool manual)
    {
        if (updateCheckRunning)
        {
            return;
        }
        updateCheckRunning = true;
        completedManualCheck = manual;
        completedUpdateCheck = null;
        completedUpdateError = null;
        nextUpdateCheck = DateTime.UtcNow.AddHours(6);
        updateItem.Enabled = false;
        updateItem.Text = "Verificando atualizações...";

        ThreadPool.QueueUserWorkItem(delegate
        {
            try
            {
                completedUpdateCheck = UpdateManager.Check();
            }
            catch (Exception exception)
            {
                completedUpdateError = exception.Message;
            }
            finally
            {
                updateCheckRunning = false;
            }
        });
    }

    private void ConsumeUpdateCheck()
    {
        if (updateCheckRunning)
        {
            return;
        }

        UpdateInfo result = completedUpdateCheck;
        string error = completedUpdateError;
        if (result == null && error == null)
        {
            return;
        }
        bool manual = completedManualCheck;
        completedUpdateCheck = null;
        completedUpdateError = null;
        updateItem.Enabled = true;

        if (error != null)
        {
            updateItem.Text = "Verificar atualizações";
            updateItem.Tag = null;
            if (manual)
            {
                MessageBox.Show("Não foi possível verificar atualizações.\n\n" + error, "Jarvis - Atualizações", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return;
        }

        if (result.Available)
        {
            updateItem.Text = "Atualizar para " + result.Version;
            updateItem.Tag = result;
            if (manual)
            {
                ConfirmAndStartUpdate(result);
            }
            else if (!String.Equals(notifiedUpdateVersion, result.Version, StringComparison.OrdinalIgnoreCase))
            {
                notifiedUpdateVersion = result.Version;
                trayIcon.BalloonTipTitle = "Nova versão do Jarvis disponível";
                trayIcon.BalloonTipText = "Versão " + result.Version + ". Clique aqui ou use o menu da bandeja para atualizar.";
                trayIcon.BalloonTipIcon = ToolTipIcon.Info;
                trayIcon.ShowBalloonTip(5000);
            }
        }
        else
        {
            updateItem.Text = "Verificar atualizações";
            updateItem.Tag = null;
            if (manual)
            {
                MessageBox.Show("O Jarvis já está atualizado.\n\nVersão instalada: " + UpdateManager.CurrentVersion, "Jarvis - Atualizações", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }

    private void ConfirmAndStartUpdate(UpdateInfo info)
    {
        string details = String.IsNullOrWhiteSpace(info.Notes) ? String.Empty : "\n\n" + info.Notes;
        if (MessageBox.Show("Atualizar o Jarvis para a versão " + info.Version + " agora?\n\nO aplicativo será reiniciado e seus dados locais serão preservados." + details,
            "Jarvis - Nova versão", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
        {
            return;
        }
        try
        {
            UpdateManager.Start(info);
            agentManager.AutoRestartEnabled = false;
            ExitTray();
        }
        catch (Exception exception)
        {
            MessageBox.Show("Não foi possível iniciar a atualização.\n\n" + exception.Message, "Jarvis - Atualizações", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void RefreshStatus()
    {
        bool online = agentManager.IsAgentOnline();
        bool bridgeOnline = online && agentManager.IsBridgeListening();
        RefreshStatus(online, bridgeOnline);
    }

    private void RefreshStatus(bool online, bool bridgeOnline)
    {

        statusItem.Text = online
            ? (bridgeOnline ? "Status: Online | Bridge ativa" : "Status: Online | Bridge indisponível")
            : "Status: Offline";

        startItem.Enabled = !online;
        stopItem.Enabled = online;

        string tooltip = online
            ? (bridgeOnline ? "Jarvis - Online | Bridge ativa" : "Jarvis - Online | Bridge offline")
            : "Jarvis - Offline";

        if (tooltip.Length > 63)
        {
            tooltip = tooltip.Substring(0, 63);
        }
        trayIcon.Text = tooltip;

        if (!firstStatus && (lastOnline != online || lastBridgeOnline != bridgeOnline))
        {
            if (online)
            {
                trayIcon.BalloonTipTitle = "Jarvis online";
                trayIcon.BalloonTipText = bridgeOnline ? "Agent e Bridge estão prontos." : "Agent está pronto; Bridge ainda não respondeu.";
                trayIcon.BalloonTipIcon = ToolTipIcon.Info;
                trayIcon.ShowBalloonTip(1800);
            }
            else
            {
                trayIcon.BalloonTipTitle = "Jarvis offline";
                trayIcon.BalloonTipText = agentManager.AutoRestartEnabled
                    ? "O Agent caiu. Vou tentar iniciá-lo novamente."
                    : "O Agent foi parado.";
                trayIcon.BalloonTipIcon = ToolTipIcon.Warning;
                trayIcon.ShowBalloonTip(1800);
            }
        }

        lastOnline = online;
        lastBridgeOnline = bridgeOnline;
        firstStatus = false;
    }

    private void OpenDashboard()
    {
        try
        {
            agentManager.AutoRestartEnabled = true;
            if (!agentManager.IsAgentOnline())
            {
                agentManager.StartAgent();
                DateTime deadline = DateTime.UtcNow.AddSeconds(12);
                while (DateTime.UtcNow < deadline && !agentManager.IsAgentOnline())
                {
                    Application.DoEvents();
                    Thread.Sleep(250);
                }
            }

            if (!File.Exists(JarvisPaths.DashboardExe))
            {
                MessageBox.Show("jarvis-dashboard.exe não foi encontrado na pasta do Jarvis.",
                    "Jarvis", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Process.Start(new ProcessStartInfo
            {
                FileName = JarvisPaths.DashboardExe,
                WorkingDirectory = JarvisPaths.BaseDirectory,
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show("Não foi possível abrir o Dashboard.\n\n" + ex.Message,
                "Jarvis", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static void OpenLogs()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(JarvisPaths.LogFile));
            if (!File.Exists(JarvisPaths.LogFile))
            {
                File.WriteAllText(JarvisPaths.LogFile, "");
            }
            Process.Start(new ProcessStartInfo
            {
                FileName = "notepad.exe",
                Arguments = "\"" + JarvisPaths.LogFile + "\"",
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show("Não foi possível abrir os logs.\n\n" + ex.Message,
                "Jarvis", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static void OpenFolder()
    {
        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = "\"" + JarvisPaths.BaseDirectory + "\"",
                UseShellExecute = true
            });
        }
        catch
        {
        }
    }

    private void ExitTray()
    {
        monitorTimer.Stop();
        trayIcon.Visible = false;
        trayIcon.Dispose();
        ExitThread();
    }
}

internal sealed class AgentManager
{
    private const string ExpectedAgentVersion = "0.10.2";
    private DateTime nextRestartAttempt = DateTime.MinValue;
    private Process launchedProcess;
    private int bridgeFailureChecks;

    private static int GetEnvPort(string key, int fallback)
    {
        try
        {
            string envPath = Path.Combine(JarvisPaths.BaseDirectory, ".env");
            if (File.Exists(envPath))
            {
                string[] lines = File.ReadAllLines(envPath);
                foreach (string line in lines)
                {
                    string trimmed = line.Trim();
                    if (trimmed.StartsWith(key + "=", StringComparison.OrdinalIgnoreCase))
                    {
                        string val = trimmed.Substring(key.Length + 1).Trim();
                        int port;
                        if (int.TryParse(val, out port) && port > 0 && port <= 65535)
                        {
                            return port;
                        }
                    }
                }
            }
        }
        catch { }
        return fallback;
    }

    private static string HealthUrl
    {
        get { return "http://127.0.0.1:" + GetEnvPort("JARVIS_PORT", 9520) + "/api/v1/health"; }
    }

    public bool AutoRestartEnabled { get; set; }

    public bool IsAgentOnline()
    {
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(HealthUrl);
            request.Method = "GET";
            request.Timeout = 700;
            request.ReadWriteTimeout = 700;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                return response.StatusCode == HttpStatusCode.OK;
            }
        }
        catch
        {
            return false;
        }
    }

    public bool IsAgentCompatible()
    {
        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(HealthUrl);
            request.Method = "GET";
            request.Timeout = 900;
            request.ReadWriteTimeout = 900;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                string body = reader.ReadToEnd();
                return response.StatusCode == HttpStatusCode.OK &&
                    body.IndexOf("\"agent_version\":\"" + ExpectedAgentVersion + "\"", StringComparison.OrdinalIgnoreCase) >= 0;
            }
        }
        catch
        {
            return false;
        }
    }

    public bool IsBridgeListening()
    {
        TcpClient client = null;
        try
        {
            int bridgePort = GetEnvPort("JARVIS_BRIDGE_PORT", 9521);
            client = new TcpClient();
            IAsyncResult result = client.BeginConnect(IPAddress.Loopback, bridgePort, null, null);
            bool connected = result.AsyncWaitHandle.WaitOne(350);
            if (!connected)
            {
                return false;
            }
            client.EndConnect(result);
            return client.Connected;
        }
        catch
        {
            return false;
        }
        finally
        {
            if (client != null)
            {
                client.Close();
            }
        }
    }

    public void StartAgentIfDue()
    {
        if (DateTime.UtcNow < nextRestartAttempt)
        {
            return;
        }
        StartAgent();
    }

    public void RecoverIfNeeded(bool online, bool bridgeOnline)
    {
        if (!AutoRestartEnabled)
        {
            bridgeFailureChecks = 0;
            return;
        }
        if (!online)
        {
            bridgeFailureChecks = 0;
            StartAgentIfDue();
            return;
        }
        if (bridgeOnline)
        {
            bridgeFailureChecks = 0;
            return;
        }
        bridgeFailureChecks++;
        if (bridgeFailureChecks >= 4 && DateTime.UtcNow >= nextRestartAttempt)
        {
            bridgeFailureChecks = 0;
            RestartAgent();
        }
    }

    public void StartAgent()
    {
        if (IsAgentOnline())
        {
            return;
        }

        nextRestartAttempt = DateTime.UtcNow.AddSeconds(8);

        string pythonPath = File.Exists(JarvisPaths.PythonW) ? JarvisPaths.PythonW : JarvisPaths.Python;
        if (!File.Exists(pythonPath) || !File.Exists(JarvisPaths.RunPy))
        {
            return;
        }

        try
        {
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = pythonPath;
            info.Arguments = "\"" + JarvisPaths.RunPy + "\"";
            info.WorkingDirectory = JarvisPaths.BaseDirectory;
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.WindowStyle = ProcessWindowStyle.Hidden;
            launchedProcess = Process.Start(info);
        }
        catch
        {
        }
    }

    public void StopAgent()
    {
        int pid = ReadPid();
        if (pid <= 0 && launchedProcess != null)
        {
            try { pid = launchedProcess.Id; } catch { pid = 0; }
        }
        if (pid <= 0)
        {
            pid = FindListeningPid(GetEnvPort("JARVIS_PORT", 9520));
        }

        if (pid > 0)
        {
            try
            {
                Process process = Process.GetProcessById(pid);
                process.Kill();
                process.WaitForExit(5000);
            }
            catch
            {
            }
        }

        TryDeletePidFile();
        nextRestartAttempt = DateTime.UtcNow.AddSeconds(2);
    }

    public void RestartAgent()
    {
        StopAgent();
        Thread.Sleep(500);
        StartAgent();
    }

    private static int ReadPid()
    {
        try
        {
            if (!File.Exists(JarvisPaths.PidFile))
            {
                return 0;
            }
            int pid;
            if (int.TryParse(File.ReadAllText(JarvisPaths.PidFile).Trim(), out pid))
            {
                try
                {
                    Process.GetProcessById(pid);
                    return pid;
                }
                catch
                {
                    TryDeletePidFile();
                }
            }
        }
        catch
        {
        }
        return 0;
    }

    private static int FindListeningPid(int port)
    {
        try
        {
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = "netstat.exe";
            info.Arguments = "-ano -p tcp";
            info.UseShellExecute = false;
            info.RedirectStandardOutput = true;
            info.CreateNoWindow = true;
            Process process = Process.Start(info);
            string output = process.StandardOutput.ReadToEnd();
            process.WaitForExit(3000);

            string pattern = @"^\s*TCP\s+\S+:" + port + @"\s+\S+\s+LISTENING\s+(\d+)\s*$";
            Match match = Regex.Match(output, pattern, RegexOptions.Multiline | RegexOptions.IgnoreCase);
            int pid;
            if (match.Success && int.TryParse(match.Groups[1].Value, out pid))
            {
                return pid;
            }
        }
        catch
        {
        }
        return 0;
    }

    private static void TryDeletePidFile()
    {
        try
        {
            if (File.Exists(JarvisPaths.PidFile))
            {
                File.Delete(JarvisPaths.PidFile);
            }
        }
        catch
        {
        }
    }
}

internal static class StartupManager
{
    public static bool IsEnabled()
    {
        return File.Exists(JarvisPaths.StartupShortcut);
    }

    public static void Enable()
    {
        string exePath = Process.GetCurrentProcess().MainModule.FileName;
        Type shellType = Type.GetTypeFromProgID("WScript.Shell");
        if (shellType == null)
        {
            throw new InvalidOperationException("Windows Script Host não está disponível.");
        }

        dynamic shell = Activator.CreateInstance(shellType);
        dynamic shortcut = shell.CreateShortcut(JarvisPaths.StartupShortcut);
        shortcut.TargetPath = exePath;
        shortcut.Arguments = "--startup";
        shortcut.WorkingDirectory = JarvisPaths.BaseDirectory;
        shortcut.IconLocation = exePath + ",0";
        shortcut.Description = "Jarvis";
        shortcut.Save();
    }

    public static void Disable()
    {
        if (File.Exists(JarvisPaths.StartupShortcut))
        {
            File.Delete(JarvisPaths.StartupShortcut);
        }
    }
}
