from __future__ import annotations

import base64
import hashlib
import hmac
import io
import ipaddress
import json
import os
import re
import secrets
import socket
import subprocess
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlparse

import httpx
from fastapi import Depends, FastAPI, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from .actions import ActionError, ActionRegistry, ProcessManager
from .config import PROJECT_DIR, Settings
from .database import Database
from .engine import ExecutionEngine


APP_VERSION = "5.10.2"
AGENT_VERSION = "0.10.2"


class ActionRequest(BaseModel):
    action: str = Field(min_length=1, max_length=64)
    parameters: dict[str, Any] = Field(default_factory=dict)
    request_id: str | None = Field(default=None, max_length=100)


class RunRequest(BaseModel):
    request_id: str | None = Field(default=None, max_length=100)


class DashboardApplicationPayload(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    identifier: str = Field(min_length=1, max_length=64)
    executable_path: str = Field(min_length=5, max_length=1024)
    process_name: str = Field(min_length=1, max_length=260)
    arguments: list[str] = Field(default_factory=list)
    enabled: bool = True
    close_policy: str = Field(default="safe", pattern="^(safe|force|never)$")


class DashboardModePayload(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    slug: str = Field(default="", max_length=64)
    enabled: bool = True
    applications: list[str] = Field(default_factory=list, max_length=20)
    close_applications: list[str] = Field(default_factory=list, max_length=20)


class DashboardClosePayload(BaseModel):
    force: bool = False


class DashboardBridgeDevicePayload(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    ip_address: str = Field(default="", max_length=64)
    additional_ip_addresses: list[str] = Field(default_factory=list, max_length=10)
    auto_update_ip: bool = True
    source_policy: str = Field(default="ip", pattern="^(ip|token)$")
    enabled: bool = True
    token: str = Field(default="", max_length=256)


class DashboardNetworkPayload(BaseModel):
    port: int = Field(ge=1024, le=65535)
    bridge_port: int = Field(ge=1024, le=65535)
    allow_sensitive_actions: bool = False
    remote_access_enabled: bool = False
    remote_access_url: str = Field(default="", max_length=256)
    remote_access_type: str = Field(default="custom", max_length=32)


class DashboardRemoteTestPayload(BaseModel):
    url: str = Field(min_length=1, max_length=256)


class DashboardRelayBootstrapPayload(BaseModel):
    name: str = Field(default="Relay remoto", min_length=1, max_length=120)


class DashboardQrPayload(BaseModel):
    token: str = Field(min_length=16, max_length=256)


class DashboardBackupStepPayload(BaseModel):
    action_type: str = Field(min_length=1, max_length=64)
    parameters: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True
    timeout_seconds: int = Field(default=30, ge=1, le=3600)
    on_error: str = Field(default="stop", max_length=16)


class DashboardBackupModePayload(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    slug: str = Field(min_length=1, max_length=64)
    enabled: bool = True
    steps: list[DashboardBackupStepPayload] = Field(default_factory=list, max_length=500)


class DashboardBackupPayload(BaseModel):
    format: str = Field(min_length=1, max_length=40)
    version: int
    applications: list[DashboardApplicationPayload] = Field(default_factory=list, max_length=500)
    modes: list[DashboardBackupModePayload] = Field(default_factory=list, max_length=500)


def get_local_lan_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def set_env_value(key: str, value: str) -> None:
    env_path = PROJECT_DIR / ".env"
    content = env_path.read_text(encoding="utf-8") if env_path.exists() else ""
    pattern = rf"(?m)^{re.escape(key)}=.*$"
    line = f"{key}={value}"
    if re.search(pattern, content):
        content = re.sub(pattern, line, content)
    else:
        if content and not content.endswith("\n"):
            content += "\n"
        content += f"{line}\n"
    env_path.write_text(content, encoding="utf-8")


def slugify(value: str) -> str:
    normalized = "".join(character.lower() if character.isalnum() else "-" for character in value.strip())
    return "-".join(part for part in normalized.split("-") if part)[:64]


def validate_remote_access_url(value: str) -> str:
    url_value = (value or "").strip()
    if not url_value:
        return ""
    try:
        parsed = urlparse(url_value)
    except Exception as error:
        raise ValueError("URL de acesso remoto inválida.") from error
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("A URL de acesso remoto deve começar com http:// ou https:// e conter um host válido.")
    return url_value.rstrip("/")


def bridge_token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def validate_bridge_ip(value: str, allow_blank: bool) -> str:
    ip_value = value.strip()
    if not ip_value and allow_blank:
        return ""
    try:
        ip = ipaddress.ip_address(ip_value)
    except ValueError as error:
        raise ValueError("Informe um endereco IPv4/IPv6 valido.") from error
    if ip.is_loopback or ip.is_multicast or ip.is_unspecified:
        raise ValueError("Use um endereço unicast válido da rede local ou privada.")
    return str(ip)


def build_step_parameters(action_type: str, application: str, url: str, seconds: str, timeout_seconds: int) -> dict[str, Any]:
    if action_type in {"open_application", "close_application", "wait_process_start", "wait_process_exit", "check_process"}:
        if not application:
            raise ValueError("Selecione um aplicativo para esta ação.")
        parameters = {"application": application}
        if action_type.startswith("wait_process"):
            parameters["timeout_seconds"] = timeout_seconds
        return parameters
    if action_type == "open_url":
        if not url:
            raise ValueError("Informe uma URL.")
        return {"url": url}
    if action_type == "wait":
        try:
            value = float(seconds)
        except ValueError as error:
            raise ValueError("Informe um tempo de espera válido.") from error
        return {"seconds": value}
    return {}


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings.from_environment()
    database = Database(settings.database_path)
    registry = ActionRegistry(database, settings)
    engine = ExecutionEngine(database, registry)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        database.migrate()
        yield

    app = FastAPI(title="Jarvis Agent", version=AGENT_VERSION, lifespan=lifespan)
    app.state.settings = settings
    app.state.database = database
    app.state.registry = registry
    app.state.engine = engine
    app.state.started_at = time.monotonic()
    templates = Jinja2Templates(directory=str(PROJECT_DIR / "app" / "templates"))
    app.mount("/static", StaticFiles(directory=str(PROJECT_DIR / "app" / "static")), name="static")
    bearer = HTTPBearer(auto_error=False)

    def api_auth(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)) -> None:
        supplied = credentials.credentials if credentials and credentials.scheme.lower() == "bearer" else ""
        if not settings.api_token or not supplied or not hmac.compare_digest(supplied, settings.api_token):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token da API inválido.")

    def render(request: Request, template: str, **context: Any) -> HTMLResponse:
        return templates.TemplateResponse(request, template, {"settings": settings, "current_mode": engine.current_mode, **context})

    def local_dashboard_only(request: Request) -> None:
        client_host = request.client.host if request.client else ""
        if client_host not in {"127.0.0.1", "::1", "testclient"}:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="O Dashboard local aceita somente conexões do próprio PC.")

    def legacy_dashboard_only(request: Request) -> None:
        local_dashboard_only(request)
        if not settings.legacy_web_dashboard:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="O painel web legado está desativado. Use o Jarvis Dashboard nativo.")

    def save_dashboard_application(payload: DashboardApplicationPayload, application_id: int | None = None) -> dict[str, Any]:
        identifier = slugify(payload.identifier)
        executable_path = Path(payload.executable_path.strip())
        if not identifier or executable_path.suffix.casefold() != ".exe":
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Informe um identificador e um arquivo .exe válido.")
        if application_id is not None:
            current = database.get_application_by_id(application_id)
            if current and current["identifier"] != identifier:
                references = database.application_references(current["identifier"])
                if references:
                    modes = ", ".join(sorted({reference["mode_name"] for reference in references}))
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=f"Este aplicativo é usado pelos modos: {modes}. Remova ou altere essas etapas antes de trocar o identificador.",
                    )
        try:
            saved_id = database.save_application(
                {
                    "name": payload.name.strip(),
                    "identifier": identifier,
                    "executable_path": str(executable_path),
                    "process_name": payload.process_name.strip(),
                    "arguments": [argument.strip() for argument in payload.arguments if argument.strip()],
                    "enabled": payload.enabled,
                    "close_policy": payload.close_policy,
                },
                application_id,
            )
        except Exception as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Já existe um aplicativo com esse identificador.") from error
        application = database.get_application_by_id(saved_id)
        if not application:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Não foi possível salvar o aplicativo.")
        return application

    def save_dashboard_bridge_device(payload: DashboardBridgeDevicePayload, device_id: int | None = None) -> dict[str, Any]:
        auto_update = bool(payload.auto_update_ip)
        source_policy = payload.source_policy if payload.source_policy in {"ip", "token"} else "ip"
        try:
            configured_ip = validate_bridge_ip(payload.ip_address, allow_blank=(auto_update or source_policy == "token"))
            additional_ips: list[str] = []
            for value in payload.additional_ip_addresses:
                validated = validate_bridge_ip(value, allow_blank=False)
                if validated != configured_ip and validated not in additional_ips:
                    additional_ips.append(validated)
        except ValueError as error:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(error)) from error

        current = database.get_bridge_device_by_id(device_id) if device_id is not None else None
        if device_id is not None and not current:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dispositivo nao encontrado.")

        issued_token: str | None = None
        supplied_token = payload.token.strip()
        if device_id is None:
            issued_token = supplied_token or secrets.token_hex(32)
        elif supplied_token:
            issued_token = supplied_token

        token_hash = bridge_token_hash(issued_token) if issued_token else None
        token_hint = issued_token[-6:] if issued_token else None
        try:
            saved_id = database.save_bridge_device(
                payload.name.strip(),
                configured_ip,
                additional_ips,
                auto_update,
                payload.enabled,
                source_policy,
                token_hash=token_hash,
                token_hint=token_hint,
                device_id=device_id,
            )
        except Exception as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Nao foi possivel salvar o dispositivo. O token pode ja estar em uso.") from error

        device = database.get_bridge_device_by_id(saved_id)
        if not device:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Nao foi possivel salvar o dispositivo.")
        if issued_token:
            device["issued_token"] = issued_token
        return device

    def native_mode_is_simple(steps: list[dict[str, Any]]) -> bool:
        return all(
            step["action_type"] in {"open_application", "close_application"}
            and bool(step["enabled"])
            and int(step["timeout_seconds"]) == 30
            and step["on_error"] == "stop"
            and set(step["parameters"].keys()) == {"application"}
            for step in steps
        )

    def native_mode_response(mode: dict[str, Any]) -> dict[str, Any]:
        steps = database.list_steps(mode["id"])
        return {
            **mode,
            "applications": [
                step["parameters"].get("application", "")
                for step in steps
                if step["action_type"] == "open_application" and step["enabled"]
            ],
            "close_applications": [
                step["parameters"].get("application", "")
                for step in steps
                if step["action_type"] == "close_application" and step["enabled"]
            ],
            "step_count": len(steps),
            "native_editable": native_mode_is_simple(steps),
        }

    def mode_api_response(mode: dict[str, Any]) -> dict[str, Any]:
        steps = database.list_steps(mode["id"])
        risks: list[str] = []
        unknown_actions: list[str] = []
        for step in steps:
            if not step["enabled"]:
                continue
            definition = registry.actions.get(step["action_type"])
            if definition is None:
                unknown_actions.append(step["action_type"])
            else:
                risks.append(definition.risk)
        risk_order = {"SAFE": 0, "SENSITIVE": 1, "DANGEROUS": 2}
        max_risk = max(risks, key=lambda value: risk_order.get(value, 99)) if risks else "SAFE"
        return {
            "id": mode["id"],
            "name": mode["name"],
            "slug": mode["slug"],
            "enabled": bool(mode["enabled"]),
            "step_count": len(steps),
            "max_risk": max_risk,
            "valid": not unknown_actions,
        }

    def history_source_label(source: str) -> str:
        if source.startswith("bridge:"):
            parts = source.split(":", 2)
            device_name = parts[1] if len(parts) > 1 and parts[1] else "Celular"
            client_ip = parts[2] if len(parts) > 2 else ""
            return f"Celular - {device_name} ({client_ip})" if client_ip else f"Celular - {device_name}"
        if source == "native_dashboard":
            return "Dashboard"
        if source == "api":
            return "API local"
        return source or "Desconhecida"

    def history_details(row: dict[str, Any]) -> str:
        if row.get("error_message"):
            return str(row["error_message"])
        try:
            details = json.loads(row.get("details_json") or "{}")
        except (TypeError, json.JSONDecodeError):
            details = {}
        if row.get("target_type") == "action":
            action_result = details.get("result") if isinstance(details, dict) else None
            if isinstance(action_result, dict) and action_result.get("message"):
                return str(action_result["message"])
        if row.get("success") is None:
            return "Em andamento."
        return "Executado com sucesso." if bool(row.get("success")) else "Falha na execucao."

    def save_dashboard_mode(payload: DashboardModePayload, mode_id: int | None = None) -> dict[str, Any]:
        slug = slugify(payload.slug or payload.name)
        application_ids = list(dict.fromkeys(slugify(identifier) for identifier in payload.applications if identifier.strip()))
        close_application_ids = list(dict.fromkeys(slugify(identifier) for identifier in payload.close_applications if identifier.strip()))
        if not slug:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Informe um identificador válido para o modo.")
        if not application_ids and not close_application_ids:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Selecione pelo menos um aplicativo para abrir ou fechar.")
        if set(application_ids) & set(close_application_ids):
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="O mesmo aplicativo não pode abrir e fechar no mesmo modo.")
        if mode_id is not None:
            existing_steps = database.list_steps(mode_id)
            if not native_mode_is_simple(existing_steps):
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Este modo possui etapas avançadas. A edição simplificada foi bloqueada para não apagar configurações. Edite-o pelo editor avançado/local.",
                )

        applications = {application["identifier"]: application for application in database.list_applications()}
        selected_ids = list(dict.fromkeys(close_application_ids + application_ids))
        missing = [identifier for identifier in selected_ids if identifier not in applications]
        disabled = [identifier for identifier in selected_ids if identifier in applications and not applications[identifier]["enabled"]]
        if missing:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Um dos aplicativos selecionados não está mais cadastrado.")
        if disabled:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Ative os aplicativos selecionados antes de adicioná-los ao modo.")

        try:
            saved_id = database.save_mode(payload.name.strip(), slug, payload.enabled, mode_id)
        except Exception as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Já existe um modo com esse identificador.") from error

        database.replace_mode_steps(
            saved_id,
            [
                {
                    "action_type": "close_application",
                    "parameters": {"application": identifier},
                    "timeout_seconds": 30,
                    "on_error": "stop",
                    "enabled": True,
                }
                for identifier in close_application_ids
            ]
            + [
                {
                    "action_type": "open_application",
                    "parameters": {"application": identifier},
                    "timeout_seconds": 30,
                    "on_error": "stop",
                    "enabled": True,
                }
                for identifier in application_ids
            ],
        )
        mode = database.get_mode_by_id(saved_id)
        if not mode:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Não foi possível salvar o modo.")
        return native_mode_response(mode)

    @app.get("/api/v1/health")
    async def health() -> dict[str, str]:
        return {"status": "ok", "agent_version": AGENT_VERSION, "app_version": APP_VERSION}

    @app.get("/api/v1/status", dependencies=[Depends(api_auth)])
    async def api_status() -> dict[str, Any]:
        return {"hostname": socket.gethostname(), "instance_name": settings.instance_name, "bridge_port": settings.bridge_port, "platform": os.name, "agent_version": AGENT_VERSION, "app_version": APP_VERSION, "uptime": int(time.monotonic() - app.state.started_at), "current_mode": engine.current_mode, "dev_mode": settings.dev_mode}

    @app.get("/api/v1/actions", dependencies=[Depends(api_auth)])
    async def api_actions() -> list[dict[str, str]]:
        return registry.describe()

    @app.get("/api/v1/modes", dependencies=[Depends(api_auth)])
    async def api_modes() -> list[dict[str, Any]]:
        return [mode_api_response(mode) for mode in database.list_modes()]

    @app.post("/api/v1/action", dependencies=[Depends(api_auth)])
    async def api_action(request: Request, payload: ActionRequest) -> dict[str, Any]:
        source = "api"
        forwarded_source = request.headers.get("X-Jarvis-Source", "").strip()
        client_host = request.client.host if request.client else ""
        if client_host in {"127.0.0.1", "::1", "testclient"} and forwarded_source.startswith("bridge:"):
            source = forwarded_source[:120]
        result = await engine.run_action(payload.action, payload.parameters, source, payload.request_id)
        if not result["success"]:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=result["error"])
        return result

    @app.get("/api/v1/applications/active", dependencies=[Depends(api_auth)])
    async def api_active_applications() -> list[dict[str, Any]]:
        return registry.active_applications()

    @app.post("/api/v1/modes/{mode_slug}/run", dependencies=[Depends(api_auth)])
    async def api_run_mode(request: Request, mode_slug: str, payload: RunRequest) -> dict[str, Any]:
        source = "api"
        client_host = request.client.host if request.client else ""
        forwarded_source = request.headers.get("X-Jarvis-Source", "").strip()
        if client_host in {"127.0.0.1", "::1", "testclient"} and forwarded_source.startswith("bridge:"):
            source = forwarded_source[:120]
        try:
            return await engine.run_mode(mode_slug, source, payload.request_id)
        except ActionError as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error)) from error

    @app.get("/dashboard-api/v1/applications", dependencies=[Depends(local_dashboard_only)])
    async def native_list_applications() -> list[dict[str, Any]]:
        return database.list_applications()

    @app.post("/dashboard-api/v1/applications", status_code=status.HTTP_201_CREATED, dependencies=[Depends(local_dashboard_only)])
    async def native_create_application(payload: DashboardApplicationPayload) -> dict[str, Any]:
        return save_dashboard_application(payload)

    @app.put("/dashboard-api/v1/applications/{application_id}", dependencies=[Depends(local_dashboard_only)])
    async def native_update_application(application_id: int, payload: DashboardApplicationPayload) -> dict[str, Any]:
        if not database.get_application_by_id(application_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Aplicativo não encontrado.")
        return save_dashboard_application(payload, application_id)

    @app.delete("/dashboard-api/v1/applications/{application_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(local_dashboard_only)])
    async def native_delete_application(application_id: int) -> None:
        application = database.get_application_by_id(application_id)
        if not application:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Aplicativo não encontrado.")
        references = database.application_references(application["identifier"])
        if references:
            modes = ", ".join(sorted({reference["mode_name"] for reference in references}))
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=f"Este aplicativo é usado pelos modos: {modes}. Remova essas etapas antes de excluir.")
        database.delete_application(application_id)

    @app.post("/dashboard-api/v1/applications/{application_id}/test", dependencies=[Depends(local_dashboard_only)])
    async def native_test_application(application_id: int) -> dict[str, Any]:
        application = database.get_application_by_id(application_id)
        if not application:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Aplicativo não encontrado.")
        result = await engine.run_action("open_application", {"application": application["identifier"]}, "native_dashboard")
        if not result["success"]:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=result["error"])
        return result

    @app.post("/dashboard-api/v1/applications/{application_id}/close", dependencies=[Depends(local_dashboard_only)])
    async def native_close_application(application_id: int, payload: DashboardClosePayload) -> dict[str, Any]:
        application = database.get_application_by_id(application_id)
        if not application:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Aplicativo não encontrado.")
        result = await engine.run_action("close_application", {"application": application["identifier"], "force": payload.force}, "native_dashboard")
        if not result["success"]:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=result["error"])
        return result

    @app.get("/dashboard-api/v1/applications-active", dependencies=[Depends(local_dashboard_only)])
    async def native_active_applications() -> list[dict[str, Any]]:
        return registry.active_applications()

    @app.post("/dashboard-api/v1/applications/close-session", dependencies=[Depends(local_dashboard_only)])
    async def native_close_session_applications() -> dict[str, Any]:
        result = await engine.run_action("close_session_applications", {}, "native_dashboard")
        if not result["success"]:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=result["error"])
        return result

    @app.get("/dashboard-api/v1/devices", dependencies=[Depends(local_dashboard_only)])
    async def native_list_devices() -> list[dict[str, Any]]:
        return database.list_bridge_devices()

    @app.post("/dashboard-api/v1/devices", status_code=status.HTTP_201_CREATED, dependencies=[Depends(local_dashboard_only)])
    async def native_create_device(payload: DashboardBridgeDevicePayload) -> dict[str, Any]:
        return save_dashboard_bridge_device(payload)

    @app.put("/dashboard-api/v1/devices/{device_id}", dependencies=[Depends(local_dashboard_only)])
    async def native_update_device(device_id: int, payload: DashboardBridgeDevicePayload) -> dict[str, Any]:
        return save_dashboard_bridge_device(payload, device_id)

    @app.post("/dashboard-api/v1/devices/{device_id}/rotate-token", dependencies=[Depends(local_dashboard_only)])
    async def native_rotate_device_token(device_id: int) -> dict[str, Any]:
        device = database.get_bridge_device_by_id(device_id)
        if not device:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dispositivo nao encontrado.")
        token = secrets.token_hex(32)
        payload = DashboardBridgeDevicePayload(
            name=device["name"],
            ip_address=device.get("configured_ip", ""),
            additional_ip_addresses=device.get("additional_ips", []),
            auto_update_ip=bool(device.get("auto_update_ip")),
            source_policy=str(device.get("source_policy") or "ip"),
            enabled=bool(device.get("enabled")),
            token=token,
        )
        return save_dashboard_bridge_device(payload, device_id)

    @app.delete("/dashboard-api/v1/devices/{device_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(local_dashboard_only)])
    async def native_delete_device(device_id: int) -> None:
        if not database.get_bridge_device_by_id(device_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dispositivo nao encontrado.")
        database.delete_bridge_device(device_id)

    @app.get("/dashboard-api/v1/relays", dependencies=[Depends(local_dashboard_only)])
    async def native_list_relays() -> list[dict[str, Any]]:
        return database.list_bridge_relays()

    @app.post("/dashboard-api/v1/relays/bootstrap", dependencies=[Depends(local_dashboard_only)])
    async def native_create_relay_bootstrap(payload: DashboardRelayBootstrapPayload) -> dict[str, Any]:
        token = secrets.token_hex(32)
        database.create_bridge_relay(payload.name.strip(), bridge_token_hash(token), token[-6:])
        environment = {
            "JARVIS_RELAY_INSTANCE_ID": settings.instance_id,
            "JARVIS_RELAY_TOKEN": token,
            "JARVIS_RELAY_BIND_HOST": "0.0.0.0",
            "JARVIS_RELAY_PORT": "9580",
        }
        return {
            "success": True,
            "instance_id": settings.instance_id,
            "instance_name": settings.instance_name,
            "service_type": "_jarvis._tcp.local.",
            "relay_token": token,
            "environment": environment,
            "message": "Credencial de Relay criada. O token completo é exibido somente agora.",
        }

    @app.post("/dashboard-api/v1/relays/revoke-all", dependencies=[Depends(local_dashboard_only)])
    async def native_revoke_all_relays() -> dict[str, Any]:
        revoked = database.revoke_all_bridge_relays()
        return {"success": True, "revoked": revoked}

    @app.get("/dashboard-api/v1/modes", dependencies=[Depends(local_dashboard_only)])
    async def native_list_modes() -> list[dict[str, Any]]:
        return [native_mode_response(mode) for mode in database.list_modes()]

    @app.post("/dashboard-api/v1/modes", status_code=status.HTTP_201_CREATED, dependencies=[Depends(local_dashboard_only)])
    async def native_create_mode(payload: DashboardModePayload) -> dict[str, Any]:
        return save_dashboard_mode(payload)

    @app.put("/dashboard-api/v1/modes/{mode_id}", dependencies=[Depends(local_dashboard_only)])
    async def native_update_mode(mode_id: int, payload: DashboardModePayload) -> dict[str, Any]:
        if not database.get_mode_by_id(mode_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Modo não encontrado.")
        return save_dashboard_mode(payload, mode_id)

    @app.delete("/dashboard-api/v1/modes/{mode_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(local_dashboard_only)])
    async def native_delete_mode(mode_id: int) -> None:
        if not database.get_mode_by_id(mode_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Modo não encontrado.")
        database.delete_mode(mode_id)

    @app.post("/dashboard-api/v1/modes/{mode_id}/test", dependencies=[Depends(local_dashboard_only)])
    async def native_test_mode(mode_id: int) -> dict[str, Any]:
        mode = database.get_mode_by_id(mode_id)
        if not mode:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Modo não encontrado.")
        try:
            return await engine.run_mode(mode["slug"], "native_dashboard")
        except ActionError as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error)) from error

    @app.get("/dashboard-api/v1/history", dependencies=[Depends(local_dashboard_only)])
    async def native_history() -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for row in database.recent_history(1000):
            success = row.get("success")
            result.append(
                {
                    "id": row.get("id"),
                    "timestamp": row.get("started_at") or "",
                    "origin": history_source_label(str(row.get("source") or "")),
                    "type": "Modo" if row.get("target_type") == "mode" else "Acao",
                    "command": row.get("target_name") or "",
                    "duration": "-" if row.get("duration_ms") is None else f"{row.get('duration_ms')} ms",
                    "result": "Em andamento" if success is None else ("Sucesso" if bool(success) else "Falha"),
                    "details": history_details(row),
                }
            )
        return result

    @app.delete("/dashboard-api/v1/history", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(local_dashboard_only)])
    async def native_clear_history() -> None:
        database.clear_history()

    @app.post("/dashboard-api/v1/mobile-setup", dependencies=[Depends(local_dashboard_only)])
    async def native_mobile_setup(payload: DashboardQrPayload) -> dict[str, Any]:
        # O token existe apenas nesta requisicao local e nunca e salvo em texto puro.
        token = payload.token.strip()
        local_host = f"{settings.instance_name}.local"
        bridge_url = f"http://{local_host}:{settings.bridge_port}/bridge/v1/command"
        pair_url = f"http://{local_host}:{settings.bridge_port}/pair#token={quote(token, safe='')}"

        remote_enabled = bool(database.get_setting("remote_access_enabled", settings.remote_access_enabled))
        remote_url = str(database.get_setting("remote_access_url", settings.remote_access_url) or "").rstrip("/")
        remote_type = str(database.get_setting("remote_access_type", settings.remote_access_type) or "custom")
        remote_bridge_url = f"{remote_url}/bridge/v1/command" if (remote_enabled and remote_url) else ""
        remote_pair_url = f"{remote_url}/pair#token={quote(token, safe='')}" if (remote_enabled and remote_url) else ""

        setup = {
            "jarvis": "mobile-setup",
            "url": remote_bridge_url or bridge_url,
            "local_url": bridge_url,
            "remote_url": remote_bridge_url,
            "remote_type": remote_type,
            "method": "POST",
            "headers": {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            "body": {"command": "SEU-MODO"},
        }
        setup_text = json.dumps(setup, ensure_ascii=False, separators=(",", ":"))
        try:
            import qrcode

            image = qrcode.make(pair_url)
            output = io.BytesIO()
            image.save(output, format="PNG")
            shortcut_output = io.BytesIO()
            if settings.ios_shortcut_url.startswith("https://www.icloud.com/shortcuts/"):
                qrcode.make(settings.ios_shortcut_url).save(shortcut_output, format="PNG")
        except Exception as error:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Nao foi possivel gerar o QR Code localmente.") from error
        return {
            "bridge_url": bridge_url,
            "pair_url": pair_url,
            "remote_bridge_url": remote_bridge_url,
            "remote_pair_url": remote_pair_url,
            "remote_access_type": remote_type,
            "instance_name": settings.instance_name,
            "ios_shortcut_url": settings.ios_shortcut_url,
            "authorization": f"Bearer {token}",
            "setup_text": setup_text,
            "qr_png_base64": base64.b64encode(output.getvalue()).decode("ascii"),
            "shortcut_qr_png_base64": base64.b64encode(shortcut_output.getvalue()).decode("ascii") if shortcut_output.getvalue() else "",
        }

    @app.get("/dashboard-api/v1/backup", dependencies=[Depends(local_dashboard_only)])
    async def native_export_backup() -> dict[str, Any]:
        applications = [
            {
                "name": application["name"],
                "identifier": application["identifier"],
                "executable_path": application["executable_path"],
                "process_name": application["process_name"],
                "arguments": application.get("arguments", []),
                "enabled": bool(application.get("enabled", True)),
                "close_policy": application.get("close_policy", "safe"),
            }
            for application in database.list_applications()
        ]
        modes: list[dict[str, Any]] = []
        for mode in database.list_modes():
            modes.append(
                {
                    "name": mode["name"],
                    "slug": mode["slug"],
                    "enabled": bool(mode.get("enabled", True)),
                    "steps": [
                        {
                            "action_type": step["action_type"],
                            "parameters": step["parameters"],
                            "enabled": bool(step.get("enabled", True)),
                            "timeout_seconds": int(step.get("timeout_seconds", 30)),
                            "on_error": step.get("on_error", "stop"),
                        }
                        for step in database.list_steps(mode["id"])
                    ],
                }
            )
        return {
            "format": "jarvis-config-backup",
            "version": 1,
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "applications": applications,
            "modes": modes,
        }

    @app.post("/dashboard-api/v1/backup/import", dependencies=[Depends(local_dashboard_only)])
    async def native_import_backup(payload: DashboardBackupPayload) -> dict[str, Any]:
        if payload.format != "jarvis-config-backup" or payload.version != 1:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Arquivo de backup do Jarvis invalido ou versao nao suportada.")

        imported_applications: list[dict[str, Any]] = []
        identifiers: set[str] = set()
        for application in payload.applications:
            identifier = slugify(application.identifier)
            executable_path = Path(application.executable_path.strip())
            if not identifier or executable_path.suffix.casefold() != ".exe":
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Backup contem um aplicativo com identificador ou executavel invalido.")
            if identifier in identifiers:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Backup contem aplicativo duplicado: {identifier}.")
            identifiers.add(identifier)
            imported_applications.append(
                {
                    "name": application.name.strip(),
                    "identifier": identifier,
                    "executable_path": str(executable_path),
                    "process_name": application.process_name.strip(),
                    "arguments": [argument.strip() for argument in application.arguments if argument.strip()],
                    "enabled": application.enabled,
                    "close_policy": application.close_policy,
                }
            )

        existing_identifiers = {application["identifier"] for application in database.list_applications()}
        app_conflicts = sorted(identifiers & existing_identifiers)

        imported_modes: list[dict[str, Any]] = []
        slugs: set[str] = set()
        known_applications = existing_identifiers | identifiers
        application_actions = {"open_application", "close_application", "wait_process_start", "wait_process_exit", "check_process"}
        for mode in payload.modes:
            slug = slugify(mode.slug)
            if not slug:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Backup contem um modo com identificador invalido.")
            if slug in slugs:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Backup contem modo duplicado: {slug}.")
            slugs.add(slug)
            steps: list[dict[str, Any]] = []
            for step in mode.steps:
                if step.action_type not in registry.actions:
                    raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Backup contem acao desconhecida: {step.action_type}.")
                if step.on_error not in {"stop", "continue"}:
                    raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Backup contem politica de erro invalida.")
                parameters = dict(step.parameters)
                if step.action_type in application_actions:
                    application_identifier = slugify(str(parameters.get("application") or ""))
                    if application_identifier not in known_applications:
                        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Modo {slug} referencia aplicativo inexistente: {application_identifier or '(vazio)'}.")
                    parameters["application"] = application_identifier
                steps.append(
                    {
                        "action_type": step.action_type,
                        "parameters": parameters,
                }
            )

        existing_identifiers = {application["identifier"] for application in database.list_applications()}
        app_conflicts = sorted(identifiers & existing_identifiers)

        imported_modes: list[dict[str, Any]] = []
        slugs: set[str] = set()
        known_applications = existing_identifiers | identifiers
        application_actions = {"open_application", "close_application", "wait_process_start", "wait_process_exit", "check_process"}
        for mode in payload.modes:
            slug = slugify(mode.slug)
            if not slug:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Backup contem um modo com identificador invalido.")
            if slug in slugs:
                raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Backup contem modo duplicado: {slug}.")
            slugs.add(slug)
            steps: list[dict[str, Any]] = []
            for step in mode.steps:
                if step.action_type not in registry.actions:
                    raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Backup contem acao desconhecida: {step.action_type}.")
                if step.on_error not in {"stop", "continue"}:
                    raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Backup contem politica de erro invalida.")
                parameters = dict(step.parameters)
                if step.action_type in application_actions:
                    application_identifier = slugify(str(parameters.get("application") or ""))
                    if application_identifier not in known_applications:
                        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Modo {slug} referencia aplicativo inexistente: {application_identifier or '(vazio)'}.")
                    parameters["application"] = application_identifier
                steps.append(
                    {
                        "action_type": step.action_type,
                        "parameters": parameters,
                        "enabled": step.enabled,
                        "timeout_seconds": step.timeout_seconds,
                        "on_error": step.on_error,
                    }
                )
            imported_modes.append({"name": mode.name.strip(), "slug": slug, "enabled": mode.enabled, "steps": steps})

        existing_slugs = {mode["slug"] for mode in database.list_modes()}
        mode_conflicts = sorted(slugs & existing_slugs)
        if app_conflicts or mode_conflicts:
            conflicts: list[str] = []
            if app_conflicts:
                conflicts.append("aplicativos: " + ", ".join(app_conflicts))
            if mode_conflicts:
                conflicts.append("modos: " + ", ".join(mode_conflicts))
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Importacao cancelada sem alterar dados. Ja existem " + "; ".join(conflicts) + ".",
            )

        try:
            database.import_configuration(imported_applications, imported_modes)
        except Exception as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Importacao cancelada sem sobrescrever dados existentes.") from error
        return {
            "success": True,
            "applications_imported": len(imported_applications),
            "modes_imported": len(imported_modes),
        }

    @app.get("/dashboard-api/v1/network", dependencies=[Depends(local_dashboard_only)])
    async def native_get_network() -> dict[str, Any]:
        remote_enabled = database.get_setting("remote_access_enabled", settings.remote_access_enabled)
        remote_url = database.get_setting("remote_access_url", settings.remote_access_url)
        remote_type = database.get_setting("remote_access_type", settings.remote_access_type)
        return {
            "port": settings.port,
            "bridge_port": settings.bridge_port,
            "local_ip": get_local_lan_ip(),
            "bridge_host": settings.bridge_host,
            "instance_id": settings.instance_id,
            "instance_name": settings.instance_name,
            "local_url": f"http://{settings.instance_name}.local:{settings.bridge_port}",
            "local_description": "Disponível apenas na mesma rede local. O endereço continua válido mesmo que o IP local do computador mude.",
            "allow_sensitive_actions": settings.bridge_max_risk in {"SENSITIVE", "DANGEROUS"},
            "remote_access_enabled": bool(remote_enabled),
            "remote_access_url": str(remote_url or ""),
            "remote_access_type": str(remote_type or "custom"),
        }

    @app.put("/dashboard-api/v1/network", dependencies=[Depends(local_dashboard_only)])
    async def native_update_network(payload: DashboardNetworkPayload) -> dict[str, Any]:
        if payload.port == payload.bridge_port:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="A porta do Agent e a porta da Bridge devem ser diferentes.",
            )
        try:
            cleaned_remote_url = validate_remote_access_url(payload.remote_access_url)
        except ValueError as error:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=str(error),
            ) from error
        allowed_remote_types = {"direct", "relay", "custom", "tailscale", "cloudflare", "ddns"}
        if payload.remote_access_type not in allowed_remote_types:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="O tipo de acesso remoto deve ser direct, relay ou custom.",
            )

        set_env_value("JARVIS_PORT", str(payload.port))
        set_env_value("JARVIS_BRIDGE_PORT", str(payload.bridge_port))
        set_env_value("JARVIS_BRIDGE_MAX_RISK", "SENSITIVE" if payload.allow_sensitive_actions else "SAFE")
        set_env_value("JARVIS_REMOTE_ACCESS_ENABLED", "true" if payload.remote_access_enabled else "false")
        set_env_value("JARVIS_REMOTE_ACCESS_URL", cleaned_remote_url)
        set_env_value("JARVIS_REMOTE_ACCESS_TYPE", payload.remote_access_type)

        database.set_setting("remote_access_enabled", payload.remote_access_enabled)
        database.set_setting("remote_access_url", cleaned_remote_url)
        database.set_setting("remote_access_type", payload.remote_access_type)

        return {
            "success": True,
            "port": payload.port,
            "bridge_port": payload.bridge_port,
            "local_ip": get_local_lan_ip(),
            "instance_name": settings.instance_name,
            "local_url": f"http://{settings.instance_name}.local:{payload.bridge_port}",
            "local_description": "Disponível apenas na mesma rede local. O endereço continua válido mesmo que o IP local do computador mude.",
            "allow_sensitive_actions": payload.allow_sensitive_actions,
            "remote_access_enabled": payload.remote_access_enabled,
            "remote_access_url": cleaned_remote_url,
            "remote_access_type": payload.remote_access_type,
            "message": "Configurações de rede salvas. Reinicie o Jarvis pelo ícone da bandeja para aplicar alterações de porta.",
        }

    @app.post("/dashboard-api/v1/network/test-remote", dependencies=[Depends(local_dashboard_only)])
    async def native_test_remote_network(payload: DashboardRemoteTestPayload) -> dict[str, Any]:
        try:
            target_url = validate_remote_access_url(payload.url)
        except ValueError as error:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(error)) from error

        if not target_url:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Informe uma URL para testar.")

        health_url = f"{target_url}/bridge/v1/health"
        try:
            async with httpx.AsyncClient(timeout=6.0) as client:
                try:
                    response = await client.get(health_url)
                except httpx.HTTPError:
                    response = await client.get(target_url)

                if response.status_code == 200:
                    return {
                        "success": True,
                        "status": "connected",
                        "http_code": response.status_code,
                        "message": "O endpoint respondeu HTTP 200. A identidade ainda precisa ser confirmada por um cliente ou Relay autenticado.",
                        "url": target_url,
                        "identity_verified": False,
                    }
                elif response.status_code in {401, 403}:
                    return {
                        "success": True,
                        "status": "auth_required",
                        "http_code": response.status_code,
                        "message": "Endpoint alcançado e protegido por autenticação. A identidade deve ser confirmada pelo cliente ou Relay autenticado.",
                        "url": target_url,
                        "identity_verified": False,
                    }
                elif response.status_code == 404:
                    return {
                        "success": False,
                        "status": "not_found",
                        "http_code": 404,
                        "message": "Rota inexistente (HTTP 404). Verifique se o endereço aponta para a porta correta da Bridge.",
                        "url": target_url,
                        "identity_verified": False,
                    }
                else:
                    return {
                        "success": False,
                        "status": "http_error",
                        "http_code": response.status_code,
                        "message": f"Servidor respondeu com código HTTP {response.status_code}.",
                        "url": target_url,
                        "identity_verified": False,
                    }
        except (httpx.ConnectTimeout, httpx.ReadTimeout):
            return {
                "success": False,
                "status": "timeout",
                "http_code": None,
                "message": "Tempo de conexão esgotado (timeout). O host não respondeu a tempo.",
                "url": target_url,
                "identity_verified": False,
            }
        except httpx.ConnectError:
            return {
                "success": False,
                "status": "unreachable",
                "http_code": None,
                "message": "Não foi possível conectar (host inacessível ou conexão recusada).",
                "url": target_url,
                "identity_verified": False,
            }
        except Exception as error:
            return {
                "success": False,
                "status": "error",
                "http_code": None,
                "message": f"Falha na conexão: {str(error)}",
                "url": target_url,
                "identity_verified": False,
            }

    @app.get("/", response_class=HTMLResponse, dependencies=[Depends(legacy_dashboard_only)])
    async def dashboard(request: Request) -> HTMLResponse:
        return render(request, "index.html", applications=database.list_applications(), modes=database.list_modes(), logs=database.recent_history(10), message=request.query_params.get("message"), error=request.query_params.get("error"))

    @app.get("/dashboard/applications", response_class=HTMLResponse, dependencies=[Depends(legacy_dashboard_only)])
    async def applications_page(request: Request) -> HTMLResponse:
        return render(request, "applications.html", applications=database.list_applications(), message=request.query_params.get("message"), error=request.query_params.get("error"))

    @app.get("/dashboard/applications/new", response_class=HTMLResponse, dependencies=[Depends(legacy_dashboard_only)])
    async def new_application(request: Request, executable_path: str = "") -> HTMLResponse:
        return render(request, "application_form.html", application=None, executable_path=executable_path, error=request.query_params.get("error"))

    @app.get("/dashboard/applications/{application_id}/edit", response_class=HTMLResponse, dependencies=[Depends(legacy_dashboard_only)])
    async def edit_application(request: Request, application_id: int) -> HTMLResponse:
        application = database.get_application_by_id(application_id)
        if not application:
            raise HTTPException(status_code=404, detail="Aplicativo não encontrado.")
        return render(request, "application_form.html", application=application, executable_path=application["executable_path"], error=request.query_params.get("error"))

    @app.get("/dashboard/pick-executable", dependencies=[Depends(legacy_dashboard_only)])
    def pick_executable() -> RedirectResponse:
        selector_script = """
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Selecione um executável'
$dialog.Filter = 'Executáveis (*.exe)|*.exe'
$dialog.CheckFileExists = $true
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    Write-Output $dialog.FileName
}
"""
        try:
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-STA", "-Command", selector_script],
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=300,
                check=False,
            )
            selected = result.stdout.strip()
        except (OSError, subprocess.TimeoutExpired):
            return RedirectResponse("/dashboard/applications/new?error=Não+foi+possível+abrir+o+seletor.+Informe+o+caminho+manualmente.", status_code=303)
        if result.returncode != 0:
            return RedirectResponse("/dashboard/applications/new?error=Não+foi+possível+abrir+o+seletor.+Informe+o+caminho+manualmente.", status_code=303)
        if not selected:
            return RedirectResponse("/dashboard/applications/new", status_code=303)
        selected_path = Path(selected)
        if not selected_path.is_file() or selected_path.suffix.casefold() != ".exe":
            return RedirectResponse("/dashboard/applications/new?error=Selecione+um+arquivo+.exe+válido.", status_code=303)
        return RedirectResponse(f"/dashboard/applications/new?executable_path={quote(selected, safe='')}", status_code=303)

    @app.post("/dashboard/applications/save", dependencies=[Depends(legacy_dashboard_only)])
    async def save_application(name: str = Form(...), identifier: str = Form(...), executable_path: str = Form(...), process_name: str = Form(...), arguments: str = Form(""), enabled: bool = Form(False), close_policy: str = Form("safe"), application_id: int | None = Form(None)) -> RedirectResponse:
        identifier = slugify(identifier)
        argument_list = [argument.strip() for argument in arguments.splitlines() if argument.strip()]
        if not name.strip() or not identifier or not process_name.strip() or Path(executable_path).suffix.casefold() != ".exe":
            return RedirectResponse("/dashboard/applications/new?error=Preencha+todos+os+campos+e+informe+um+arquivo+.exe.", status_code=303)
        try:
            if application_id is not None:
                current = database.get_application_by_id(application_id)
                if current and current["identifier"] != identifier and database.application_references(current["identifier"]):
                    return RedirectResponse("/dashboard/applications?error=Aplicativo+usado+por+um+modo.+Remova+as+etapas+antes+de+trocar+o+identificador.", status_code=303)
            policy = close_policy if close_policy in {"safe", "force", "never"} else "safe"
            database.save_application({"name": name.strip(), "identifier": identifier, "executable_path": executable_path.strip(), "process_name": process_name.strip(), "arguments": argument_list, "enabled": enabled, "close_policy": policy}, application_id)
        except Exception:
            return RedirectResponse("/dashboard/applications/new?error=Identificador+já+utilizado.", status_code=303)
        return RedirectResponse("/dashboard/applications?message=Aplicativo+salvo.", status_code=303)

    @app.post("/dashboard/applications/{application_id}/test", dependencies=[Depends(legacy_dashboard_only)])
    async def test_application(application_id: int) -> RedirectResponse:
        application = database.get_application_by_id(application_id)
        if not application:
            return RedirectResponse("/dashboard/applications?error=Aplicativo+não+encontrado.", status_code=303)
        result = await engine.run_action("open_application", {"application": application["identifier"]}, "dashboard")
        key = "message" if result["success"] else "error"
        return RedirectResponse(f"/dashboard/applications?{key}={result.get('result', {}).get('message', result.get('error', 'Falha'))}", status_code=303)

    @app.post("/dashboard/applications/{application_id}/close", dependencies=[Depends(legacy_dashboard_only)])
    async def close_application(application_id: int) -> RedirectResponse:
        application = database.get_application_by_id(application_id)
        if not application:
            return RedirectResponse("/dashboard/applications?error=Aplicativo+não+encontrado.", status_code=303)
        result = await engine.run_action("close_application", {"application": application["identifier"]}, "dashboard")
        key = "message" if result["success"] else "error"
        return RedirectResponse(f"/dashboard/applications?{key}={result.get('result', {}).get('message', result.get('error', 'Falha'))}", status_code=303)

    @app.post("/dashboard/applications/{application_id}/delete", dependencies=[Depends(legacy_dashboard_only)])
    async def delete_application(application_id: int) -> RedirectResponse:
        application = database.get_application_by_id(application_id)
        if application and database.application_references(application["identifier"]):
            return RedirectResponse("/dashboard/applications?error=Aplicativo+usado+por+um+modo.+Remova+as+etapas+antes+de+excluir.", status_code=303)
        database.delete_application(application_id)
        return RedirectResponse("/dashboard/applications?message=Aplicativo+excluído.", status_code=303)

    @app.get("/dashboard/modes", response_class=HTMLResponse, dependencies=[Depends(legacy_dashboard_only)])
    async def modes_page(request: Request) -> HTMLResponse:
        return render(request, "modes.html", modes=database.list_modes(), message=request.query_params.get("message"), error=request.query_params.get("error"))

    @app.post("/dashboard/modes/save", dependencies=[Depends(legacy_dashboard_only)])
    async def save_mode(name: str = Form(...), slug: str = Form(""), enabled: bool = Form(False), mode_id: int | None = Form(None)) -> RedirectResponse:
        actual_slug = slugify(slug or name)
        if not name.strip() or not actual_slug:
            return RedirectResponse("/dashboard/modes?error=Informe+um+nome+válido.", status_code=303)
        try:
            mode_id = database.save_mode(name.strip(), actual_slug, enabled, mode_id)
        except Exception:
            return RedirectResponse("/dashboard/modes?error=Identificador+de+modo+já+utilizado.", status_code=303)
        return RedirectResponse(f"/dashboard/modes/{mode_id}/edit?message=Modo+salvo.", status_code=303)

    @app.get("/dashboard/modes/{mode_id}/edit", response_class=HTMLResponse, dependencies=[Depends(legacy_dashboard_only)])
    async def edit_mode(request: Request, mode_id: int) -> HTMLResponse:
        mode = database.get_mode_by_id(mode_id)
        if not mode:
            raise HTTPException(status_code=404, detail="Modo não encontrado.")
        return render(request, "mode_form.html", mode=mode, steps=database.list_steps(mode_id), applications=database.list_applications(), actions=registry.describe(), message=request.query_params.get("message"), error=request.query_params.get("error"))

    @app.post("/dashboard/modes/{mode_id}/steps/save", dependencies=[Depends(legacy_dashboard_only)])
    async def save_step(mode_id: int, action_type: str = Form(...), application: str = Form(""), url: str = Form(""), seconds: str = Form("0"), timeout_seconds: int = Form(30), on_error: str = Form("stop"), enabled: bool = Form(False), step_id: int | None = Form(None)) -> RedirectResponse:
        try:
            parameters = build_step_parameters(action_type, application, url, seconds, timeout_seconds)
            if action_type not in registry.actions or not 1 <= timeout_seconds <= 3600 or on_error not in {"stop", "continue"}:
                raise ValueError("Parâmetros inválidos.")
            if step_id:
                database.update_step(step_id, action_type, parameters, timeout_seconds, on_error, enabled)
            else:
                database.add_step(mode_id, action_type, parameters, timeout_seconds, on_error, enabled)
        except ValueError as error:
            return RedirectResponse(f"/dashboard/modes/{mode_id}/edit?error={error}", status_code=303)
        return RedirectResponse(f"/dashboard/modes/{mode_id}/edit?message=Etapa+salva.", status_code=303)

    @app.post("/dashboard/modes/{mode_id}/steps/{step_id}/delete", dependencies=[Depends(legacy_dashboard_only)])
    async def delete_step(mode_id: int, step_id: int) -> RedirectResponse:
        database.delete_step(step_id)
        return RedirectResponse(f"/dashboard/modes/{mode_id}/edit?message=Etapa+excluída.", status_code=303)

    @app.post("/dashboard/modes/{mode_id}/steps/{step_id}/move/{direction}", dependencies=[Depends(legacy_dashboard_only)])
    async def move_step(mode_id: int, step_id: int, direction: int) -> RedirectResponse:
        if direction in {-1, 1}:
            database.move_step(step_id, direction)
        return RedirectResponse(f"/dashboard/modes/{mode_id}/edit", status_code=303)

    @app.post("/dashboard/modes/{mode_id}/run", dependencies=[Depends(legacy_dashboard_only)])
    async def dashboard_run_mode(mode_id: int) -> RedirectResponse:
        mode = database.get_mode_by_id(mode_id)
        if not mode:
            return RedirectResponse("/dashboard/modes?error=Modo+não+encontrado.", status_code=303)
        try:
            result = await engine.run_mode(mode["slug"], "dashboard")
            message = "Modo executado." if result["success"] else "Modo finalizado com falha. Consulte os logs."
            return RedirectResponse(f"/dashboard/modes/{mode_id}/edit?message={message}", status_code=303)
        except ActionError as error:
            return RedirectResponse(f"/dashboard/modes/{mode_id}/edit?error={error}", status_code=303)

    @app.post("/dashboard/modes/{mode_id}/delete", dependencies=[Depends(legacy_dashboard_only)])
    async def delete_mode(mode_id: int) -> RedirectResponse:
        database.delete_mode(mode_id)
        return RedirectResponse("/dashboard/modes?message=Modo+excluído.", status_code=303)

    @app.get("/dashboard/logs", response_class=HTMLResponse, dependencies=[Depends(legacy_dashboard_only)])
    async def logs_page(request: Request) -> HTMLResponse:
        return render(request, "logs.html", logs=database.recent_history(100))

    return app


app = create_app()
