from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def migrate(self) -> None:
        with self.connection() as connection:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
            )
            applied = {row["version"] for row in connection.execute("SELECT version FROM schema_migrations")}
            if 1 not in applied:
                connection.executescript(
                    """
                    CREATE TABLE applications (
                        id INTEGER PRIMARY KEY,
                        name TEXT NOT NULL,
                        identifier TEXT NOT NULL UNIQUE,
                        executable_path TEXT NOT NULL,
                        process_name TEXT NOT NULL,
                        arguments_json TEXT NOT NULL DEFAULT '[]',
                        enabled INTEGER NOT NULL DEFAULT 1,
                        close_policy TEXT NOT NULL DEFAULT 'safe' CHECK(close_policy IN ('safe', 'force', 'never')),
                        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                    );
                    CREATE TABLE modes (
                        id INTEGER PRIMARY KEY,
                        name TEXT NOT NULL,
                        slug TEXT NOT NULL UNIQUE,
                        enabled INTEGER NOT NULL DEFAULT 1,
                        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                    );
                    CREATE TABLE mode_steps (
                        id INTEGER PRIMARY KEY,
                        mode_id INTEGER NOT NULL REFERENCES modes(id) ON DELETE CASCADE,
                        position INTEGER NOT NULL,
                        action_type TEXT NOT NULL,
                        parameters_json TEXT NOT NULL DEFAULT '{}',
                        enabled INTEGER NOT NULL DEFAULT 1,
                        timeout_seconds INTEGER NOT NULL DEFAULT 30,
                        on_error TEXT NOT NULL DEFAULT 'stop' CHECK(on_error IN ('stop', 'continue')),
                        UNIQUE(mode_id, position)
                    );
                    CREATE TABLE aliases (
                        id INTEGER PRIMARY KEY,
                        target_type TEXT NOT NULL CHECK(target_type IN ('mode', 'application')),
                        target_id INTEGER NOT NULL,
                        alias TEXT NOT NULL UNIQUE
                    );
                    CREATE TABLE settings (
                        key TEXT PRIMARY KEY,
                        value_json TEXT NOT NULL
                    );
                    CREATE TABLE execution_history (
                        id INTEGER PRIMARY KEY,
                        request_id TEXT NOT NULL,
                        source TEXT NOT NULL,
                        target_type TEXT NOT NULL,
                        target_name TEXT NOT NULL,
                        started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        finished_at TEXT,
                        success INTEGER,
                        duration_ms INTEGER,
                        details_json TEXT NOT NULL DEFAULT '{}',
                        error_message TEXT
                    );
                    CREATE INDEX idx_history_started_at ON execution_history(started_at DESC);
                    """
                )
                connection.execute("INSERT INTO schema_migrations(version) VALUES (1)")
            if 2 not in applied:
                connection.executescript(
                    """
                    CREATE TABLE bridge_devices (
                        id INTEGER PRIMARY KEY,
                        name TEXT NOT NULL,
                        token_hash TEXT NOT NULL UNIQUE,
                        token_hint TEXT NOT NULL DEFAULT '',
                        configured_ip TEXT NOT NULL DEFAULT '',
                        last_ip TEXT NOT NULL DEFAULT '',
                        auto_update_ip INTEGER NOT NULL DEFAULT 0,
                        enabled INTEGER NOT NULL DEFAULT 1,
                        last_seen_at TEXT,
                        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                    );
                    CREATE INDEX idx_bridge_devices_last_seen ON bridge_devices(last_seen_at DESC);
                    """
                )
                connection.execute("INSERT INTO schema_migrations(version) VALUES (2)")
            if 3 not in applied:
                columns = {row["name"] for row in connection.execute("PRAGMA table_info(applications)")}
                if "close_policy" not in columns:
                    connection.execute(
                        "ALTER TABLE applications ADD COLUMN close_policy TEXT NOT NULL DEFAULT 'safe' CHECK(close_policy IN ('safe', 'force', 'never'))"
                    )
                connection.execute("INSERT INTO schema_migrations(version) VALUES (3)")
            if 4 not in applied:
                columns = {row["name"] for row in connection.execute("PRAGMA table_info(bridge_devices)")}
                if "additional_ips_json" not in columns:
                    connection.execute("ALTER TABLE bridge_devices ADD COLUMN additional_ips_json TEXT NOT NULL DEFAULT '[]'")
                connection.execute("INSERT INTO schema_migrations(version) VALUES (4)")

    def list_applications(self) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute("SELECT * FROM applications ORDER BY name COLLATE NOCASE").fetchall()
        return [self._application(row) for row in rows]

    def get_application(self, identifier: str) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute("SELECT * FROM applications WHERE identifier = ?", (identifier,)).fetchone()
        return self._application(row) if row else None

    def get_application_by_id(self, application_id: int) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute("SELECT * FROM applications WHERE id = ?", (application_id,)).fetchone()
        return self._application(row) if row else None

    def save_application(self, application: dict[str, Any], application_id: int | None = None) -> int:
        values = (application["name"], application["identifier"], application["executable_path"], application["process_name"], json.dumps(application.get("arguments", [])), int(application.get("enabled", True)), application.get("close_policy", "safe"))
        with self.connection() as connection:
            if application_id is None:
                cursor = connection.execute("INSERT INTO applications(name, identifier, executable_path, process_name, arguments_json, enabled, close_policy) VALUES (?, ?, ?, ?, ?, ?, ?)", values)
                return int(cursor.lastrowid)
            connection.execute("UPDATE applications SET name=?, identifier=?, executable_path=?, process_name=?, arguments_json=?, enabled=?, close_policy=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (*values, application_id))
        return application_id

    def application_references(self, identifier: str) -> list[dict[str, Any]]:
        references: list[dict[str, Any]] = []
        with self.connection() as connection:
            rows = connection.execute(
                "SELECT ms.id AS step_id, ms.parameters_json, m.id AS mode_id, m.name AS mode_name, m.slug AS mode_slug "
                "FROM mode_steps ms JOIN modes m ON m.id = ms.mode_id "
                "WHERE ms.action_type IN ('open_application', 'close_application', 'wait_process_start', 'wait_process_exit', 'check_process')"
            ).fetchall()
        for row in rows:
            try:
                parameters = json.loads(row["parameters_json"])
            except (TypeError, json.JSONDecodeError):
                continue
            if parameters.get("application") == identifier:
                references.append({
                    "step_id": row["step_id"],
                    "mode_id": row["mode_id"],
                    "mode_name": row["mode_name"],
                    "mode_slug": row["mode_slug"],
                })
        return references

    def delete_application(self, application_id: int) -> None:
        with self.connection() as connection:
            connection.execute("DELETE FROM applications WHERE id = ?", (application_id,))

    def list_modes(self) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute("SELECT * FROM modes ORDER BY name COLLATE NOCASE").fetchall()
        return [dict(row) for row in rows]

    def get_mode(self, slug: str) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute("SELECT * FROM modes WHERE slug = ?", (slug,)).fetchone()
        return dict(row) if row else None

    def get_mode_by_id(self, mode_id: int) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute("SELECT * FROM modes WHERE id = ?", (mode_id,)).fetchone()
        return dict(row) if row else None

    def save_mode(self, name: str, slug: str, enabled: bool = True, mode_id: int | None = None) -> int:
        with self.connection() as connection:
            if mode_id is None:
                cursor = connection.execute("INSERT INTO modes(name, slug, enabled) VALUES (?, ?, ?)", (name, slug, int(enabled)))
                return int(cursor.lastrowid)
            connection.execute("UPDATE modes SET name=?, slug=?, enabled=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (name, slug, int(enabled), mode_id))
        return mode_id

    def delete_mode(self, mode_id: int) -> None:
        with self.connection() as connection:
            connection.execute("DELETE FROM modes WHERE id = ?", (mode_id,))

    def list_steps(self, mode_id: int) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute("SELECT * FROM mode_steps WHERE mode_id = ? ORDER BY position", (mode_id,)).fetchall()
        return [{**dict(row), "parameters": json.loads(row["parameters_json"])} for row in rows]

    def add_step(self, mode_id: int, action_type: str, parameters: dict[str, Any], timeout_seconds: int, on_error: str, enabled: bool = True) -> int:
        with self.connection() as connection:
            position = connection.execute("SELECT COALESCE(MAX(position), 0) + 1 AS next_position FROM mode_steps WHERE mode_id = ?", (mode_id,)).fetchone()["next_position"]
            cursor = connection.execute("INSERT INTO mode_steps(mode_id, position, action_type, parameters_json, enabled, timeout_seconds, on_error) VALUES (?, ?, ?, ?, ?, ?, ?)", (mode_id, position, action_type, json.dumps(parameters), int(enabled), timeout_seconds, on_error))
            return int(cursor.lastrowid)

    def replace_mode_steps(self, mode_id: int, steps: list[dict[str, Any]]) -> None:
        with self.connection() as connection:
            connection.execute("DELETE FROM mode_steps WHERE mode_id = ?", (mode_id,))
            for position, step in enumerate(steps, start=1):
                connection.execute(
                    "INSERT INTO mode_steps(mode_id, position, action_type, parameters_json, enabled, timeout_seconds, on_error) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        mode_id,
                        position,
                        step["action_type"],
                        json.dumps(step["parameters"]),
                        int(step.get("enabled", True)),
                        step.get("timeout_seconds", 30),
                        step.get("on_error", "stop"),
                    ),
                )

    def get_step(self, step_id: int) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute("SELECT * FROM mode_steps WHERE id = ?", (step_id,)).fetchone()
        return {**dict(row), "parameters": json.loads(row["parameters_json"])} if row else None

    def update_step(self, step_id: int, action_type: str, parameters: dict[str, Any], timeout_seconds: int, on_error: str, enabled: bool) -> None:
        with self.connection() as connection:
            connection.execute("UPDATE mode_steps SET action_type=?, parameters_json=?, timeout_seconds=?, on_error=?, enabled=? WHERE id=?", (action_type, json.dumps(parameters), timeout_seconds, on_error, int(enabled), step_id))

    def delete_step(self, step_id: int) -> None:
        with self.connection() as connection:
            row = connection.execute("SELECT mode_id FROM mode_steps WHERE id = ?", (step_id,)).fetchone()
            if not row:
                return
            connection.execute("DELETE FROM mode_steps WHERE id = ?", (step_id,))
            self._normalize_positions(connection, row["mode_id"])

    def move_step(self, step_id: int, direction: int) -> None:
        with self.connection() as connection:
            step = connection.execute("SELECT * FROM mode_steps WHERE id = ?", (step_id,)).fetchone()
            if not step:
                return
            neighbor = connection.execute("SELECT * FROM mode_steps WHERE mode_id = ? AND position = ?", (step["mode_id"], step["position"] + direction)).fetchone()
            if neighbor:
                connection.execute("UPDATE mode_steps SET position = -1 WHERE id = ?", (step["id"],))
                connection.execute("UPDATE mode_steps SET position = ? WHERE id = ?", (step["position"], neighbor["id"]))
                connection.execute("UPDATE mode_steps SET position = ? WHERE id = ?", (neighbor["position"], step["id"]))

    def list_bridge_devices(self) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute("SELECT * FROM bridge_devices ORDER BY name COLLATE NOCASE").fetchall()
        return [self._bridge_device(row) for row in rows]

    def get_bridge_device_by_id(self, device_id: int) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute("SELECT * FROM bridge_devices WHERE id = ?", (device_id,)).fetchone()
        return self._bridge_device(row) if row else None

    def get_bridge_device_by_token_hash(self, token_hash: str) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute("SELECT * FROM bridge_devices WHERE token_hash = ?", (token_hash,)).fetchone()
        return self._bridge_device(row, include_hash=True) if row else None

    def save_bridge_device(
        self,
        name: str,
        configured_ip: str,
        additional_ips: list[str],
        auto_update_ip: bool,
        enabled: bool,
        token_hash: str | None = None,
        token_hint: str | None = None,
        device_id: int | None = None,
    ) -> int:
        with self.connection() as connection:
            if device_id is None:
                if not token_hash:
                    raise ValueError("token_hash obrigatório ao criar dispositivo")
                cursor = connection.execute(
                    "INSERT INTO bridge_devices(name, token_hash, token_hint, configured_ip, additional_ips_json, auto_update_ip, enabled) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (name, token_hash, token_hint or "", configured_ip, json.dumps(additional_ips), int(auto_update_ip), int(enabled)),
                )
                return int(cursor.lastrowid)
            if token_hash:
                connection.execute(
                    "UPDATE bridge_devices SET name=?, configured_ip=?, additional_ips_json=?, auto_update_ip=?, enabled=?, token_hash=?, token_hint=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (name, configured_ip, json.dumps(additional_ips), int(auto_update_ip), int(enabled), token_hash, token_hint or "", device_id),
                )
            else:
                connection.execute(
                    "UPDATE bridge_devices SET name=?, configured_ip=?, additional_ips_json=?, auto_update_ip=?, enabled=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (name, configured_ip, json.dumps(additional_ips), int(auto_update_ip), int(enabled), device_id),
                )
        return device_id

    def delete_bridge_device(self, device_id: int) -> None:
        with self.connection() as connection:
            connection.execute("DELETE FROM bridge_devices WHERE id = ?", (device_id,))

    def touch_bridge_device(self, device_id: int, client_ip: str, update_configured_ip: bool = False) -> None:
        with self.connection() as connection:
            if update_configured_ip:
                connection.execute(
                    "UPDATE bridge_devices SET last_ip=?, configured_ip=?, last_seen_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (client_ip, client_ip, device_id),
                )
            else:
                connection.execute(
                    "UPDATE bridge_devices SET last_ip=?, last_seen_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (client_ip, device_id),
                )

    def ensure_legacy_bridge_device(self, name: str, token_hash: str, token_hint: str, configured_ip: str) -> None:
        return

    def add_history(self, request_id: str, source: str, target_type: str, target_name: str) -> int:
        with self.connection() as connection:
            cursor = connection.execute("INSERT INTO execution_history(request_id, source, target_type, target_name) VALUES (?, ?, ?, ?)", (request_id, source, target_type, target_name))
            # Retencao simples e previsivel: mantem somente os 1.000 registros mais recentes.
            connection.execute(
                "DELETE FROM execution_history WHERE id NOT IN (SELECT id FROM execution_history ORDER BY id DESC LIMIT 1000)"
            )
            return int(cursor.lastrowid)

    def clear_history(self) -> None:
        with self.connection() as connection:
            connection.execute("DELETE FROM execution_history")

    def import_configuration(self, applications: list[dict[str, Any]], modes: list[dict[str, Any]]) -> None:
        """Importa uma configuracao ja validada em uma unica transacao, sem sobrescrever registros."""
        with self.connection() as connection:
            for application in applications:
                connection.execute(
                    "INSERT INTO applications(name, identifier, executable_path, process_name, arguments_json, enabled, close_policy) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        application["name"],
                        application["identifier"],
                        application["executable_path"],
                        application["process_name"],
                        json.dumps(application.get("arguments", [])),
                        int(application.get("enabled", True)),
                        application.get("close_policy", "safe"),
                    ),
                )

            for mode in modes:
                cursor = connection.execute(
                    "INSERT INTO modes(name, slug, enabled) VALUES (?, ?, ?)",
                    (mode["name"], mode["slug"], int(mode.get("enabled", True))),
                )
                mode_id = int(cursor.lastrowid)
                for position, step in enumerate(mode.get("steps", []), start=1):
                    connection.execute(
                        "INSERT INTO mode_steps(mode_id, position, action_type, parameters_json, enabled, timeout_seconds, on_error) VALUES (?, ?, ?, ?, ?, ?, ?)",
                        (
                            mode_id,
                            position,
                            step["action_type"],
                            json.dumps(step.get("parameters", {})),
                            int(step.get("enabled", True)),
                            int(step.get("timeout_seconds", 30)),
                            step.get("on_error", "stop"),
                        ),
                    )

    def finish_history(self, history_id: int, success: bool, duration_ms: int, details: dict[str, Any], error_message: str | None = None) -> None:
        with self.connection() as connection:
            connection.execute("UPDATE execution_history SET finished_at=CURRENT_TIMESTAMP, success=?, duration_ms=?, details_json=?, error_message=? WHERE id=?", (int(success), duration_ms, json.dumps(details), error_message, history_id))

    def recent_history(self, limit: int = 30) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute("SELECT * FROM execution_history ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _application(row: sqlite3.Row) -> dict[str, Any]:
        application = dict(row)
        application["arguments"] = json.loads(application.pop("arguments_json"))
        return application

    @staticmethod
    def _bridge_device(row: sqlite3.Row, include_hash: bool = False) -> dict[str, Any]:
        device = dict(row)
        try:
            device["additional_ips"] = json.loads(device.pop("additional_ips_json", "[]"))
        except (TypeError, json.JSONDecodeError):
            device["additional_ips"] = []
        device["auto_update_ip"] = bool(device.get("auto_update_ip"))
        device["enabled"] = bool(device.get("enabled"))
        if not include_hash:
            device.pop("token_hash", None)
        return device

    @staticmethod
    def _normalize_positions(connection: sqlite3.Connection, mode_id: int) -> None:
        rows = connection.execute("SELECT id FROM mode_steps WHERE mode_id = ? ORDER BY position", (mode_id,)).fetchall()
        for position, row in enumerate(rows, start=1):
            connection.execute("UPDATE mode_steps SET position = ? WHERE id = ?", (position, row["id"]))
