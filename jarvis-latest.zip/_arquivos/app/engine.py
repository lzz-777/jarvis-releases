from __future__ import annotations

import asyncio
import base64
import html
import os
import subprocess
import time
import uuid
from typing import Any

from .actions import ActionError, ActionRegistry
from .database import Database


def _notify_bridge_success(source: str, mode_name: str) -> None:
    """Dispara um toast do Windows sem bloquear nem afetar a automacao em caso de falha."""
    if os.name != "nt" or not source.startswith("bridge:"):
        return
    try:
        parts = source.split(":", 2)
        device_name = parts[1] if len(parts) > 1 and parts[1] else "Celular"
        client_ip = parts[2] if len(parts) > 2 else ""
        origin = f"{device_name} ({client_ip})" if client_ip else device_name
        message = f"Modo {mode_name} iniciado via {origin}"
        safe_message = html.escape(message, quote=True)
        toast_xml = f"<toast><visual><binding template='ToastGeneric'><text>Jarvis</text><text>{safe_message}</text></binding></visual></toast>"
        toast_xml_base64 = base64.b64encode(toast_xml.encode("utf-8")).decode("ascii")
        script = (
            "$ErrorActionPreference='Stop';"
            "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
            "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null;"
            f"$toastXml=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{toast_xml_base64}'));"
            "$xml=New-Object Windows.Data.Xml.Dom.XmlDocument;"
            "$xml.LoadXml($toastXml);"
            "$toast=[Windows.UI.Notifications.ToastNotification]::new($xml);"
            "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('Jarvis').Show($toast);"
        )
        encoded = base64.b64encode(script.encode("utf-16le")).decode("ascii")
        subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-EncodedCommand", encoded],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            close_fds=False,
        )
    except Exception:
        # Notificacao e apenas informativa; nunca pode derrubar ou alterar o resultado do comando.
        return


class ExecutionEngine:
    def __init__(self, database: Database, registry: ActionRegistry) -> None:
        self.database = database
        self.registry = registry
        self._lock = asyncio.Lock()
        self.current_mode: str | None = None
        self._completed_requests: dict[str, dict[str, Any]] = {}

    async def run_action(self, action: str, parameters: dict[str, Any], source: str, request_id: str | None = None) -> dict[str, Any]:
        request_id = request_id or str(uuid.uuid4())
        if request_id in self._completed_requests:
            return {**self._completed_requests[request_id], "duplicate": True}
        if self._lock.locked():
            raise ActionError("Outra automação está em execução.")
        async with self._lock:
            result = await self._execute_action(action, parameters, source, request_id)
            self._remember(request_id, result)
            return result

    async def run_mode(self, slug: str, source: str, request_id: str | None = None) -> dict[str, Any]:
        request_id = request_id or str(uuid.uuid4())
        if request_id in self._completed_requests:
            return {**self._completed_requests[request_id], "duplicate": True}
        if self._lock.locked():
            raise ActionError("Outra automação está em execução.")
        mode = self.database.get_mode(slug)
        if not mode or not mode["enabled"]:
            raise ActionError("Modo inexistente ou desativado.")
        async with self._lock:
            self.current_mode = mode["slug"]
            history_id = self.database.add_history(request_id, source, "mode", mode["slug"])
            started = time.monotonic()
            step_results: list[dict[str, Any]] = []
            success = True
            error_message: str | None = None
            try:
                for step in self.database.list_steps(mode["id"]):
                    if not step["enabled"]:
                        continue
                    try:
                        step_result = await asyncio.wait_for(self.registry.execute(step["action_type"], step["parameters"]), timeout=step["timeout_seconds"])
                        step_results.append({"step_id": step["id"], "action": step["action_type"], "success": True, "result": step_result})
                    except (ActionError, asyncio.TimeoutError) as error:
                        message = "Timeout da etapa." if isinstance(error, asyncio.TimeoutError) else str(error)
                        step_results.append({"step_id": step["id"], "action": step["action_type"], "success": False, "error": message})
                        success = False
                        if step["on_error"] == "stop":
                            error_message = message
                            break
                result = {"success": success, "mode": mode["slug"], "request_id": request_id, "steps": step_results}
                self.database.finish_history(history_id, success, int((time.monotonic() - started) * 1000), result, error_message)
                if success:
                    _notify_bridge_success(source, mode["name"])
                self._remember(request_id, result)
                return result
            finally:
                self.current_mode = None

    async def _execute_action(self, action: str, parameters: dict[str, Any], source: str, request_id: str) -> dict[str, Any]:
        history_id = self.database.add_history(request_id, source, "action", action)
        started = time.monotonic()
        try:
            action_result = await self.registry.execute(action, parameters)
            result = {"success": True, "action": action, "request_id": request_id, "result": action_result}
            self.database.finish_history(history_id, True, int((time.monotonic() - started) * 1000), result)
            return result
        except ActionError as error:
            result = {"success": False, "action": action, "request_id": request_id, "error": str(error)}
            self.database.finish_history(history_id, False, int((time.monotonic() - started) * 1000), result, str(error))
            return result

    def _remember(self, request_id: str, result: dict[str, Any]) -> None:
        self._completed_requests[request_id] = result
        if len(self._completed_requests) > 100:
            self._completed_requests.pop(next(iter(self._completed_requests)))
