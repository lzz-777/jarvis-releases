from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


PROJECT_DIR = Path(__file__).resolve().parents[1]


def _as_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _split_csv(value: str | None) -> tuple[str, ...]:
    if not value:
        return ()
    return tuple(part.strip() for part in value.split(",") if part.strip())


@dataclass(frozen=True)
class Settings:
    host: str
    port: int
    api_token: str
    dev_mode: bool
    database_path: Path
    bridge_enabled: bool = False
    bridge_host: str = "0.0.0.0"
    bridge_port: int = 9521
    bridge_token: str = ""
    bridge_allowed_clients: tuple[str, ...] = ()
    bridge_max_risk: str = "SAFE"
    bridge_rate_limit_per_minute: int = 30
    legacy_web_dashboard: bool = False

    @classmethod
    def from_environment(cls) -> "Settings":
        load_dotenv(PROJECT_DIR / ".env")
        database_value = os.getenv("JARVIS_DATABASE_PATH")
        database_path = Path(database_value) if database_value else PROJECT_DIR / "data" / "jarvis.db"
        max_risk = os.getenv("JARVIS_BRIDGE_MAX_RISK", "SAFE").strip().upper()
        if max_risk not in {"SAFE", "SENSITIVE", "DANGEROUS"}:
            max_risk = "SAFE"
        return cls(
            host=os.getenv("JARVIS_HOST", "127.0.0.1"),
            port=int(os.getenv("JARVIS_PORT", "9520")),
            api_token=os.getenv("JARVIS_API_TOKEN", ""),
            dev_mode=_as_bool(os.getenv("JARVIS_DEV_MODE"), True),
            database_path=database_path,
            bridge_enabled=_as_bool(os.getenv("JARVIS_BRIDGE_ENABLED"), False),
            bridge_host=os.getenv("JARVIS_BRIDGE_HOST", "0.0.0.0"),
            bridge_port=int(os.getenv("JARVIS_BRIDGE_PORT", "9521")),
            bridge_token=os.getenv("JARVIS_BRIDGE_TOKEN", ""),
            bridge_allowed_clients=_split_csv(os.getenv("JARVIS_BRIDGE_ALLOWED_CLIENTS")),
            bridge_max_risk=max_risk,
            bridge_rate_limit_per_minute=max(1, int(os.getenv("JARVIS_BRIDGE_RATE_LIMIT_PER_MINUTE", "30"))),
            legacy_web_dashboard=_as_bool(os.getenv("JARVIS_LEGACY_WEB_DASHBOARD"), False),
        )
