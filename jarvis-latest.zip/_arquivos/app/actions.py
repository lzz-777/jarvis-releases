from __future__ import annotations

import asyncio
import ntpath
import os
import subprocess
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable
from urllib.parse import urlparse

from .config import Settings
from .database import Database


class ActionError(Exception):
    pass


@dataclass(frozen=True)
class ActionDefinition:
    name: str
    risk: str
    description: str
    executor: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class ProcessManager:
    @staticmethod
    def is_running(process_name: str) -> bool:
        if not process_name:
            return False
        if os.name == "nt":
            result = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {process_name}", "/NH"], capture_output=True, text=True, check=False)
            return process_name.casefold() in result.stdout.casefold() and "no tasks" not in result.stdout.casefold()
        result = subprocess.run(["ps", "-A", "-o", "comm="], capture_output=True, text=True, check=False)
        return any(Path(line.strip()).name.casefold() == process_name.casefold() for line in result.stdout.splitlines())

    @staticmethod
    def stop(process_name: str) -> None:
        if os.name != "nt":
            raise ActionError("Fechar processos está disponível apenas no Windows.")
        result = subprocess.run(["taskkill", "/IM", process_name, "/F"], capture_output=True, text=True, check=False)
        if result.returncode != 0:
            raise ActionError("Não foi possível encerrar o processo configurado.")


class ActionRegistry:
    def __init__(self, database: Database, settings: Settings) -> None:
        self.database = database
        self.settings = settings
        self.actions: dict[str, ActionDefinition] = {}
        self._register_defaults()

    def describe(self) -> list[dict[str, str]]:
        return [{"name": action.name, "risk": action.risk, "description": action.description} for action in self.actions.values()]

    async def execute(self, action_name: str, parameters: dict[str, Any]) -> dict[str, Any]:
        action = self.actions.get(action_name)
        if not action:
            raise ActionError(f"Ação desconhecida: {action_name}")
        return await action.executor(parameters)

    def _register(self, name: str, risk: str, description: str, executor: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]) -> None:
        self.actions[name] = ActionDefinition(name, risk, description, executor)

    def _register_defaults(self) -> None:
        self._register("open_application", "SAFE", "Abre um aplicativo cadastrado.", self._open_application)
        self._register("close_application", "SENSITIVE", "Fecha o processo configurado de um aplicativo.", self._close_application)
        self._register("open_url", "SAFE", "Abre uma URL HTTP ou HTTPS no navegador padrão.", self._open_url)
        self._register("wait", "SAFE", "Aguarda por um intervalo definido.", self._wait)
        self._register("wait_process_start", "SAFE", "Espera um processo configurado iniciar.", self._wait_process_start)
        self._register("wait_process_exit", "SAFE", "Espera um processo configurado encerrar.", self._wait_process_exit)
        self._register("check_process", "SAFE", "Consulta se um processo configurado está ativo.", self._check_process)
        self._register("lock_pc", "SENSITIVE", "Bloqueia a sessão atual do Windows.", self._lock_pc)
        self._register("sleep_pc", "DANGEROUS", "Coloca o computador em suspensão.", self._system_action("sleep_pc"))
        self._register("restart_pc", "DANGEROUS", "Reinicia o computador.", self._system_action("restart_pc"))
        self._register("shutdown_pc", "DANGEROUS", "Desliga o computador.", self._system_action("shutdown_pc"))

    def _application(self, parameters: dict[str, Any]) -> dict[str, Any]:
        identifier = parameters.get("application")
        if not isinstance(identifier, str) or not identifier:
            raise ActionError("Informe o identificador de um aplicativo cadastrado.")
        application = self.database.get_application(identifier)
        if not application or not application["enabled"]:
            raise ActionError("Aplicativo inexistente ou desativado.")
        return application

    async def _open_application(self, parameters: dict[str, Any]) -> dict[str, Any]:
        application = self._application(parameters)
        if ProcessManager.is_running(application["process_name"]):
            return {"message": "Aplicativo já estava aberto.", "already_running": True}
        executable = Path(application["executable_path"])
        if not executable.is_file() or executable.suffix.casefold() != ".exe":
            raise ActionError("Executável não encontrado ou inválido.")
        executable_text = str(executable)
        working_directory = ntpath.dirname(executable_text) if "\\" in executable_text else str(executable.parent)
        try:
            subprocess.Popen(
                [executable_text, *application["arguments"]],
                cwd=working_directory,
                shell=False,
                close_fds=False,
            )
        except OSError as error:
            raise ActionError("Não foi possível iniciar o executável configurado.") from error
        return {"message": "Programa iniciado com sucesso.", "already_running": False}

    async def _close_application(self, parameters: dict[str, Any]) -> dict[str, Any]:
        application = self._application(parameters)
        if not ProcessManager.is_running(application["process_name"]):
            return {"message": "Aplicativo já estava fechado.", "already_running": False}
        ProcessManager.stop(application["process_name"])
        return {"message": "Solicitado encerramento do aplicativo."}

    async def _open_url(self, parameters: dict[str, Any]) -> dict[str, Any]:
        url = parameters.get("url")
        parsed = urlparse(url) if isinstance(url, str) else None
        if not parsed or parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ActionError("A URL deve usar HTTP ou HTTPS.")
        opened = webbrowser.open(url, new=2)
        if not opened:
            raise ActionError("O navegador padrão não aceitou a URL.")
        return {"message": "URL aberta no navegador padrão."}

    async def _wait(self, parameters: dict[str, Any]) -> dict[str, Any]:
        seconds = parameters.get("seconds")
        if not isinstance(seconds, (int, float)) or isinstance(seconds, bool) or not 0 <= seconds <= 3600:
            raise ActionError("O tempo de espera deve ser entre 0 e 3600 segundos.")
        await asyncio.sleep(seconds)
        return {"message": f"Aguardou {seconds} segundos."}

    async def _wait_process_start(self, parameters: dict[str, Any]) -> dict[str, Any]:
        return await self._wait_process(parameters, expected=True)

    async def _wait_process_exit(self, parameters: dict[str, Any]) -> dict[str, Any]:
        return await self._wait_process(parameters, expected=False)

    async def _wait_process(self, parameters: dict[str, Any], expected: bool) -> dict[str, Any]:
        application = self._application(parameters)
        timeout = parameters.get("timeout_seconds", 30)
        if not isinstance(timeout, int) or not 1 <= timeout <= 3600:
            raise ActionError("O timeout deve ser um inteiro entre 1 e 3600 segundos.")
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if ProcessManager.is_running(application["process_name"]) == expected:
                state = "iniciou" if expected else "encerrou"
                return {"message": f"Processo {state}."}
            await asyncio.sleep(0.5)
        state = "iniciar" if expected else "encerrar"
        raise ActionError(f"Timeout aguardando processo {state}.")

    async def _check_process(self, parameters: dict[str, Any]) -> dict[str, Any]:
        application = self._application(parameters)
        return {"running": ProcessManager.is_running(application["process_name"])}

    async def _lock_pc(self, parameters: dict[str, Any]) -> dict[str, Any]:
        if self.settings.dev_mode:
            return {"message": "Would execute lock_pc", "simulated": True}
        if os.name != "nt":
            raise ActionError("Bloqueio disponível apenas no Windows.")
        result = subprocess.run(["rundll32.exe", "user32.dll,LockWorkStation"], check=False)
        if result.returncode != 0:
            raise ActionError("Não foi possível bloquear o PC.")
        return {"message": "PC bloqueado."}

    def _system_action(self, action_name: str) -> Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]:
        async def execute(_: dict[str, Any]) -> dict[str, Any]:
            if self.settings.dev_mode:
                return {"message": f"Would execute {action_name}", "simulated": True}
            if os.name != "nt":
                raise ActionError("Ação de sistema disponível apenas no Windows.")
            commands = {
                "shutdown_pc": ["shutdown.exe", "/s", "/t", "0"],
                "restart_pc": ["shutdown.exe", "/r", "/t", "0"],
                "sleep_pc": ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"],
            }
            result = subprocess.run(commands[action_name], check=False)
            if result.returncode != 0:
                raise ActionError(f"Não foi possível executar {action_name}.")
            return {"message": f"Ação {action_name} enviada ao Windows."}
        return execute
