from __future__ import annotations

import hashlib
import hmac
import ipaddress
import time
from collections import defaultdict, deque
from typing import Any

import httpx
from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

from .config import Settings
from .database import Database


RISK_ORDER = {"SAFE": 0, "SENSITIVE": 1, "DANGEROUS": 2}


class BridgeRunRequest(BaseModel):
    request_id: str | None = Field(default=None, max_length=100)


class BridgeCommandRequest(BaseModel):
    command: str = Field(min_length=1, max_length=64)
    request_id: str | None = Field(default=None, max_length=100)


def _slugify(value: str) -> str:
    normalized = "".join(character.lower() if character.isalnum() else "-" for character in value.strip())
    return "-".join(part for part in normalized.split("-") if part)[:64]


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _client_allowed(client_ip: str, allowed_clients: tuple[str, ...]) -> bool:
    """Compatibilidade com a validacao antiga; novos acessos usam dispositivos cadastrados."""
    if not client_ip or not allowed_clients:
        return False
    if client_ip == "testclient":
        return "testclient" in allowed_clients
    try:
        ip = ipaddress.ip_address(client_ip)
    except ValueError:
        return False
    for entry in allowed_clients:
        try:
            if "/" in entry:
                if ip in ipaddress.ip_network(entry, strict=False):
                    return True
            elif ip == ipaddress.ip_address(entry):
                return True
        except ValueError:
            continue
    return False


def _private_client_ip(client_ip: str) -> bool:
    if client_ip == "testclient":
        return True
    try:
        ip = ipaddress.ip_address(client_ip)
    except ValueError:
        return False
    return bool(ip.is_private and not ip.is_loopback and not ip.is_multicast and not ip.is_unspecified)


def create_bridge_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings.from_environment()
    database = Database(settings.database_path)
    database.migrate()

    app = FastAPI(
        title="Jarvis Bridge Receiver",
        version="0.3.0",
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )
    bearer = HTTPBearer(auto_error=False)
    attempts: dict[int, deque[float]] = defaultdict(deque)

    def bridge_guard(
        request: Request,
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
    ) -> dict[str, Any]:
        if not settings.bridge_enabled:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bridge desativada.")

        supplied = credentials.credentials if credentials and credentials.scheme.lower() == "bearer" else ""
        if not supplied:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token da Bridge invalido.")

        device = database.get_bridge_device_by_token_hash(_token_hash(supplied))
        if not device or not device.get("enabled"):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token da Bridge invalido.")

        # Comparacao adicional evita aceitar um registro corrompido/inesperado.
        if not hmac.compare_digest(device.get("token_hash", ""), _token_hash(supplied)):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token da Bridge invalido.")

        client_ip = request.client.host if request.client else ""
        configured_ip = str(device.get("configured_ip") or "").strip()
        auto_update = bool(device.get("auto_update_ip"))

        if client_ip == "testclient":
            allowed = True
            should_update_ip = False
        elif configured_ip and client_ip == configured_ip:
            allowed = True
            should_update_ip = False
        elif auto_update and _private_client_ip(client_ip):
            allowed = True
            should_update_ip = True
        else:
            allowed = False
            should_update_ip = False

        if not allowed:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Dispositivo autenticado, mas o IP atual nao esta autorizado.",
            )

        database.touch_bridge_device(int(device["id"]), client_ip, update_configured_ip=should_update_ip)

        now = time.monotonic()
        bucket = attempts[int(device["id"])]
        while bucket and now - bucket[0] > 60:
            bucket.popleft()
        if len(bucket) >= settings.bridge_rate_limit_per_minute:
            raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Muitas requisicoes para a Bridge.")
        bucket.append(now)

        return {"device": device, "client_ip": client_ip}

    def internal_headers(principal: dict[str, Any] | None = None) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {settings.api_token}"}
        if principal:
            device_name = str(principal["device"].get("name") or "device").replace(":", "-")[:40]
            headers["X-Jarvis-Source"] = f"bridge:{device_name}:{principal['client_ip']}"
        return headers

    async def fetch_modes() -> list[dict[str, Any]]:
        if not settings.api_token:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Token interno do Agent nao configurado.")
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(
                    f"http://127.0.0.1:{settings.port}/api/v1/modes",
                    headers=internal_headers(),
                )
        except httpx.HTTPError as error:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Jarvis Agent local indisponivel.") from error
        if response.status_code != 200:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Jarvis Agent local rejeitou a consulta de modos.")
        return response.json()

    def mode_allowed(mode: dict[str, Any]) -> bool:
        if not mode.get("enabled") or not mode.get("valid", False):
            return False
        configured = RISK_ORDER.get(settings.bridge_max_risk, 0)
        mode_risk = RISK_ORDER.get(str(mode.get("max_risk", "DANGEROUS")), 99)
        return mode_risk <= configured

    async def run_mode(slug: str, principal: dict[str, Any], request_id: str | None) -> dict[str, Any]:
        modes = await fetch_modes()
        mode = next((item for item in modes if item.get("slug") == slug), None)
        if not mode:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Modo nao encontrado.")
        if not mode_allowed(mode):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Modo nao liberado para execucao remota. Risco maximo: {mode.get('max_risk', 'desconhecido')}.",
            )
        try:
            async with httpx.AsyncClient(timeout=300.0) as client:
                response = await client.post(
                    f"http://127.0.0.1:{settings.port}/api/v1/modes/{slug}/run",
                    headers=internal_headers(principal),
                    json={"request_id": request_id},
                )
        except httpx.HTTPError as error:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Jarvis Agent local indisponivel durante a execucao.") from error
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", "Falha ao executar o modo.")
            except ValueError:
                detail = "Falha ao executar o modo."
            raise HTTPException(status_code=response.status_code, detail=detail)
        return response.json()

    @app.get("/bridge/v1/health")
    async def health(principal: dict[str, Any] = Depends(bridge_guard)) -> dict[str, Any]:
        return {
            "status": "ok",
            "role": "pc_receiver",
            "device": principal["device"].get("name"),
        }

    @app.get("/bridge/v1/status")
    async def bridge_status(principal: dict[str, Any] = Depends(bridge_guard)) -> dict[str, Any]:
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(
                    f"http://127.0.0.1:{settings.port}/api/v1/status",
                    headers=internal_headers(principal),
                )
        except httpx.HTTPError as error:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Jarvis Agent local indisponivel.") from error
        if response.status_code != 200:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Jarvis Agent local indisponivel.")
        data = response.json()
        return {
            "status": "ok",
            "hostname": data.get("hostname"),
            "current_mode": data.get("current_mode"),
            "dev_mode": data.get("dev_mode"),
            "device": principal["device"].get("name"),
        }

    @app.get("/bridge/v1/modes")
    async def bridge_modes(_: dict[str, Any] = Depends(bridge_guard)) -> list[dict[str, Any]]:
        modes = await fetch_modes()
        return [
            {
                "name": mode.get("name"),
                "slug": mode.get("slug"),
                "step_count": mode.get("step_count"),
                "max_risk": mode.get("max_risk"),
            }
            for mode in modes
            if mode_allowed(mode)
        ]

    @app.post("/bridge/v1/modes/{mode_slug}/run")
    async def bridge_run_mode(
        mode_slug: str,
        payload: BridgeRunRequest,
        principal: dict[str, Any] = Depends(bridge_guard),
    ) -> dict[str, Any]:
        slug = _slugify(mode_slug)
        if not slug:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Modo invalido.")
        return await run_mode(slug, principal, payload.request_id)

    @app.post("/bridge/v1/command")
    async def bridge_command(
        payload: BridgeCommandRequest,
        principal: dict[str, Any] = Depends(bridge_guard),
    ) -> dict[str, Any]:
        slug = _slugify(payload.command)
        if not slug:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Comando invalido.")
        return await run_mode(slug, principal, payload.request_id)

    return app


app = create_bridge_app()
