param([switch]$Update)

$ErrorActionPreference = 'Stop'

$packageDir = Split-Path -Parent $PSCommandPath
$installDir = Join-Path $env:LOCALAPPDATA 'Programs\Jarvis'
$tempBackup = Join-Path $env:TEMP ('Jarvis-Migracao-' + [guid]::NewGuid().ToString('N'))
$appVersion = '5.5.0'

Write-Host ''
Write-Host '=== Instalador do Jarvis ===' -ForegroundColor Cyan
Write-Host "Destino: $installDir"
Write-Host ''

function Get-ShortcutTargetDirectory {
    $shell = New-Object -ComObject WScript.Shell
    $links = @(
        (Join-Path ([Environment]::GetFolderPath('Startup')) 'Jarvis.lnk'),
        (Join-Path ([Environment]::GetFolderPath('Startup')) 'Jarvis Agent.lnk'),
        (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Jarvis.lnk'),
        (Join-Path ([Environment]::GetFolderPath('Programs')) 'Jarvis.lnk')
    )
    foreach ($link in $links) {
        if (-not (Test-Path -LiteralPath $link)) { continue }
        try {
            $shortcut = $shell.CreateShortcut($link)
            if ($shortcut.TargetPath) {
                if ([IO.Path]::GetFileName($shortcut.TargetPath) -ieq 'Jarvis.exe') {
                    return (Split-Path -Parent $shortcut.TargetPath)
                }
                if ([IO.Path]::GetFileName($shortcut.TargetPath) -ieq 'wscript.exe' -and $shortcut.Arguments) {
                    $m = [regex]::Match($shortcut.Arguments, '"([^"]+)"')
                    if ($m.Success -and (Test-Path -LiteralPath $m.Groups[1].Value)) {
                        return (Split-Path -Parent $m.Groups[1].Value)
                    }
                }
            }
        } catch { }
    }
    return $null
}

function Stop-JarvisListener {
    param([int]$Port)
    try {
        $connections = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
        foreach ($connection in @($connections)) {
            if (-not $connection.OwningProcess -or $connection.OwningProcess -eq $PID) { continue }
            try {
                $proc = Get-CimInstance Win32_Process -Filter "ProcessId = $($connection.OwningProcess)" -ErrorAction SilentlyContinue
                if ($proc -and $proc.CommandLine -and $proc.CommandLine -match 'run\.py' -and $proc.CommandLine -match 'jarvis') {
                    Stop-Process -Id $connection.OwningProcess -Force -ErrorAction SilentlyContinue
                }
            } catch { }
        }
    } catch { }
}

function Stop-AllJarvis {
    Get-Process -Name 'Jarvis' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Get-Process -Name 'jarvis-dashboard' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Stop-JarvisListener -Port 9520
    Stop-JarvisListener -Port 9521
    Stop-JarvisListener -Port 8765
    Stop-JarvisListener -Port 8766
    try {
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -and $_.CommandLine -match 'run\.py' -and $_.CommandLine -match 'jarvis' } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch { }
}

function Get-JarvisListeningPids {
    $pids = @()
    try {
        $pids = @(
            Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
                Where-Object { $_.LocalPort -in @(9520, 9521, 8765, 8766) } |
                Select-Object -ExpandProperty OwningProcess -Unique
        )
    } catch { }

    if ($pids.Count -eq 0) {
        try {
            $lines = @(netstat -ano -p TCP 2>$null)
            foreach ($line in $lines) {
                if ($line -match '^\s*TCP\s+\S+:(9520|9521|8765|8766)\s+\S+\s+LISTENING\s+(\d+)\s*$') {
                    $pids += [int]$matches[2]
                }
            }
        } catch { }
    }

    return @($pids | Where-Object { $_ -and $_ -ne $PID } | Select-Object -Unique)
}

function Wait-JarvisPortsFree {
    param([int]$TimeoutSeconds = 12)

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        Stop-JarvisListener -Port 9520
        Stop-JarvisListener -Port 9521
        Stop-JarvisListener -Port 8765
        Stop-JarvisListener -Port 8766
        $busy = @(Get-JarvisListeningPids)
        if ($busy.Count -eq 0) { return }
        Start-Sleep -Milliseconds 500
    } while ((Get-Date) -lt $deadline)

    $details = @()
    foreach ($busyPid in @(Get-JarvisListeningPids)) {
        try {
            $proc = Get-CimInstance Win32_Process -Filter "ProcessId = $busyPid" -ErrorAction SilentlyContinue
            if ($proc) {
                $details += "PID $busyPid - $($proc.Name) - $($proc.CommandLine)"
            } else {
                $details += "PID $busyPid"
            }
        } catch {
            $details += "PID $busyPid"
        }
    }

    throw ("As portas do Jarvis continuam ocupadas por outro processo. O instalador foi interrompido.`r`n" + ($details -join "`r`n"))
}

function Find-PythonLauncher {
    $candidates = @(
        @{ Exe = 'py.exe'; Prefix = @('-3') },
        @{ Exe = 'python.exe'; Prefix = @() }
    )
    foreach ($candidate in $candidates) {
        try {
            $cmd = Get-Command $candidate.Exe -ErrorAction Stop
            $version = & $cmd.Source @($candidate.Prefix) -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
            if ($LASTEXITCODE -ne 0 -or -not $version) { continue }
            $parts = $version.Trim().Split('.')
            if ([int]$parts[0] -gt 3 -or ([int]$parts[0] -eq 3 -and [int]$parts[1] -ge 11)) {
                return @{ Exe = $cmd.Source; Prefix = @($candidate.Prefix) }
            }
        } catch { }
    }
    return $null
}

function New-RandomToken {
    $bytes = New-Object byte[] 32
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return (($bytes | ForEach-Object { $_.ToString('x2') }) -join '')
}

function Get-JarvisEnvValue {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Name,
        [string]$Default = ''
    )
    if (Test-Path -LiteralPath $Path) {
        $lines = @(Get-Content -LiteralPath $Path)
        foreach ($line in $lines) {
            $t = $line.Trim()
            if ($t.StartsWith("$Name=")) {
                return $t.Substring("$Name=".Length).Trim()
            }
        }
    }
    return $Default
}

function Set-JarvisEnvValue {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$Value
    )
    $content = ''
    if (Test-Path -LiteralPath $Path) {
        $content = Get-Content -LiteralPath $Path -Raw
    }
    $pattern = '(?m)^' + [regex]::Escape($Name) + '=.*$'
    $line = $Name + '=' + $Value
    if ($content -match $pattern) {
        $content = [regex]::Replace($content, $pattern, $line)
    } else {
        if ($content -and -not $content.EndsWith("`n")) { $content += "`r`n" }
        $content += $line + "`r`n"
    }
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $content, $utf8NoBom)
}

function New-JarvisShortcut {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ExePath,
        [string]$Arguments = ''
    )
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = $ExePath
    $shortcut.Arguments = $Arguments
    $shortcut.WorkingDirectory = $installDir
    $shortcut.IconLocation = "$ExePath,0"
    $shortcut.Description = 'Jarvis'
    $shortcut.Save()
}

# Descobre a instalação antiga ANTES de trocar os atalhos, para preservar dados do usuário.
# Além do registro/atalho, cobre a pasta usada pelas versões antigas em Downloads.
$oldDir = $null
$candidates = New-Object System.Collections.Generic.List[string]
try {
    $reg = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Jarvis' -ErrorAction SilentlyContinue
    if ($reg -and $reg.InstallLocation) { $candidates.Add([string]$reg.InstallLocation) }
} catch { }
$shortcutDir = Get-ShortcutTargetDirectory
if ($shortcutDir) { $candidates.Add([string]$shortcutDir) }
$candidates.Add([string]$installDir)
$candidates.Add((Join-Path $env:USERPROFILE 'Downloads\jarvis'))
$candidates.Add((Join-Path $env:USERPROFILE 'Documents\jarvis'))

foreach ($candidate in $candidates) {
    if (-not $candidate -or -not (Test-Path -LiteralPath $candidate)) { continue }
    $hasEnv = Test-Path -LiteralPath (Join-Path $candidate '.env')
    $hasDb = Test-Path -LiteralPath (Join-Path $candidate 'data\jarvis.db')
    if ($hasEnv -or $hasDb) {
        $oldDir = $candidate
        break
    }
}

Stop-AllJarvis
Wait-JarvisPortsFree

New-Item -ItemType Directory -Force -Path $tempBackup | Out-Null
if ($oldDir -and (Test-Path -LiteralPath $oldDir)) {
    $oldEnv = Join-Path $oldDir '.env'
    $oldDb = Join-Path $oldDir 'data\jarvis.db'
    if (Test-Path -LiteralPath $oldEnv) { Copy-Item -LiteralPath $oldEnv -Destination (Join-Path $tempBackup '.env') -Force }
    if (Test-Path -LiteralPath $oldDb) { Copy-Item -LiteralPath $oldDb -Destination (Join-Path $tempBackup 'jarvis.db') -Force }
}

# Backup opcional criado pelo desinstalador também pode ser restaurado automaticamente.
$uninstallBackup = Join-Path $env:LOCALAPPDATA 'Jarvis\Backup'
if (-not (Test-Path -LiteralPath (Join-Path $tempBackup '.env')) -and (Test-Path -LiteralPath (Join-Path $uninstallBackup '.env'))) {
    Copy-Item -LiteralPath (Join-Path $uninstallBackup '.env') -Destination (Join-Path $tempBackup '.env') -Force
}
if (-not (Test-Path -LiteralPath (Join-Path $tempBackup 'jarvis.db')) -and (Test-Path -LiteralPath (Join-Path $uninstallBackup 'jarvis.db'))) {
    Copy-Item -LiteralPath (Join-Path $uninstallBackup 'jarvis.db') -Destination (Join-Path $tempBackup 'jarvis.db') -Force
}

New-Item -ItemType Directory -Force -Path $installDir | Out-Null

# Limpa somente arquivos do programa. Configuração migrada já está segura em $tempBackup.
Get-ChildItem -LiteralPath $installDir -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $installDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $installDir 'data') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $installDir 'logs') | Out-Null

Write-Host 'Copiando arquivos essenciais...' -ForegroundColor Yellow
Copy-Item -LiteralPath (Join-Path $packageDir 'app') -Destination (Join-Path $installDir 'app') -Recurse -Force
Copy-Item -LiteralPath (Join-Path $packageDir 'run.py') -Destination (Join-Path $installDir 'run.py') -Force
Copy-Item -LiteralPath (Join-Path $packageDir 'requirements.txt') -Destination (Join-Path $installDir 'requirements.txt') -Force
Copy-Item -LiteralPath (Join-Path $packageDir 'jarvis.ico') -Destination (Join-Path $installDir 'jarvis.ico') -Force
Copy-Item -LiteralPath (Join-Path $packageDir 'desinstalar.ps1') -Destination (Join-Path $installDir 'desinstalar.ps1') -Force
Copy-Item -LiteralPath (Join-Path $packageDir 'atualizar.ps1') -Destination (Join-Path $installDir 'atualizar.ps1') -Force

if (Test-Path -LiteralPath (Join-Path $tempBackup '.env')) {
    Copy-Item -LiteralPath (Join-Path $tempBackup '.env') -Destination (Join-Path $installDir '.env') -Force
} else {
    $envText = Get-Content -LiteralPath (Join-Path $packageDir '.env.example') -Raw
    $envText = $envText.Replace('replace-with-a-long-random-local-token', (New-RandomToken))
    $envText = $envText.Replace('replace-with-a-different-long-random-bridge-token', (New-RandomToken))
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText((Join-Path $installDir '.env'), $envText, $utf8NoBom)
}
if (Test-Path -LiteralPath (Join-Path $tempBackup 'jarvis.db')) {
    Copy-Item -LiteralPath (Join-Path $tempBackup 'jarvis.db') -Destination (Join-Path $installDir 'data\jarvis.db') -Force
}

$installedEnv = Join-Path $installDir '.env'
$currentPort = Get-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_PORT' -Default '9520'
$currentBridgePort = Get-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_BRIDGE_PORT' -Default '9521'
Set-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_HOST' -Value '127.0.0.1'
Set-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_PORT' -Value $currentPort
Set-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_BRIDGE_ENABLED' -Value 'true'
Set-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_BRIDGE_HOST' -Value '0.0.0.0'
Set-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_BRIDGE_PORT' -Value $currentBridgePort
Set-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_BRIDGE_ALLOWED_CLIENTS' -Value ''

$python = Find-PythonLauncher
if (-not $python) {
    throw 'Python 3.11 ou mais recente não foi encontrado. Instale o Python para Windows e execute o instalador novamente.'
}

$venvDir = Join-Path $installDir '.venv'
Write-Host 'Criando ambiente Python do Jarvis...' -ForegroundColor Yellow
& $python.Exe @($python.Prefix) -m venv $venvDir
if ($LASTEXITCODE -ne 0) { throw 'Falha ao criar o ambiente Python do Jarvis.' }
$venvPython = Join-Path $venvDir 'Scripts\python.exe'

Write-Host 'Instalando dependências...' -ForegroundColor Yellow
& $venvPython -m pip install --disable-pip-version-check --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'Falha ao atualizar o pip.' }
& $venvPython -m pip install --disable-pip-version-check -r (Join-Path $installDir 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar as dependências do Jarvis. Verifique sua conexão com a internet.' }

$exePath = Join-Path $installDir 'Jarvis.exe'
$dashboardExePath = Join-Path $installDir 'jarvis-dashboard.exe'
$iconPath = Join-Path $installDir 'jarvis.ico'

Write-Host 'Criando Jarvis.exe...' -ForegroundColor Yellow
$provider = New-Object Microsoft.CSharp.CSharpCodeProvider
$parameters = New-Object System.CodeDom.Compiler.CompilerParameters
$parameters.GenerateExecutable = $true
$parameters.GenerateInMemory = $false
$parameters.OutputAssembly = $exePath
$parameters.CompilerOptions = '/target:winexe /optimize+'
$parameters.CompilerOptions += " /win32icon:`"$iconPath`""
[void]$parameters.ReferencedAssemblies.Add('System.dll')
[void]$parameters.ReferencedAssemblies.Add('System.Core.dll')
[void]$parameters.ReferencedAssemblies.Add('System.Drawing.dll')
[void]$parameters.ReferencedAssemblies.Add('System.Windows.Forms.dll')
[void]$parameters.ReferencedAssemblies.Add('System.Web.Extensions.dll')
[void]$parameters.ReferencedAssemblies.Add('Microsoft.CSharp.dll')
$result = $provider.CompileAssemblyFromFile($parameters, (Join-Path $packageDir 'jarvis_app.cs'))
if ($result.Errors.HasErrors) {
    $messages = @($result.Errors | ForEach-Object { "Linha $($_.Line): $($_.ErrorText)" }) -join "`r`n"
    throw "Falha ao criar Jarvis.exe:`r`n$messages"
}

Write-Host 'Criando Dashboard...' -ForegroundColor Yellow
$dashboardProvider = New-Object Microsoft.CSharp.CSharpCodeProvider
$dashboardParameters = New-Object System.CodeDom.Compiler.CompilerParameters
$dashboardParameters.GenerateExecutable = $true
$dashboardParameters.GenerateInMemory = $false
$dashboardParameters.OutputAssembly = $dashboardExePath
$dashboardParameters.CompilerOptions = '/target:winexe /optimize+'
$dashboardParameters.CompilerOptions += " /win32icon:`"$iconPath`""
[void]$dashboardParameters.ReferencedAssemblies.Add('System.dll')
[void]$dashboardParameters.ReferencedAssemblies.Add('System.Core.dll')
[void]$dashboardParameters.ReferencedAssemblies.Add('System.Drawing.dll')
[void]$dashboardParameters.ReferencedAssemblies.Add('System.Windows.Forms.dll')
[void]$dashboardParameters.ReferencedAssemblies.Add('System.Web.Extensions.dll')
$dashboardResult = $dashboardProvider.CompileAssemblyFromFile($dashboardParameters, (Join-Path $packageDir 'native_dashboard.cs'))
if ($dashboardResult.Errors.HasErrors) {
    $messages = @($dashboardResult.Errors | ForEach-Object { "Linha $($_.Line): $($_.ErrorText)" }) -join "`r`n"
    throw "Falha ao criar o Dashboard:`r`n$messages"
}

# Atalhos antigos e novos.
$startup = [Environment]::GetFolderPath('Startup')
$desktop = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')
foreach ($file in @('Jarvis Agent.lnk','Jarvis.lnk')) {
    $p = Join-Path $startup $file
    if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue }
}
New-JarvisShortcut -Path (Join-Path $startup 'Jarvis.lnk') -ExePath $exePath -Arguments '--startup'
New-JarvisShortcut -Path (Join-Path $desktop 'Jarvis.lnk') -ExePath $exePath
New-JarvisShortcut -Path (Join-Path $programs 'Jarvis.lnk') -ExePath $exePath

# Entrada real de desinstalação no Windows (Configurações > Aplicativos instalados).
$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Jarvis'
New-Item -Path $uninstallKey -Force | Out-Null
Set-ItemProperty -Path $uninstallKey -Name 'DisplayName' -Value 'Jarvis'
Set-ItemProperty -Path $uninstallKey -Name 'DisplayVersion' -Value $appVersion
Set-ItemProperty -Path $uninstallKey -Name 'Publisher' -Value 'Jarvis'
Set-ItemProperty -Path $uninstallKey -Name 'InstallLocation' -Value $installDir
Set-ItemProperty -Path $uninstallKey -Name 'DisplayIcon' -Value "$exePath,0"
Set-ItemProperty -Path $uninstallKey -Name 'NoModify' -Value 1 -Type DWord
Set-ItemProperty -Path $uninstallKey -Name 'NoRepair' -Value 1 -Type DWord
$uninstallCmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $installDir 'desinstalar.ps1')`""
Set-ItemProperty -Path $uninstallKey -Name 'UninstallString' -Value $uninstallCmd
Set-ItemProperty -Path $uninstallKey -Name 'QuietUninstallString' -Value ($uninstallCmd + ' -Silent')
Set-ItemProperty -Path $uninstallKey -Name 'InstallDate' -Value (Get-Date -Format 'yyyyMMdd')

# Valida o Agent antes de abrir o gerenciador da bandeja. Se algo estiver errado, o instalador
# para aqui com uma mensagem em vez de deixar o Jarvis reiniciando em loop silenciosamente.
Write-Host 'Validando Agent e Bridge...' -ForegroundColor Yellow
Wait-JarvisPortsFree
$valPort = [int](Get-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_PORT' -Default '9520')
$valBridgePort = [int](Get-JarvisEnvValue -Path $installedEnv -Name 'JARVIS_BRIDGE_PORT' -Default '9521')
$pythonw = Join-Path $venvDir 'Scripts\pythonw.exe'
$agentExe = if (Test-Path -LiteralPath $pythonw) { $pythonw } else { $venvPython }
$agentProcess = Start-Process -FilePath $agentExe -ArgumentList ('"' + (Join-Path $installDir 'run.py') + '"') -WorkingDirectory $installDir -WindowStyle Hidden -PassThru
$ready = $false
$deadline = (Get-Date).AddSeconds(15)
do {
    Start-Sleep -Milliseconds 350
    if ($agentProcess.HasExited) { break }

    $healthOk = $false
    try {
        $health = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$valPort/api/v1/health" -TimeoutSec 1
        $healthOk = ($health.StatusCode -eq 200)
    } catch { }

    $bridgeOk = $false
    try {
        $bridgeOk = [bool](Get-NetTCPConnection -LocalPort $valBridgePort -State Listen -ErrorAction SilentlyContinue)
    } catch {
        try {
            $bridgeOk = [bool](@(netstat -ano -p TCP 2>$null) | Where-Object { $_ -match "^\s*TCP\s+\S+:$valBridgePort\s+\S+\s+LISTENING\s+\d+\s*$" } | Select-Object -First 1)
        } catch { }
    }

    if ($healthOk -and $bridgeOk) {
        $ready = $true
        break
    }
} while ((Get-Date) -lt $deadline)

if (-not $ready) {
    try { if (-not $agentProcess.HasExited) { Stop-Process -Id $agentProcess.Id -Force -ErrorAction SilentlyContinue } } catch { }
    $logTail = ''
    $agentLog = Join-Path $installDir 'logs\agent.log'
    if (Test-Path -LiteralPath $agentLog) {
        try { $logTail = (@(Get-Content -LiteralPath $agentLog -Tail 14) -join "`r`n") } catch { }
    }
    throw ("O Agent/Bridge não ficou pronto após a instalação. O Jarvis NÃO será iniciado em loop. Verifique o erro abaixo:`r`n`r`n" + $logTail)
}

Remove-Item -LiteralPath $tempBackup -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ''
Write-Host ($(if ($Update) { "Jarvis atualizado para $appVersion e validado com sucesso." } else { "Jarvis $appVersion instalado e validado com sucesso." })) -ForegroundColor Green
Write-Host "Agent local: 127.0.0.1:$valPort | Bridge: 0.0.0.0:$valBridgePort" -ForegroundColor Green
Write-Host 'Ele aparece em Configurações > Aplicativos instalados e pode ser desinstalado normalmente.' -ForegroundColor Green
Write-Host 'Seus aplicativos, modos, dispositivos e tokens anteriores foram preservados quando encontrados.' -ForegroundColor Green
Write-Host ''
Start-Process -FilePath $exePath -WorkingDirectory $installDir
