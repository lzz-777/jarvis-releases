﻿param(
    [string]$InstallDir = '',
    [switch]$TempCopy,
    [switch]$Silent
)
$ErrorActionPreference = 'SilentlyContinue'
$firewallRuleName = 'Jarvis Bridge (Rede Privada)'

if (-not $InstallDir) { $InstallDir = Split-Path -Parent $PSCommandPath }

# Executa a remoção a partir do TEMP para conseguir apagar a própria pasta do Jarvis.
if (-not $TempCopy) {
    $tempScript = Join-Path $env:TEMP ('Jarvis-Uninstall-' + [guid]::NewGuid().ToString('N') + '.ps1')
    Copy-Item -LiteralPath $PSCommandPath -Destination $tempScript -Force
    $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$tempScript,'-InstallDir',$InstallDir,'-TempCopy')
    if ($Silent) { $args += '-Silent' }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $args
    exit
}

if (-not $Silent) {
    Write-Host ''
    Write-Host '=== Desinstalar Jarvis ===' -ForegroundColor Cyan
    $keep = Read-Host 'Deseja manter seus aplicativos, modos e dispositivos para uma futura reinstalacao? [S/N]'
} else {
    $keep = 'N'
}

Get-Process -Name 'Jarvis' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Get-Process -Name 'jarvis-dashboard' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -and $_.CommandLine -like "*$InstallDir*" -and $_.CommandLine -match 'run\.py' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch { }
Start-Sleep -Milliseconds 700

$startup = [Environment]::GetFolderPath('Startup')
$desktop = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')
foreach ($path in @(
    (Join-Path $startup 'Jarvis.lnk'),
    (Join-Path $startup 'Jarvis Agent.lnk'),
    (Join-Path $desktop 'Jarvis.lnk'),
    (Join-Path $programs 'Jarvis.lnk')
)) {
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force }
}

if ($keep -match '^[sSyY]') {
    $backup = Join-Path $env:LOCALAPPDATA 'Jarvis\Backup'
    New-Item -ItemType Directory -Force -Path $backup | Out-Null
    if (Test-Path -LiteralPath (Join-Path $InstallDir '.env')) {
        Copy-Item -LiteralPath (Join-Path $InstallDir '.env') -Destination (Join-Path $backup '.env') -Force
    }
    if (Test-Path -LiteralPath (Join-Path $InstallDir 'data\jarvis.db')) {
        Copy-Item -LiteralPath (Join-Path $InstallDir 'data\jarvis.db') -Destination (Join-Path $backup 'jarvis.db') -Force
    }
    if (-not $Silent) { Write-Host "Backup salvo em: $backup" -ForegroundColor Yellow }
}

Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Jarvis' -Recurse -Force -ErrorAction SilentlyContinue

# A regra aponta somente para o executavel exclusivo do Jarvis. Tenta remove-la sem impedir a desinstalacao se o UAC for cancelado.
$ruleNameEncoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($firewallRuleName))
$removeFirewallScript = "`$ruleName=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('$ruleNameEncoded')); Get-NetFirewallRule -DisplayName `$ruleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule"
$removeFirewallEncoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($removeFirewallScript))
try {
    if ($Silent) {
        powershell.exe -NoProfile -NonInteractive -EncodedCommand $removeFirewallEncoded 2>$null
    } else {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoProfile','-NonInteractive','-EncodedCommand',$removeFirewallEncoded) -WindowStyle Hidden -Wait | Out-Null
    }
} catch { }

# Tenta remover a pasta algumas vezes para aguardar processos encerrarem.
for ($i=0; $i -lt 8; $i++) {
    if (-not (Test-Path -LiteralPath $InstallDir)) { break }
    Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
}

if (-not $Silent) {
    Write-Host ''
    if (Test-Path -LiteralPath $InstallDir) {
        Write-Host 'O Jarvis foi removido, mas algum arquivo ainda esta em uso. Reinicie o Windows e apague a pasta restante:' -ForegroundColor Yellow
        Write-Host $InstallDir
    } else {
        Write-Host 'Jarvis desinstalado.' -ForegroundColor Green
    }
    Write-Host ''
    Read-Host 'Pressione Enter para fechar'
}
Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue
