param(
    [Parameter(Mandatory=$true)][string]$ManifestUrl,
    [Parameter(Mandatory=$true)][string]$ExpectedVersion,
    [Parameter(Mandatory=$true)][string]$ExpectedSha256
)

$ErrorActionPreference = 'Stop'
$allowedPrefix = 'https://raw.githubusercontent.com/lzz-777/jarvis-releases/main/'
$workDir = Join-Path $env:TEMP ('Jarvis-Update-' + [guid]::NewGuid().ToString('N'))
$logDir = Join-Path $env:LOCALAPPDATA 'Jarvis'
$logFile = Join-Path $logDir 'update.log'

function Write-UpdateLog {
    param([string]$Message)
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Message) -Encoding UTF8
}

try {
    if (-not $ManifestUrl.StartsWith($allowedPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Origem do manifesto de atualização não autorizada.'
    }

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    New-Item -ItemType Directory -Force -Path $workDir | Out-Null
    $manifestPath = Join-Path $workDir 'version.json'
    $packagePath = Join-Path $workDir 'jarvis-update.zip'
    $extractDir = Join-Path $workDir 'package'

    Write-UpdateLog "Baixando manifesto da versão $ExpectedVersion."
    Invoke-WebRequest -UseBasicParsing -Uri $ManifestUrl -OutFile $manifestPath -TimeoutSec 20
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $downloadUrl = [string]$manifest.download_url
    $publishedVersion = [string]$manifest.version
    $publishedSha256 = ([string]$manifest.sha256).Trim().ToUpperInvariant()

    if ($publishedVersion -ne $ExpectedVersion -or $publishedSha256 -ne $ExpectedSha256.Trim().ToUpperInvariant()) {
        throw 'O manifesto mudou durante a atualização. Verifique novamente pelo Jarvis.'
    }
    if (-not $downloadUrl.StartsWith($allowedPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Origem do pacote de atualização não autorizada.'
    }
    if ($publishedSha256 -notmatch '^[0-9A-F]{64}$') {
        throw 'SHA-256 publicado é inválido.'
    }

    Write-UpdateLog "Baixando pacote da versão $ExpectedVersion."
    Invoke-WebRequest -UseBasicParsing -Uri $downloadUrl -OutFile $packagePath -TimeoutSec 120
    $actualSha256 = (Get-FileHash -LiteralPath $packagePath -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($actualSha256 -ne $publishedSha256) {
        throw 'O pacote baixado não corresponde ao SHA-256 publicado.'
    }

    Expand-Archive -LiteralPath $packagePath -DestinationPath $extractDir -Force
    $installer = Join-Path $extractDir '_arquivos\instalar.ps1'
    if (-not (Test-Path -LiteralPath $installer)) {
        throw 'O pacote não contém o instalador esperado.'
    }

    Write-UpdateLog "Pacote verificado. Iniciando instalação da versão $ExpectedVersion."
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -Update
    if ($LASTEXITCODE -ne 0) {
        throw "O instalador terminou com o código $LASTEXITCODE."
    }
    Write-UpdateLog "Atualização para $ExpectedVersion concluída."
}
catch {
    Write-UpdateLog ('Falha: ' + $_.Exception.Message)
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show(
        "Não foi possível atualizar o Jarvis.`r`n`r`n$($_.Exception.Message)`r`n`r`nDetalhes: $logFile",
        'Jarvis - Atualização',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}
finally {
    if (Test-Path -LiteralPath $workDir) {
        Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
