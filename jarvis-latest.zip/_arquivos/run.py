from __future__ import annotations

import atexit
import logging
import os
import sys
import threading
import time
import socket
from logging.handlers import RotatingFileHandler
from pathlib import Path

import uvicorn

from app.bridge import create_bridge_app
from app.config import Settings
from app.main import create_app
from zeroconf import ServiceInfo, Zeroconf


PROJECT_DIR = Path(__file__).resolve().parent
LOG_DIR = PROJECT_DIR / "logs"
LOG_FILE = LOG_DIR / "agent.log"
PID_FILE = PROJECT_DIR / "data" / "jarvis.pid"


def local_lan_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
            client.connect(("8.8.8.8", 80))
            return client.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def advertise_bridge(settings: Settings) -> None:
    """Anuncia nome e porta na LAN e se atualiza quando o notebook muda de rede."""
    service_type = "_jarvis._tcp.local."
    server_name = f"{settings.instance_name}.local."
    zeroconf = Zeroconf()
    current: ServiceInfo | None = None
    current_ip = ""
    try:
        while True:
            detected_ip = local_lan_ip()
            if detected_ip != "127.0.0.1" and detected_ip != current_ip:
                if current is not None:
                    zeroconf.unregister_service(current)
                current = ServiceInfo(
                    service_type,
                    f"{settings.instance_name}.{service_type}",
                    addresses=[socket.inet_aton(detected_ip)],
                    port=settings.bridge_port,
                    properties={"id": settings.instance_id, "name": settings.instance_name},
                    server=server_name,
                )
                zeroconf.register_service(current, allow_name_change=False)
                current_ip = detected_ip
            time.sleep(10)
    except Exception:
        logging.getLogger("jarvis.discovery").exception("Descoberta local indisponivel.")
    finally:
        if current is not None:
            try:
                zeroconf.unregister_service(current)
            except Exception:
                pass
        zeroconf.close()


def configure_logging() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    handlers: list[logging.Handler] = [file_handler]
    # Quando executado manualmente pelo PowerShell, manter os logs visíveis também.
    if getattr(sys, "stderr", None) is not None:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        handlers.append(console_handler)

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(logging.INFO)
    for handler in handlers:
        root.addHandler(handler)

    for logger_name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        logger = logging.getLogger(logger_name)
        logger.handlers.clear()
        logger.propagate = True
        logger.setLevel(logging.INFO)


def write_pid_file() -> None:
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()), encoding="ascii")

    def cleanup() -> None:
        try:
            if PID_FILE.exists() and PID_FILE.read_text(encoding="ascii").strip() == str(os.getpid()):
                PID_FILE.unlink()
        except OSError:
            pass

    atexit.register(cleanup)


def run_local_agent(settings: Settings) -> None:
    # Administração e API principal ficam sempre presas ao próprio PC.
    uvicorn.run(
        create_app(settings),
        host="127.0.0.1",
        port=settings.port,
        reload=False,
        log_config=None,
    )


def main() -> None:
    configure_logging()
    write_pid_file()
    settings = Settings.from_environment()
    logger = logging.getLogger("jarvis")

    logger.info("Jarvis Agent iniciando. PID=%s", os.getpid())

    if settings.bridge_enabled:
        threading.Thread(
            target=advertise_bridge,
            args=(settings,),
            daemon=True,
            name="jarvis-local-discovery",
        ).start()

    if not settings.bridge_enabled:
        logger.info("Bridge desativada. Agent local em 127.0.0.1:%s", settings.port)
        run_local_agent(settings)
        return

    if not settings.api_token:
        logger.error("Bridge ativada, mas falta JARVIS_API_TOKEN no .env.")
        raise SystemExit("Bridge ativada, mas falta JARVIS_API_TOKEN no .env.")

    local_thread = threading.Thread(
        target=run_local_agent,
        args=(settings,),
        daemon=True,
        name="jarvis-local-agent",
    )
    local_thread.start()
    time.sleep(0.8)

    logger.info(
        "Bridge ativa em %s:%s; autenticacao e IPs sao gerenciados pelo cadastro de Dispositivos.",
        settings.bridge_host,
        settings.bridge_port,
    )

    # Esta porta é a destinada aos clientes (celulares/tablets) pela LAN.
    uvicorn.run(
        create_bridge_app(settings),
        host=settings.bridge_host,
        port=settings.bridge_port,
        reload=False,
        log_config=None,
    )


if __name__ == "__main__":
    main()
