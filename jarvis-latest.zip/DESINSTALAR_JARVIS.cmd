@echo off
setlocal
set "UNINSTALL=%LOCALAPPDATA%\Programs\Jarvis\desinstalar.ps1"
if exist "%UNINSTALL%" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%UNINSTALL%"
) else (
  echo.
  echo O Jarvis nao foi encontrado na pasta padrao de instalacao.
  echo Voce tambem pode desinstalar em: Configuracoes ^> Aplicativos ^> Aplicativos instalados ^> Jarvis.
  echo.
  pause
)
endlocal
