from __future__ import annotations

import atexit
import logging
import os
import sys
import threading
import time
import socket
import ipaddress
from logging.handlers import RotatingFileHandler
from pathlib import Path

import uvicorn

from app.bridge import create_bridge_app
from app.config import Settings
from app.main import create_app
from zeroconf import ServiceInfo, Zeroconf


PROJECT_DIR = Path(__file__).resolve().parent
LOG_DIR = PROJECT_DIR / "logs"
LOG_FILE = LOG_DIR / "agent.log"
PID_FILE = PROJECT_DIR / "data" / "jarvis.pid"
INSTANCE_LOCK_FILE = PROJECT_DIR / "data" / "jarvis.lock"
_instance_lock_handle = None


def local_lan_ips() -> tuple[str, ...]:
    candidates: list[str] = []
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
            client.connect(("8.8.8.8", 80))
            candidates.append(client.getsockname()[0])
    except OSError:
        pass
    try:
        for result in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET, socket.SOCK_DGRAM):
            candidates.append(result[4][0])
    except OSError:
        pass

    addresses: list[str] = []
    for value in candidates:
        try:
            address = ipaddress.ip_address(value)
        except ValueError:
            continue
        if not isinstance(address, ipaddress.IPv4Address):
            continue
        if address.is_loopback or address.is_link_local or address.is_multicast or address.is_unspecified:
            continue
        normalized = str(address)
        if normalized not in addresses:
            addresses.append(normalized)
    return tuple(addresses)


def local_lan_ip() -> str:
    addresses = local_lan_ips()
    return addresses[0] if addresses else "127.0.0.1"


def advertise_bridge(settings: Settings) -> None:
    """Anuncia nome e porta na LAN e se atualiza quando o notebook muda de rede."""
    service_type = "_jarvis._tcp.local."
    server_name = f"{settings.instance_name}.local."
    logger = logging.getLogger("jarvis.discovery")
    zeroconf: Zeroconf | None = None
    current: ServiceInfo | None = None
    current_ips: tuple[str, ...] = ()

    def reset_discovery() -> None:
        nonlocal zeroconf, current, current_ips
        if zeroconf is not None:
            if current is not None:
                try:
                    zeroconf.unregister_service(current)
                except Exception:
                    pass
            try:
                zeroconf.close()
            except Exception:
                pass
        zeroconf = None
        current = None
        current_ips = ()

    while True:
        try:
            detected_ips = local_lan_ips()
            if not detected_ips:
                if current_ips:
                    reset_discovery()
                time.sleep(3)
                continue
            if detected_ips != current_ips:
                reset_discovery()
                zeroconf = Zeroconf()
                current = ServiceInfo(
                    service_type,
                    f"{settings.instance_name}.{service_type}",
                    addresses=[socket.inet_aton(address) for address in detected_ips],
                    port=settings.bridge_port,
                    properties={"id": settings.instance_id, "name": settings.instance_name},
                    server=server_name,
                )
                zeroconf.register_service(current, allow_name_change=False)
                current_ips = detected_ips
                logger.info("Descoberta local atualizada apos mudanca de rede.")
            time.sleep(10)
        except Exception:
            logger.exception("Descoberta local falhou; nova tentativa em 3 segundos.")
            reset_discovery()
            time.sleep(3)


def configure_logging() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    handlers: list[logging.Handler] = [file_handler]
    # Quando executado manualmente pelo PowerShell, manter os logs visíveis também.
    if getattr(sys, "stderr", None) is not None:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        handlers.append(console_handler)

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(logging.INFO)
    for handler in handlers:
        root.addHandler(handler)

    for logger_name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        logger = logging.getLogger(logger_name)
        logger.handlers.clear()
        logger.propagate = True
        logger.setLevel(logging.INFO)


def write_pid_file() -> None:
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()), encoding="ascii")

    def cleanup() -> None:
        try:
            if PID_FILE.exists() and PID_FILE.read_text(encoding="ascii").strip() == str(os.getpid()):
                PID_FILE.unlink()
        except OSError:
            pass

    atexit.register(cleanup)


def acquire_instance_lock() -> bool:
    """Garante um unico Agent, inclusive durante inicializacoes simultaneas."""
    global _instance_lock_handle
    INSTANCE_LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    handle = INSTANCE_LOCK_FILE.open("a+b")
    handle.seek(0, os.SEEK_END)
    if handle.tell() == 0:
        handle.write(b"\0")
        handle.flush()
    handle.seek(0)
    try:
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (OSError, BlockingIOError):
        handle.close()
        return False

    _instance_lock_handle = handle
    atexit.register(release_instance_lock)
    return True


def release_instance_lock() -> None:
    global _instance_lock_handle
    locked_handle = _instance_lock_handle
    _instance_lock_handle = None
    if locked_handle is None:
        return
    try:
        locked_handle.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(locked_handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(locked_handle.fileno(), fcntl.LOCK_UN)
    except OSError:
        pass
    locked_handle.close()


def run_local_agent(settings: Settings) -> None:
    # Administração e API principal ficam sempre presas ao próprio PC.
    uvicorn.run(
        create_app(settings),
        host="127.0.0.1",
        port=settings.port,
        reload=False,
        log_config=None,
    )


def run_bridge(settings: Settings) -> None:
    """Mantem a Bridge viva mesmo se a interface de rede oscilar durante a troca de Wi-Fi."""
    logger = logging.getLogger("jarvis.bridge")
    while True:
        try:
            uvicorn.run(
                create_bridge_app(settings),
                host=settings.bridge_host,
                port=settings.bridge_port,
                reload=False,
                log_config=None,
            )
            logger.warning("Bridge foi encerrada; reiniciando em 3 segundos.")
        except (OSError, SystemExit):
            logger.exception("Bridge indisponivel durante mudanca de rede; nova tentativa em 3 segundos.")
        except Exception:
            logger.exception("Falha inesperada na Bridge; nova tentativa em 3 segundos.")
        time.sleep(3)


def main() -> None:
    configure_logging()
    if not acquire_instance_lock():
        logging.getLogger("jarvis").info("Outro Jarvis Agent ja esta em execucao; encerrando esta copia.")
        return
    write_pid_file()
    settings = Settings.from_environment()
    logger = logging.getLogger("jarvis")

    logger.info("Jarvis Agent iniciando. PID=%s", os.getpid())

    if settings.bridge_enabled:
        threading.Thread(
            target=advertise_bridge,
            args=(settings,),
            daemon=True,
            name="jarvis-local-discovery",
        ).start()

    if not settings.bridge_enabled:
        logger.info("Bridge desativada. Agent local em 127.0.0.1:%s", settings.port)
        run_local_agent(settings)
        return

    if not settings.api_token:
        logger.error("Bridge ativada, mas falta JARVIS_API_TOKEN no .env.")
        raise SystemExit("Bridge ativada, mas falta JARVIS_API_TOKEN no .env.")

    local_thread = threading.Thread(
        target=run_local_agent,
        args=(settings,),
        daemon=True,
        name="jarvis-local-agent",
    )
    local_thread.start()
    time.sleep(0.8)

    logger.info(
        "Bridge ativa em %s:%s; autenticacao e IPs sao gerenciados pelo cadastro de Dispositivos.",
        settings.bridge_host,
        settings.bridge_port,
    )

    # Esta porta é a destinada aos clientes (celulares/tablets) pela LAN.
    run_bridge(settings)


if __name__ == "__main__":
    main()
