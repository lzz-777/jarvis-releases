from __future__ import annotations

import asyncio
import csv
import ctypes
import io
import ntpath
import os
import subprocess
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable
from urllib.parse import urlparse

from .config import Settings
from .database import Database


class ActionError(Exception):
    pass


@dataclass(frozen=True)
class ActionDefinition:
    name: str
    risk: str
    description: str
    executor: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class ProcessManager:
    @staticmethod
    def _run_hidden(arguments: list[str]) -> subprocess.CompletedProcess[str]:
        options: dict[str, Any] = {"capture_output": True, "text": True, "check": False}
        if os.name == "nt":
            options["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        return subprocess.run(arguments, **options)

    @staticmethod
    def is_running(process_name: str) -> bool:
        if not process_name:
            return False
        if os.name == "nt":
            return bool(ProcessManager.process_ids(process_name))
        result = subprocess.run(["ps", "-A", "-o", "comm="], capture_output=True, text=True, check=False)
        return any(Path(line.strip()).name.casefold() == process_name.casefold() for line in result.stdout.splitlines())

    @staticmethod
    def process_ids(process_name: str) -> list[int]:
        if os.name != "nt" or not process_name:
            return []
        result = ProcessManager._run_hidden(["tasklist", "/FI", f"IMAGENAME eq {process_name}", "/FO", "CSV", "/NH"])
        pids: list[int] = []
        for row in csv.reader(io.StringIO(result.stdout)):
            if len(row) >= 2 and row[0].casefold() == process_name.casefold():
                try:
                    pids.append(int(row[1]))
                except ValueError:
                    continue
        return pids

    @staticmethod
    def stop(process_name: str, force: bool = False) -> bool:
        if os.name != "nt":
            raise ActionError("Fechar processos está disponível apenas no Windows.")
        if force:
            result = ProcessManager._run_hidden(["taskkill", "/IM", process_name, "/T", "/F"])
            if result.returncode != 0:
                raise ActionError("Não foi possível forçar o encerramento do processo configurado.")
            return True

        target_pids = set(ProcessManager.process_ids(process_name))
        if not target_pids:
            return True
        user32 = ctypes.windll.user32
        posted_handles: set[int] = set()
        callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def close_window(window_handle: int, _: int) -> bool:
            process_id = ctypes.c_ulong()
            handle = ctypes.c_void_p(window_handle)
            user32.GetWindowThreadProcessId(handle, ctypes.byref(process_id))
            if process_id.value in target_pids and user32.IsWindowVisible(handle):
                if user32.PostMessageW(handle, 0x0010, 0, 0):  # WM_CLOSE
                    posted_handles.add(window_handle)
            return True

        user32.EnumWindows(callback_type(close_window), 0)
        if not posted_handles:
            raise ActionError(f"O processo {process_name} esta ativo, mas nao possui janela visivel. Confira o nome do processo ou use a politica Forcado.")
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            remaining_pids = target_pids.intersection(ProcessManager.process_ids(process_name))
            if not remaining_pids:
                return True
            if all(not user32.IsWindow(handle) or not user32.IsWindowVisible(handle) for handle in posted_handles):
                return True
            time.sleep(0.25)
        raise ActionError(f"O processo {process_name} nao respondeu ao fechamento seguro. Verifique trabalho nao salvo antes de usar Forcado.")


class ActionRegistry:
    def __init__(self, database: Database, settings: Settings) -> None:
        self.database = database
        self.settings = settings
        self.actions: dict[str, ActionDefinition] = {}
        self.launched_applications: set[str] = set()
        self._register_defaults()

    def describe(self) -> list[dict[str, str]]:
        return [{"name": action.name, "risk": action.risk, "description": action.description} for action in self.actions.values()]

    async def execute(self, action_name: str, parameters: dict[str, Any]) -> dict[str, Any]:
        action = self.actions.get(action_name)
        if not action:
            raise ActionError(f"Ação desconhecida: {action_name}")
        return await action.executor(parameters)

    def _register(self, name: str, risk: str, description: str, executor: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]) -> None:
        self.actions[name] = ActionDefinition(name, risk, description, executor)

    def _register_defaults(self) -> None:
        self._register("open_application", "SAFE", "Abre um aplicativo cadastrado.", self._open_application)
        self._register("close_application", "SENSITIVE", "Fecha o processo configurado de um aplicativo.", self._close_application)
        self._register("close_session_applications", "SENSITIVE", "Fecha aplicativos abertos pelo Jarvis nesta sessão.", self._close_session_applications)
        self._register("open_url", "SAFE", "Abre uma URL HTTP ou HTTPS no navegador padrão.", self._open_url)
        self._register("wait", "SAFE", "Aguarda por um intervalo definido.", self._wait)
        self._register("wait_process_start", "SAFE", "Espera um processo configurado iniciar.", self._wait_process_start)
        self._register("wait_process_exit", "SAFE", "Espera um processo configurado encerrar.", self._wait_process_exit)
        self._register("check_process", "SAFE", "Consulta se um processo configurado está ativo.", self._check_process)
        self._register("lock_pc", "SENSITIVE", "Bloqueia a sessão atual do Windows.", self._lock_pc)
        self._register("sleep_pc", "DANGEROUS", "Coloca o computador em suspensão.", self._system_action("sleep_pc"))
        self._register("restart_pc", "DANGEROUS", "Reinicia o computador.", self._system_action("restart_pc"))
        self._register("shutdown_pc", "DANGEROUS", "Desliga o computador.", self._system_action("shutdown_pc"))

    def _application(self, parameters: dict[str, Any]) -> dict[str, Any]:
        identifier = parameters.get("application")
        if not isinstance(identifier, str) or not identifier:
            raise ActionError("Informe o identificador de um aplicativo cadastrado.")
        application = self.database.get_application(identifier)
        if not application or not application["enabled"]:
            raise ActionError("Aplicativo inexistente ou desativado.")
        return application

    async def _open_application(self, parameters: dict[str, Any]) -> dict[str, Any]:
        application = self._application(parameters)
        if ProcessManager.is_running(application["process_name"]):
            return {"message": "Aplicativo já estava aberto.", "already_running": True}
        executable = Path(application["executable_path"])
        if not executable.is_file() or executable.suffix.casefold() != ".exe":
            raise ActionError("Executável não encontrado ou inválido.")
        executable_text = str(executable)
        working_directory = ntpath.dirname(executable_text) if "\\" in executable_text else str(executable.parent)
        try:
            subprocess.Popen(
                [executable_text, *application["arguments"]],
                cwd=working_directory,
                shell=False,
                close_fds=False,
            )
        except OSError as error:
            raise ActionError("Não foi possível iniciar o executável configurado.") from error
        self.launched_applications.add(application["identifier"])
        return {"message": "Programa iniciado com sucesso.", "already_running": False}

    async def _close_application(self, parameters: dict[str, Any]) -> dict[str, Any]:
        application = self._application(parameters)
        if not ProcessManager.is_running(application["process_name"]):
            self.launched_applications.discard(application["identifier"])
            return {"message": "Aplicativo já estava fechado.", "already_running": False}
        policy = str(application.get("close_policy") or "safe")
        requested_force = parameters.get("force") is True
        if policy == "never" and not requested_force:
            raise ActionError("Este aplicativo está protegido pela política Nunca fechar.")
        force = requested_force or policy == "force"
        ProcessManager.stop(application["process_name"], force=force)
        self.launched_applications.discard(application["identifier"])
        method = "forçado" if force else "seguro"
        return {"message": f"Encerramento {method} concluído.", "force": force}

    async def _close_session_applications(self, _: dict[str, Any]) -> dict[str, Any]:
        closed: list[str] = []
        skipped: list[str] = []
        errors: list[dict[str, str]] = []
        for identifier in sorted(self.launched_applications):
            application = self.database.get_application(identifier)
            if not application or not ProcessManager.is_running(application["process_name"]):
                self.launched_applications.discard(identifier)
                continue
            if application.get("close_policy") == "never":
                skipped.append(identifier)
                continue
            try:
                await self._close_application({"application": identifier})
                closed.append(identifier)
            except ActionError as error:
                errors.append({"application": identifier, "error": str(error)})
        return {"message": f"{len(closed)} aplicativo(s) desta sessão fechado(s).", "closed": closed, "skipped": skipped, "errors": errors}

    def active_applications(self) -> list[dict[str, Any]]:
        active: list[dict[str, Any]] = []
        for application in self.database.list_applications():
            if ProcessManager.is_running(application["process_name"]):
                active.append({
                    "id": application["id"],
                    "name": application["name"],
                    "identifier": application["identifier"],
                    "process_name": application["process_name"],
                    "close_policy": application.get("close_policy", "safe"),
                    "launched_by_jarvis": application["identifier"] in self.launched_applications,
                })
        return active

    async def _open_url(self, parameters: dict[str, Any]) -> dict[str, Any]:
        url = parameters.get("url")
        parsed = urlparse(url) if isinstance(url, str) else None
        if not parsed or parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ActionError("A URL deve usar HTTP ou HTTPS.")
        opened = webbrowser.open(url, new=2)
        if not opened:
            raise ActionError("O navegador padrão não aceitou a URL.")
        return {"message": "URL aberta no navegador padrão."}

    async def _wait(self, parameters: dict[str, Any]) -> dict[str, Any]:
        seconds = parameters.get("seconds")
        if not isinstance(seconds, (int, float)) or isinstance(seconds, bool) or not 0 <= seconds <= 3600:
            raise ActionError("O tempo de espera deve ser entre 0 e 3600 segundos.")
        await asyncio.sleep(seconds)
        return {"message": f"Aguardou {seconds} segundos."}

    async def _wait_process_start(self, parameters: dict[str, Any]) -> dict[str, Any]:
        return await self._wait_process(parameters, expected=True)

    async def _wait_process_exit(self, parameters: dict[str, Any]) -> dict[str, Any]:
        return await self._wait_process(parameters, expected=False)

    async def _wait_process(self, parameters: dict[str, Any], expected: bool) -> dict[str, Any]:
        application = self._application(parameters)
        timeout = parameters.get("timeout_seconds", 30)
        if not isinstance(timeout, int) or not 1 <= timeout <= 3600:
            raise ActionError("O timeout deve ser um inteiro entre 1 e 3600 segundos.")
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if ProcessManager.is_running(application["process_name"]) == expected:
                state = "iniciou" if expected else "encerrou"
                return {"message": f"Processo {state}."}
            await asyncio.sleep(0.5)
        state = "iniciar" if expected else "encerrar"
        raise ActionError(f"Timeout aguardando processo {state}.")

    async def _check_process(self, parameters: dict[str, Any]) -> dict[str, Any]:
        application = self._application(parameters)
        return {"running": ProcessManager.is_running(application["process_name"])}

    async def _lock_pc(self, parameters: dict[str, Any]) -> dict[str, Any]:
        if self.settings.dev_mode:
            return {"message": "Would execute lock_pc", "simulated": True}
        if os.name != "nt":
            raise ActionError("Bloqueio disponível apenas no Windows.")
        result = subprocess.run(["rundll32.exe", "user32.dll,LockWorkStation"], check=False)
        if result.returncode != 0:
            raise ActionError("Não foi possível bloquear o PC.")
        return {"message": "PC bloqueado."}

    def _system_action(self, action_name: str) -> Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]:
        async def execute(_: dict[str, Any]) -> dict[str, Any]:
            if self.settings.dev_mode:
                return {"message": f"Would execute {action_name}", "simulated": True}
            if os.name != "nt":
                raise ActionError("Ação de sistema disponível apenas no Windows.")
            commands = {
                "shutdown_pc": ["shutdown.exe", "/s", "/t", "0"],
                "restart_pc": ["shutdown.exe", "/r", "/t", "0"],
                "sleep_pc": ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"],
            }
            result = subprocess.run(commands[action_name], check=False)
            if result.returncode != 0:
                raise ActionError(f"Não foi possível executar {action_name}.")
            return {"message": f"Ação {action_name} enviada ao Windows."}
        return execute
