# Relay remoto genérico

O Relay é opcional e serve ao cenário em que a rede privada termina em outro dispositivo da LAN, não no computador do Jarvis.

Ele não depende de fornecedor de VPN, sistema operacional móvel, IP ou porta do computador. O destino é descoberto pelo serviço mDNS `_jarvis._tcp.local.` e confirmado pelo `instance_id` persistente antes de qualquer encaminhamento.

## Configuração

1. No Dashboard, escolha **Relay** como tipo de acesso remoto, informe a URL estável pela qual o Relay será alcançado e salve.
2. Clique em **Gerar configuração Relay**. O Jarvis cria uma credencial e copia as variáveis para a Área de Transferência. O token completo é mostrado somente nesse momento.
3. No dispositivo que possui acesso simultâneo à LAN e à rede privada, instale Python 3.11+ e as dependências de `_arquivos/requirements.txt`.
4. Defina as variáveis copiadas e execute, a partir da pasta `_arquivos`:

```powershell
python -m relay
```

`JARVIS_RELAY_BIND_HOST` e `JARVIS_RELAY_PORT` são configuráveis. O Relay não altera firewall, roteador, VPN, DNS ou UPnP. Cabe ao usuário permitir o acesso somente pela rede privada desejada.

## Autenticação

O cliente continua usando seu token de dispositivo. Entre Relay e Bridge existe uma segunda credencial, exclusiva do Relay. A Bridge valida ambas e não usa o IP como identidade.

O token do Relay pode ser revogado no Dashboard sem alterar os tokens dos celulares. Tokens não devem ser enviados em URL, logs ou arquivos publicados.
