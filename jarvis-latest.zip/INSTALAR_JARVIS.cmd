@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0_arquivos\instalar.ps1"
if errorlevel 1 (
  echo.
  echo A instalacao encontrou um erro. Leia a mensagem acima.
  pause
)
endlocal
