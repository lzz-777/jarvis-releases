from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass
from threading import Lock
from typing import Any, Callable

import httpx
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import RedirectResponse, Response
from zeroconf import IPVersion, ServiceBrowser, ServiceInfo, ServiceListener, Zeroconf


SERVICE_TYPE = "_jarvis._tcp.local."
RELAY_AUTH_HEADER = "X-Jarvis-Relay-Authorization"
FORWARDED_RESPONSE_HEADERS = {"content-type", "cache-control", "referrer-policy"}


@dataclass(frozen=True)
class RelaySettings:
    instance_id: str
    relay_token: str
    bind_host: str = "127.0.0.1"
    port: int = 9580
    discovery_timeout_seconds: float = 4.0
    target_cache_seconds: float = 30.0

    @classmethod
    def from_environment(cls) -> "RelaySettings":
        instance_id = os.getenv("JARVIS_RELAY_INSTANCE_ID", "").strip()
        relay_token = os.getenv("JARVIS_RELAY_TOKEN", "").strip()
        if not instance_id:
            raise SystemExit("Configure JARVIS_RELAY_INSTANCE_ID com o ID persistente da instalação Jarvis.")
        if len(relay_token) < 32:
            raise SystemExit("Configure JARVIS_RELAY_TOKEN com a credencial completa gerada pelo Jarvis.")
        return cls(
            instance_id=instance_id,
            relay_token=relay_token,
            bind_host=os.getenv("JARVIS_RELAY_BIND_HOST", "127.0.0.1").strip() or "127.0.0.1",
            port=int(os.getenv("JARVIS_RELAY_PORT", "9580")),
            discovery_timeout_seconds=max(1.0, float(os.getenv("JARVIS_RELAY_DISCOVERY_TIMEOUT_SECONDS", "4"))),
            target_cache_seconds=max(1.0, float(os.getenv("JARVIS_RELAY_TARGET_CACHE_SECONDS", "30"))),
        )


class JarvisListener(ServiceListener):
    def __init__(self, zeroconf: Zeroconf, expected_instance_id: str) -> None:
        self.zeroconf = zeroconf
        self.expected_instance_id = expected_instance_id
        self._lock = Lock()
        self._targets: list[str] = []

    @staticmethod
    def _property(info: ServiceInfo, key: str) -> str:
        value = info.properties.get(key.encode("utf-8"), b"")
        return value.decode("utf-8", errors="replace") if isinstance(value, bytes) else str(value or "")

    def _read(self, service_type: str, name: str) -> None:
        info = self.zeroconf.get_service_info(service_type, name, timeout=1500)
        if not info or self._property(info, "id") != self.expected_instance_id:
            return
        addresses = info.parsed_addresses(IPVersion.All)
        with self._lock:
            for address in addresses:
                host = f"[{address}]" if ":" in address else address
                target = f"http://{host}:{info.port}"
                if target not in self._targets:
                    self._targets.append(target)

    def add_service(self, zeroconf: Zeroconf, service_type: str, name: str) -> None:
        self._read(service_type, name)

    def update_service(self, zeroconf: Zeroconf, service_type: str, name: str) -> None:
        self._read(service_type, name)

    def remove_service(self, zeroconf: Zeroconf, service_type: str, name: str) -> None:
        return

    def targets(self) -> list[str]:
        with self._lock:
            return list(self._targets)


def discover_targets(expected_instance_id: str, timeout_seconds: float) -> list[str]:
    zeroconf = Zeroconf(ip_version=IPVersion.All)
    listener = JarvisListener(zeroconf, expected_instance_id)
    browser = ServiceBrowser(zeroconf, SERVICE_TYPE, listener)
    try:
        time.sleep(timeout_seconds)
        return listener.targets()
    finally:
        browser.cancel()
        zeroconf.close()


class TargetResolver:
    def __init__(
        self,
        settings: RelaySettings,
        discover: Callable[[str, float], list[str]] = discover_targets,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.discover = discover
        self.transport = transport
        self._target = ""
        self._expires_at = 0.0
        self._lock = asyncio.Lock()

    def invalidate(self) -> None:
        self._target = ""
        self._expires_at = 0.0

    async def resolve(self, force: bool = False) -> str:
        if not force and self._target and time.monotonic() < self._expires_at:
            return self._target
        async with self._lock:
            if not force and self._target and time.monotonic() < self._expires_at:
                return self._target
            candidates = await asyncio.to_thread(
                self.discover,
                self.settings.instance_id,
                self.settings.discovery_timeout_seconds,
            )
            headers = {"Authorization": f"Bearer {self.settings.relay_token}"}
            async with httpx.AsyncClient(timeout=4.0, transport=self.transport) as client:
                for candidate in candidates:
                    try:
                        response = await client.get(f"{candidate}/bridge/v1/relay/identity", headers=headers)
                        data = response.json() if response.status_code == 200 else {}
                    except (httpx.HTTPError, ValueError):
                        continue
                    if data.get("instance_id") == self.settings.instance_id and data.get("role") == "pc_receiver":
                        self._target = candidate
                        self._expires_at = time.monotonic() + self.settings.target_cache_seconds
                        return candidate
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="A instância Jarvis esperada não foi encontrada ou não aceitou a credencial do Relay.",
            )


def create_relay_app(
    settings: RelaySettings,
    discover: Callable[[str, float], list[str]] = discover_targets,
    transport: httpx.AsyncBaseTransport | None = None,
) -> FastAPI:
    app = FastAPI(
        title="Jarvis Remote Relay",
        version="1.0.0",
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )
    resolver = TargetResolver(settings, discover, transport)
    app.state.resolver = resolver

    @app.get("/relay/v1/health")
    async def relay_health() -> dict[str, Any]:
        return {"status": "ok", "role": "jarvis_relay", "target_cached": bool(resolver._target)}

    async def forward(request: Request, require_client_token: bool) -> Response:
        authorization = request.headers.get("Authorization", "").strip()
        if require_client_token and not authorization.casefold().startswith("bearer "):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token do dispositivo ausente.")
        body = await request.body()
        upstream_headers: dict[str, str] = {
            RELAY_AUTH_HEADER: f"Bearer {settings.relay_token}",
        }
        if authorization:
            upstream_headers["Authorization"] = authorization
        content_type = request.headers.get("Content-Type")
        if content_type:
            upstream_headers["Content-Type"] = content_type

        last_error: Exception | None = None
        for attempt in range(2):
            target = await resolver.resolve(force=attempt > 0)
            target_url = f"{target}{request.url.path}"
            if request.url.query:
                target_url = f"{target_url}?{request.url.query}"
            try:
                async with httpx.AsyncClient(timeout=310.0, follow_redirects=False, transport=transport) as client:
                    response = await client.request(
                        request.method,
                        target_url,
                        headers=upstream_headers,
                        content=body,
                    )
                headers = {
                    name: value
                    for name, value in response.headers.items()
                    if name.casefold() in FORWARDED_RESPONSE_HEADERS
                }
                return Response(response.content, status_code=response.status_code, headers=headers)
            except httpx.HTTPError as error:
                last_error = error
                resolver.invalidate()
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="O Relay encontrou o Jarvis, mas não conseguiu encaminhar a requisição.",
        ) from last_error

    @app.get("/", include_in_schema=False)
    async def open_mobile_panel() -> RedirectResponse:
        return RedirectResponse(url="/pair", status_code=status.HTTP_307_TEMPORARY_REDIRECT)

    @app.api_route("/pair", methods=["GET"])
    async def proxy_pair(request: Request) -> Response:
        return await forward(request, require_client_token=False)

    @app.api_route("/bridge/v1/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
    async def proxy_bridge(request: Request, path: str) -> Response:
        return await forward(request, require_client_token=True)

    return app
