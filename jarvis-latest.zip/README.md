# Jarvis — Automação local e remota para Windows

Este pacote contém tudo o que é necessário para instalar, configurar e distribuir o Jarvis de forma limpa em qualquer computador.

## Instalar

1. Extraia o ZIP.
2. Execute `INSTALAR_JARVIS.cmd`.
3. O instalador cria o Jarvis em `%LOCALAPPDATA%\Programs\Jarvis`, cria o ambiente Python e instala as dependências. Na primeira instalação é necessário ter Python 3.11+ e acesso à internet.
4. Se já existir uma versão anterior, o instalador preserva seu `.env` (incluindo portas customizadas), aplicativos, modos e dispositivos do banco SQLite.
5. A Bridge remota (porta padrão 9521) é habilitada automaticamente para comandos do celular.

## Atualizações

- O aplicativo verifica novas versões ao iniciar e novamente a cada 6 horas.
- Quando existe uma versão nova, o ícone da bandeja mostra uma notificação e a opção **Atualizar para ...**.
- O pacote é baixado por HTTPS do repositório público `lzz-777/jarvis-releases`, sem token e sem usar a API do GitHub.
- Antes de instalar, o Jarvis confere o SHA-256 publicado. O instalador preserva `.env`, banco SQLite, aplicativos, modos e dispositivos.
- Também é possível usar **Verificar atualizações** no menu do ícone da bandeja.

## Desinstalar

Você pode usar qualquer uma destas opções:

- Execute `DESINSTALAR_JARVIS.cmd` deste pacote; ou
- Windows → Configurações → Aplicativos → Aplicativos instalados → **Jarvis** → Desinstalar.

O desinstalador pergunta se você quer manter aplicativos, modos e dispositivos para uma reinstalação futura.

## Estrutura do Pacote

Na raiz existem apenas:

- `INSTALAR_JARVIS.cmd` — Script de instalação simplificado
- `DESINSTALAR_JARVIS.cmd` — Script de desinstalação
- `README.md` — Documentação do pacote
- `usar no automate e mudar token e ip no httprequest no celular .flo` — Fluxo modelo para o aplicativo Automate no Android
- `_arquivos/` — Arquivos internos do aplicativo, dashboard, bandeja e `.env.example`

## Recursos e Configurações

- **Sem dados pré-configurados**: O aplicativo inicia 100% limpo, sem dispositivos "fantasma" ou tokens pessoais. Você cadastra seus aparelhos na tela de **Dispositivos**.
- **Portas de Servidor Customizáveis**:
  - Porta Local do Agent (padrão: `9520`)
  - Porta da Bridge para Celular/LAN (padrão: `9521`)
  - As portas podem ser alteradas diretamente na tela de **Dispositivos e Rede** do aplicativo ou no arquivo `.env`. Isso permite ter múltiplos computadores com Jarvis rodando na mesma rede WiFi sem conflito.
- **Detecção de IP da LAN**: O aplicativo mostra automaticamente o IP local do computador e o exemplo da URL para configurar no celular (`http://<IP_DO_PC>:<PORTA_BRIDGE>/bridge/v1/command`).
- **Abrir e fechar aplicativos**: cada aplicativo cadastrado pode ser aberto ou fechado pelo painel. Os modos podem fechar aplicativos primeiro e abrir outros em seguida.
- **Proteção contra perda de trabalho**: fechar usa o nome de processo cadastrado e exige confirmação no painel, pois todas as instâncias desse processo são encerradas.
- **Fechamento pelo celular**: em **Dispositivos**, habilite ações sensíveis para permitir modos que fecham aplicativos pela Bridge. A opção vem desativada por segurança.

