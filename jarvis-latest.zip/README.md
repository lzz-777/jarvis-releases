# Jarvis — Automação local e remota para Windows

Este pacote contém tudo o que é necessário para instalar, configurar e distribuir o Jarvis de forma limpa em qualquer computador.

## Instalar

1. Extraia o ZIP.
2. Execute `INSTALAR_JARVIS.cmd`.
3. O instalador cria o Jarvis em `%LOCALAPPDATA%\Programs\Jarvis`, cria o ambiente Python e instala as dependências. Na primeira instalação é necessário ter Python 3.11+ e acesso à internet.
4. Se já existir uma versão anterior, o instalador preserva seu `.env` (incluindo portas e configurações de acesso remoto customizadas), aplicativos, modos e dispositivos do banco SQLite.
5. A Bridge (porta padrão 9521) é habilitada automaticamente para comandos da rede local.

Novas instalações recebem um identificador único de instância, nome local (`jarvis-<hostname>-<id>.local`) e portas disponíveis escolhidas automaticamente. O endereço `.local` permanece válido mesmo se o IP local do computador mudar, desde que o cliente esteja na mesma rede local. Instalações existentes mantêm suas portas e configurações intactas.

## Arquitetura de Endpoints: Acesso Local e Acesso Remoto

O Jarvis foi projetado com um modelo unificado de endpoints pertencentes à mesma instância e protegidos pela mesma Bridge autenticada:

### 1. Acesso Local (LAN-only)
- **Endereço mDNS**: `http://<nome-da-instancia>.local:<porta-bridge>` (ex: `http://jarvis-meupc-a1b2c3.local:9521`)
- **Escopo**: **Disponível apenas na mesma rede local (LAN)**. O endereço continua válido mesmo que o IP local do computador mude.
- **Pareamento**: QR Code local que abre a página web de pareamento no dispositivo móvel.

### 2. Acesso Remoto (Opcional e Genérico)
- **Agnóstico de provedor**: Suporta qualquer túnel reverso, gateway ou domínio público (ex: Cloudflare Tunnel, Tailscale Funnel / VPN, DDNS / Port Forward próprio).
- **Sem configurações forçadas**: Não exige VPN específica, não ativa UPnP e não abre portas externas por padrão.
- **Persistência e Teste**: Pode ser configurado e testado diretamente pela aba **Dispositivos e Rede** do Jarvis Dashboard. O teste valida se o endpoint responde com status claro (conectado, autenticação protegida, rota inexistente, timeout) sem vazar tokens nem alterar as configurações locais em caso de falha.
- **Segurança**: Todas as requisições passam pela mesma camada de autenticação Bearer da Bridge. O token de dispositivo nunca é exposto na URL (query string).

## Dispositivos Móveis e Pareamento

- O botão **QR / Configurar** abre o painel **Conectar Jarvis**. No celular, ele abre a interface web que valida o dispositivo, lista modos e mostra aplicativos ativos.
- O token fica no fragmento `#token=...` da URL do QR e é armazenado apenas no navegador do aparelho; ele **nunca** é enviado na URL ao servidor.
- É possível utilizar o Atalhos do iOS, Automate no Android ou requisições HTTP REST diretamente.
- Um atalho compartilhado do iOS pode ser configurado em `JARVIS_IOS_SHORTCUT_URL`. Consulte [docs/atalho-ios.md](docs/atalho-ios.md).

## Atualizações

- O aplicativo verifica novas versões ao iniciar e novamente a cada 6 horas.
- Quando existe uma versão nova, o ícone da bandeja mostra uma notificação e a opção **Atualizar para ...**.
- O pacote é baixado por HTTPS do repositório público `lzz-777/jarvis-releases`, sem token e sem usar a API do GitHub.
- Antes de instalar, o Jarvis confere o SHA-256 publicado. O instalador preserva `.env`, banco SQLite, aplicativos, modos e dispositivos.
- Também é possível usar **Verificar atualizações** no menu do ícone da bandeja.

## Desinstalar

Você pode usar qualquer uma destas opções:

- Execute `DESINSTALAR_JARVIS.cmd` deste pacote; ou
- Windows → Configurações → Aplicativos → Aplicativos instalados → **Jarvis** → Desinstalar.

O desinstalador pergunta se você quer manter aplicativos, modos e dispositivos para uma reinstalação futura.

## Estrutura do Pacote

Na raiz existem apenas:

- `INSTALAR_JARVIS.cmd` — Script de instalação simplificado
- `DESINSTALAR_JARVIS.cmd` — Script de desinstalação
- `README.md` — Documentação do pacote
- `Jarvis automate - configure token e destino.flo` — Fluxo pronto para o Automate no Android
- `_arquivos/` — Arquivos internos do aplicativo, dashboard, bandeja e `.env.example`
- `docs/` — Guias complementares

## Android com Automate (Gateway / Relé)

1. Importe `Jarvis automate - configure token e destino.flo` no app Automate no Android.
2. No primeiro bloco **Variável definida**, substitua `COLE-SEU-TOKEN` pelo token da Bridge gerado no Jarvis.
3. O segundo bloco pode ficar vazio: ele descobre automaticamente o primeiro Jarvis anunciado na rede. Se houver mais de um PC na mesma LAN, preencha o nome mostrado em **Jarvis local** (sem `.local`).
4. Inicie o fluxo no Automate.
5. Em clientes externos, utilize `http://<IP-DO-GATEWAY>:8767/bridge/v1/command` com método `POST` e corpo JSON `{"command":"nome-do-modo"}`.

O fluxo descobre o IP e a porta atuais do PC pelo serviço `_jarvis._tcp` na rede Wi-Fi, encaminha o comando de forma segura e devolve o status real do Jarvis.

## Recursos e Segurança

- **Sem dados pré-configurados**: O aplicativo inicia 100% limpo, sem dispositivos pré-cadastrados ou tokens pessoais. Você cadastra seus dispositivos na tela **Dispositivos e Rede**.
- **Identidade e portas automáticas**: Instalações novas criam nome e portas próprios sem conflito de portas na LAN.
- **Descoberta local**: O Jarvis anuncia `jarvis-<hostname>-<id>.local` por mDNS com recuperação automática quando o computador troca de rede.
- **Acesso remoto opcional**: Suporte a endpoints remotos agnósticos com teste integrado de conectividade.
- **Abrir e fechar aplicativos**: Cada aplicativo cadastrado pode ser aberto ou fechado pelo painel. Os modos podem fechar aplicativos primeiro e abrir outros em seguida.
- **Proteção contra perda de trabalho**: Cada aplicativo usa a política **Seguro**, **Forçado** ou **Nunca fechar**. O fechamento seguro solicita encerramento gracioso da janela.
- **Fechamento pelo celular**: Em **Dispositivos e Rede**, habilite ações sensíveis para permitir comandos que fecham aplicativos. A opção vem desativada por padrão por segurança.
- **IPs adicionais**: Cada dispositivo cadastrado pode autorizar IPs extras de ponte ou VPN sem substituir seu IP local principal.
- **Firewall dinâmico**: O instalador verifica a regra real do Windows Defender Firewall, identifica o processo Python do Agent e autoriza conexões privadas na sub-rede local, sem abrir portas globais indiscriminadas.
