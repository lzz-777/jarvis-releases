# Jarvis — Automação local e remota para Windows

Este pacote contém tudo o que é necessário para instalar, configurar e distribuir o Jarvis de forma limpa em qualquer computador.

## Instalar

1. Extraia o ZIP.
2. Execute `INSTALAR_JARVIS.cmd`.
3. O instalador cria o Jarvis em `%LOCALAPPDATA%\Programs\Jarvis`, cria o ambiente Python e instala as dependências. Na primeira instalação é necessário ter Python 3.11+ e acesso à internet.
4. Se já existir uma versão anterior, o instalador preserva seu `.env` (incluindo portas customizadas), aplicativos, modos e dispositivos do banco SQLite.
5. A Bridge remota (porta padrão 9521) é habilitada automaticamente para comandos do celular.

Novas instalações recebem um nome local único (`jarvis-nome-id.local`) e portas disponíveis escolhidas automaticamente. O QR usa esse nome, então o notebook pode mudar de IP entre casa e trabalho sem exigir edição do atalho, desde que celular e computador estejam na mesma rede local. Instalações existentes mantêm suas portas para não quebrar integrações.

## iPhone e pareamento

- O botão **QR / Configurar** abre o QR **Conectar Jarvis**. No iPhone, ele abre um painel local que valida o dispositivo, lista modos e mostra aplicativos ativos.
- O token fica no fragmento do QR e é guardado apenas no navegador do aparelho; ele não é enviado na URL ao servidor.
- Um atalho compartilhado do iOS pode ser configurado em `JARVIS_IOS_SHORTCUT_URL`. Consulte [docs/atalho-ios.md](docs/atalho-ios.md).
- O iOS sempre exige a confirmação **Adicionar Atalho**. O Jarvis automatiza o preenchimento e o pareamento, mas não tenta contornar essa proteção do sistema.

## Atualizações

- O aplicativo verifica novas versões ao iniciar e novamente a cada 6 horas.
- Quando existe uma versão nova, o ícone da bandeja mostra uma notificação e a opção **Atualizar para ...**.
- O pacote é baixado por HTTPS do repositório público `lzz-777/jarvis-releases`, sem token e sem usar a API do GitHub.
- Antes de instalar, o Jarvis confere o SHA-256 publicado. O instalador preserva `.env`, banco SQLite, aplicativos, modos e dispositivos.
- Também é possível usar **Verificar atualizações** no menu do ícone da bandeja.

## Desinstalar

Você pode usar qualquer uma destas opções:

- Execute `DESINSTALAR_JARVIS.cmd` deste pacote; ou
- Windows → Configurações → Aplicativos → Aplicativos instalados → **Jarvis** → Desinstalar.

O desinstalador pergunta se você quer manter aplicativos, modos e dispositivos para uma reinstalação futura.

## Estrutura do Pacote

Na raiz existem apenas:

- `INSTALAR_JARVIS.cmd` — Script de instalação simplificado
- `DESINSTALAR_JARVIS.cmd` — Script de desinstalação
- `README.md` — Documentação do pacote
- `Jarvis Relay J2 - configure token e destino.flo` — Relé pronto para o Automate no Android
- `_arquivos/` — Arquivos internos do aplicativo, dashboard, bandeja e `.env.example`

## Android com Automate: J2 como relé

1. Importe `Jarvis Relay J2 - configure token e destino.flo` no Automate do J2.
2. No primeiro bloco **Variável definida**, substitua somente `COLE-SEU-TOKEN` pelo token da Bridge.
3. O segundo bloco pode ficar vazio: ele escolhe automaticamente o primeiro Jarvis encontrado. Se houver mais de um PC, preencha ali o nome mostrado em **Jarvis local**, sem `.local`.
4. Inicie o fluxo e permita que o Automate continue ativo em segundo plano.
5. No iPhone, use `http://IP-TAILSCALE-DO-J2:8767/bridge/v1/command`, método `POST`, corpo JSON como `{"command":"trabalho"}`.

O fluxo recebe pela interface VPN na porta `8767`, aceita `POST /bridge/v1/command` e descobre automaticamente o IP e a porta atuais do PC pelo serviço `_jarvis._tcp` na rede Wi-Fi. Depois encaminha o JSON e devolve ao iPhone o status e a resposta reais do Jarvis. Se o PC mudar de IP, o J2 redescobre o endereço sem exigir alterações nos atalhos. Se o encaminhamento falhar, o Atalhos recebe HTTP `502` com uma mensagem clara e o fluxo atualiza o destino antes da próxima tentativa. O token fica somente no J2; o modelo publicado não contém endereço ou token reais.

## Recursos e Configurações

- **Sem dados pré-configurados**: O aplicativo inicia 100% limpo, sem dispositivos "fantasma" ou tokens pessoais. Você cadastra seus aparelhos na tela de **Dispositivos**.
- **Identidade e portas automáticas**: instalações novas criam nome e portas próprios. As portas continuam editáveis na tela **Dispositivos e Rede**.
- **Descoberta local**: o Jarvis anuncia `jarvis-nome-id.local` por mDNS e atualiza o endereço anunciado quando o notebook muda de rede.
- **Abrir e fechar aplicativos**: cada aplicativo cadastrado pode ser aberto ou fechado pelo painel. Os modos podem fechar aplicativos primeiro e abrir outros em seguida.
- **Proteção contra perda de trabalho**: cada aplicativo usa a política **Seguro**, **Forçado** ou **Nunca fechar**. O fechamento seguro solicita que a janela encerre e permite que o programa peça para salvar.
- **Fechamento por sessão**: fecha somente os aplicativos abertos pelo próprio Jarvis desde o início atual do Agent.
- **Fechamento pelo celular**: em **Dispositivos**, habilite ações sensíveis para permitir modos que fecham aplicativos pela Bridge. A opção vem desativada por segurança.
- **IPs adicionais**: cada dispositivo pode autorizar IPs extras de ponte ou VPN sem substituir seu IP local principal.
- **Histórico copiável**: a tela **Histórico** copia todos os registros carregados, incluindo origem, resultado e detalhes do erro.
- **Fechamento discreto**: consultas e encerramentos de processo são executados sem janelas de CMD piscando; processos auxiliares sem janela não impedem o fechamento seguro da interface.
- **Firewall dinâmico**: o instalador autoriza somente o executável dedicado do Jarvis, em redes privadas e para a sub-rede local. A regra acompanha qualquer porta futura da Bridge sem abrir portas globais do Windows.

