param(
    [Parameter(Mandatory=$true)][string]$PackageUrl,
    [Parameter(Mandatory=$true)][string]$ExpectedVersion,
    [Parameter(Mandatory=$true)][string]$ExpectedSha256
)

$ErrorActionPreference = 'Stop'
$allowedPrefix = 'https://raw.githubusercontent.com/lzz-777/jarvis-releases/main/'
$workDir = Join-Path $env:TEMP ('Jarvis-Update-' + [guid]::NewGuid().ToString('N'))
$logDir = Join-Path $env:LOCALAPPDATA 'Jarvis'
$logFile = Join-Path $logDir 'update.log'

function Write-UpdateLog {
    param([string]$Message)
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Message) -Encoding UTF8
}

try {
    if (-not $PackageUrl.StartsWith($allowedPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Origem do pacote de atualização não autorizada.'
    }

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    New-Item -ItemType Directory -Force -Path $workDir | Out-Null
    $packagePath = Join-Path $workDir 'jarvis-update.zip'
    $extractDir = Join-Path $workDir 'package'

    $expectedHash = $ExpectedSha256.Trim().ToUpperInvariant()
    if ($expectedHash -notmatch '^[0-9A-F]{64}$') {
        throw 'SHA-256 publicado é inválido.'
    }

    Write-UpdateLog "Baixando pacote da versão $ExpectedVersion."
    $actualSha256 = ''
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        $separator = if ($PackageUrl.Contains('?')) { '&' } else { '?' }
        $freshUrl = $PackageUrl + $separator + 'version=' + [Uri]::EscapeDataString($ExpectedVersion) + '&attempt=' + $attempt + '&t=' + [DateTime]::UtcNow.Ticks
        Invoke-WebRequest -UseBasicParsing -Uri $freshUrl -OutFile $packagePath -TimeoutSec 120 -Headers @{ 'Cache-Control' = 'no-cache' }
        $actualSha256 = (Get-FileHash -LiteralPath $packagePath -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualSha256 -eq $expectedHash) { break }
        Start-Sleep -Seconds 2
    }
    if ($actualSha256 -ne $expectedHash) {
        throw 'O pacote baixado não corresponde ao SHA-256 publicado após três tentativas.'
    }

    Expand-Archive -LiteralPath $packagePath -DestinationPath $extractDir -Force
    $installer = Join-Path $extractDir '_arquivos\instalar.ps1'
    if (-not (Test-Path -LiteralPath $installer)) {
        throw 'O pacote não contém o instalador esperado.'
    }

    Write-UpdateLog "Pacote verificado. Iniciando instalação da versão $ExpectedVersion."
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -Update
    if ($LASTEXITCODE -ne 0) {
        throw "O instalador terminou com o código $LASTEXITCODE."
    }
    Write-UpdateLog "Atualização para $ExpectedVersion concluída."
}
catch {
    Write-UpdateLog ('Falha: ' + $_.Exception.Message)
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show(
        "Não foi possível atualizar o Jarvis.`r`n`r`n$($_.Exception.Message)`r`n`r`nDetalhes: $logFile",
        'Jarvis - Atualização',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}
finally {
    if (Test-Path -LiteralPath $workDir) {
        Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
