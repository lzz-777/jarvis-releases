using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

internal static class Program
{
    private static Mutex instanceMutex;

    [STAThread]
    private static void Main()
    {
        bool createdNew;
        instanceMutex = new Mutex(true, "Local\\JarvisDashboardApp", out createdNew);
        if (!createdNew)
        {
            return;
        }
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new DashboardForm());
        GC.KeepAlive(instanceMutex);
    }
}

internal static class JarvisEnv
{
    public static string ReadPort(string key, string fallback)
    {
        try
        {
            string envPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ".env");
            if (File.Exists(envPath))
            {
                string[] lines = File.ReadAllLines(envPath);
                foreach (string line in lines)
                {
                    string trimmed = line.Trim();
                    if (trimmed.StartsWith(key + "=", StringComparison.OrdinalIgnoreCase))
                    {
                        string val = trimmed.Substring(key.Length + 1).Trim();
                        int port;
                        if (int.TryParse(val, out port) && port > 0 && port <= 65535)
                        {
                            return port.ToString();
                        }
                    }
                }
            }
        }
        catch { }
        return fallback;
    }

    public static string AgentPort
    {
        get { return ReadPort("JARVIS_PORT", "9520"); }
    }

    public static string BridgePort
    {
        get { return ReadPort("JARVIS_BRIDGE_PORT", "9521"); }
    }

    public static string ApiBaseUrl
    {
        get { return "http://127.0.0.1:" + AgentPort + "/dashboard-api/v1"; }
    }

    public static string HealthUrl
    {
        get { return "http://127.0.0.1:" + AgentPort + "/api/v1/health"; }
    }
}

internal static class TokenVault
{
    private static string VaultPath
    {
        get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Jarvis", "token-vault.json"); }
    }

    private static Dictionary<string, string> Read()
    {
        try
        {
            if (!File.Exists(VaultPath)) return new Dictionary<string, string>();
            return new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(File.ReadAllText(VaultPath)) ?? new Dictionary<string, string>();
        }
        catch { return new Dictionary<string, string>(); }
    }

    private static void Write(Dictionary<string, string> values)
    {
        string directory = Path.GetDirectoryName(VaultPath);
        if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);
        File.WriteAllText(VaultPath, new JavaScriptSerializer().Serialize(values));
    }

    public static void Save(int deviceId, string token)
    {
        Dictionary<string, string> values = Read();
        byte[] protectedBytes = ProtectedData.Protect(Encoding.UTF8.GetBytes(token), null, DataProtectionScope.CurrentUser);
        values[deviceId.ToString()] = Convert.ToBase64String(protectedBytes);
        Write(values);
    }

    public static bool TryGet(int deviceId, out string token)
    {
        token = String.Empty;
        try
        {
            string value;
            if (!Read().TryGetValue(deviceId.ToString(), out value) || String.IsNullOrWhiteSpace(value)) return false;
            token = Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(value), null, DataProtectionScope.CurrentUser));
            return !String.IsNullOrWhiteSpace(token);
        }
        catch { token = String.Empty; return false; }
    }

    public static void Remove(int deviceId)
    {
        Dictionary<string, string> values = Read();
        if (values.Remove(deviceId.ToString())) Write(values);
    }

    public static void SaveInstallation(string token)
    {
        Dictionary<string, string> values = Read();
        byte[] protectedBytes = ProtectedData.Protect(Encoding.UTF8.GetBytes(token), null, DataProtectionScope.CurrentUser);
        values["__installation_token"] = Convert.ToBase64String(protectedBytes);
        Write(values);
    }

    public static bool TryGetInstallation(out string token)
    {
        token = String.Empty;
        try
        {
            string value;
            if (!Read().TryGetValue("__installation_token", out value) || String.IsNullOrWhiteSpace(value)) return false;
            token = Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(value), null, DataProtectionScope.CurrentUser));
            return !String.IsNullOrWhiteSpace(token);
        }
        catch { token = String.Empty; return false; }
    }

    public static bool RememberTokensEnabled()
    {
        string value;
        return Read().TryGetValue("__remember_tokens", out value) && value == "1";
    }

    public static void SetRememberTokensEnabled(bool enabled)
    {
        Dictionary<string, string> values = Read();
        values["__remember_tokens"] = enabled ? "1" : "0";
        Write(values);
    }
}

internal sealed class DashboardForm : Form
{
    private static string ApiBaseUrl { get { return JarvisEnv.ApiBaseUrl; } }
    private static string HealthUrl { get { return JarvisEnv.HealthUrl; } }

    private readonly JavaScriptSerializer serializer = new JavaScriptSerializer();
    private readonly ListView applicationList = new ListView();
    private readonly TextBox nameInput = new TextBox();
    private readonly TextBox identifierInput = new TextBox();
    private readonly TextBox executableInput = new TextBox();
    private readonly TextBox processInput = new TextBox();
    private readonly TextBox argumentsInput = new TextBox();
    private readonly CheckBox enabledCheckbox = new CheckBox();
    private readonly ComboBox closePolicyInput = new ComboBox();
    private readonly Label statusLabel = new Label();
    private readonly Label editorLabel = new Label();
    private readonly Panel sectionHost = new Panel();
    private readonly List<Control> applicationSectionControls = new List<Control>();
    private Panel headerPanel;
    private DeviceManagerForm deviceManagerForm;
    private ModeManagerForm modeManagerForm;
    private HistoryManagerForm historyManagerForm;
    private BackupManagerForm backupManagerForm;
    private int? currentApplicationId;

    public DashboardForm()
    {
        Text = "Jarvis Dashboard";
        Icon = SystemIcons.Application;
        ClientSize = new Size(1060, 680);
        MinimumSize = new Size(1060, 680);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(28, 32, 42);
        ForeColor = Color.WhiteSmoke;
        Font = new Font("Segoe UI", 9.0f);

        BuildLayout();
        Shown += delegate
        {
            if (EnsureAgent())
            {
                LoadApplications();
            }
        };
    }

    private void BuildLayout()
    {
        headerPanel = new Panel();
        headerPanel.Location = new Point(0, 0);
        headerPanel.Size = new Size(1060, 78);
        headerPanel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        headerPanel.BackColor = Color.FromArgb(39, 45, 60);
        Controls.Add(headerPanel);

        Label title = new Label();
        title.Text = "Jarvis Dashboard";
        title.Font = new Font("Segoe UI Semibold", 18.0f);
        title.AutoSize = true;
        title.Location = new Point(24, 15);
        headerPanel.Controls.Add(title);

        Label subtitle = new Label();
        subtitle.Text = "Cadastre, abra e feche os programas controlados pelo Jarvis.";
        subtitle.ForeColor = Color.Gainsboro;
        subtitle.AutoSize = true;
        subtitle.Location = new Point(27, 49);
        headerPanel.Controls.Add(subtitle);

        Button applicationsButton = NewButton("Aplicativos", 500, 21, 95);
        applicationsButton.Click += ShowApplicationsSection;
        headerPanel.Controls.Add(applicationsButton);

        Button devicesButton = NewButton("Dispositivos", 602, 21, 105);
        devicesButton.Click += OpenDeviceManager;
        headerPanel.Controls.Add(devicesButton);

        Button modesButton = NewButton("Modos", 714, 21, 78);
        modesButton.Click += OpenModeManager;
        headerPanel.Controls.Add(modesButton);

        Button historyButton = NewButton("Histórico", 799, 21, 90);
        historyButton.Click += OpenHistoryManager;
        headerPanel.Controls.Add(historyButton);

        Button backupButton = NewButton("Backup", 896, 21, 78);
        backupButton.Click += OpenBackupManager;
        headerPanel.Controls.Add(backupButton);

        statusLabel.Text = "Agent: verificando...";
        statusLabel.Font = new Font("Segoe UI Semibold", 9.0f);
        statusLabel.AutoSize = true;
        statusLabel.Location = new Point(300, 29);
        headerPanel.Controls.Add(statusLabel);

        Label instructions = NewLabel("1. Escolha o .exe  2. Confira os campos  3. Salve  4. Use Abrir ou Fechar", 24, 95, Color.FromArgb(194, 205, 223));
        Controls.Add(instructions);

        Label applicationsLabel = NewLabel("Aplicativos cadastrados", 24, 128, Color.WhiteSmoke);
        applicationsLabel.Font = new Font("Segoe UI Semibold", 11.0f);
        Controls.Add(applicationsLabel);

        applicationList.Location = new Point(24, 154);
        applicationList.Size = new Size(508, 430);
        applicationList.View = View.Details;
        applicationList.FullRowSelect = true;
        applicationList.GridLines = true;
        applicationList.HideSelection = false;
        applicationList.BackColor = Color.FromArgb(20, 24, 33);
        applicationList.ForeColor = Color.WhiteSmoke;
        applicationList.Columns.Add("Nome", 180);
        applicationList.Columns.Add("Identificador", 125);
        applicationList.Columns.Add("Processo", 150);
        applicationList.Columns.Add("Fechamento", 95);
        applicationList.SelectedIndexChanged += ApplicationListSelectionChanged;
        Controls.Add(applicationList);

        editorLabel.Text = "Novo aplicativo";
        editorLabel.Font = new Font("Segoe UI Semibold", 11.0f);
        editorLabel.AutoSize = true;
        editorLabel.Location = new Point(565, 128);
        Controls.Add(editorLabel);

        AddField("Nome", 154, nameInput);
        AddField("Identificador (sem espaços)", 211, identifierInput);
        AddField("Executável (.exe)", 268, executableInput);

        Button browseButton = NewButton("Escolher .exe...", 825, 306, 145);
        browseButton.Click += BrowseForExecutable;
        Controls.Add(browseButton);

        AddField("Processo", 344, processInput);

        Label argumentsLabel = NewLabel("Argumentos opcionais (um por linha)", 565, 401, Color.WhiteSmoke);
        Controls.Add(argumentsLabel);
        argumentsInput.Location = new Point(565, 422);
        argumentsInput.Size = new Size(405, 58);
        argumentsInput.Multiline = true;
        argumentsInput.ScrollBars = ScrollBars.Vertical;
        StyleInput(argumentsInput);
        Controls.Add(argumentsInput);

        enabledCheckbox.Text = "Aplicativo ativo";
        enabledCheckbox.Checked = true;
        enabledCheckbox.AutoSize = true;
        enabledCheckbox.Location = new Point(565, 493);
        Controls.Add(enabledCheckbox);

        Controls.Add(NewLabel("Política ao fechar", 720, 493, Color.WhiteSmoke));
        closePolicyInput.Location = new Point(825, 489);
        closePolicyInput.Size = new Size(145, 27);
        closePolicyInput.DropDownStyle = ComboBoxStyle.DropDownList;
        closePolicyInput.Items.AddRange(new object[] { "Seguro", "Forçado", "Nunca fechar" });
        closePolicyInput.SelectedIndex = 0;
        Controls.Add(closePolicyInput);

        Button saveButton = NewButton("Salvar aplicativo", 565, 530, 130);
        saveButton.Click += SaveApplication;
        Controls.Add(saveButton);

        Button testButton = NewButton("Abrir", 704, 530, 80);
        testButton.Click += TestApplication;
        Controls.Add(testButton);

        Button closeButton = NewButton("Fechar", 793, 530, 80);
        closeButton.Click += CloseApplication;
        Controls.Add(closeButton);

        Button clearButton = NewButton("Limpar", 882, 530, 75);
        clearButton.Click += delegate { ClearEditor(); };
        Controls.Add(clearButton);

        Button deleteButton = NewButton("Excluir", 966, 530, 80);
        deleteButton.Click += DeleteApplication;
        Controls.Add(deleteButton);

        Button closeSessionButton = NewButton("Fechar apps desta sessão", 565, 575, 190);
        closeSessionButton.Click += CloseSessionApplications;
        Controls.Add(closeSessionButton);

        Label footer = NewLabel("Selecione um aplicativo à esquerda para editar ou testar. Os dados ficam no banco local do Jarvis.", 24, 625, Color.FromArgb(190, 201, 220));
        Controls.Add(footer);

        foreach (Control control in Controls)
        {
            if (control != headerPanel)
            {
                applicationSectionControls.Add(control);
            }
        }

        sectionHost.Location = new Point(0, 78);
        sectionHost.Size = new Size(1060, 602);
        sectionHost.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        sectionHost.BackColor = BackColor;
        sectionHost.Visible = false;
        Controls.Add(sectionHost);
        headerPanel.BringToFront();
    }

    private void ShowApplicationsSection(object sender, EventArgs eventArgs)
    {
        ShowApplicationsSection();
    }

    private void ShowApplicationsSection()
    {
        if (deviceManagerForm != null) deviceManagerForm.Visible = false;
        if (modeManagerForm != null) modeManagerForm.Visible = false;
        if (historyManagerForm != null) historyManagerForm.Visible = false;
        if (backupManagerForm != null) backupManagerForm.Visible = false;
        sectionHost.Visible = false;
        foreach (Control control in applicationSectionControls)
        {
            control.Visible = true;
        }
        headerPanel.BringToFront();
    }

    private void HideEmbeddedSections()
    {
        if (deviceManagerForm != null) deviceManagerForm.Visible = false;
        if (modeManagerForm != null) modeManagerForm.Visible = false;
        if (historyManagerForm != null) historyManagerForm.Visible = false;
        if (backupManagerForm != null) backupManagerForm.Visible = false;
    }

    private void OpenModeManager(object sender, EventArgs eventArgs)
    {
        foreach (Control control in applicationSectionControls) control.Visible = false;
        sectionHost.Visible = true;
        HideEmbeddedSections();
        if (modeManagerForm == null || modeManagerForm.IsDisposed)
        {
            modeManagerForm = new ModeManagerForm();
            EmbedForm(modeManagerForm);
        }
        modeManagerForm.RefreshData();
        modeManagerForm.Visible = true;
        modeManagerForm.BringToFront();
        headerPanel.BringToFront();
    }

    private void OpenDeviceManager(object sender, EventArgs eventArgs)
    {
        foreach (Control control in applicationSectionControls) control.Visible = false;
        sectionHost.Visible = true;
        HideEmbeddedSections();
        if (deviceManagerForm == null || deviceManagerForm.IsDisposed)
        {
            deviceManagerForm = new DeviceManagerForm();
            EmbedForm(deviceManagerForm);
        }
        deviceManagerForm.RefreshData();
        deviceManagerForm.Visible = true;
        deviceManagerForm.BringToFront();
        headerPanel.BringToFront();
    }

    private void OpenHistoryManager(object sender, EventArgs eventArgs)
    {
        foreach (Control control in applicationSectionControls) control.Visible = false;
        sectionHost.Visible = true;
        HideEmbeddedSections();
        if (historyManagerForm == null || historyManagerForm.IsDisposed)
        {
            historyManagerForm = new HistoryManagerForm();
            EmbedForm(historyManagerForm);
        }
        historyManagerForm.RefreshData();
        historyManagerForm.Visible = true;
        historyManagerForm.BringToFront();
        headerPanel.BringToFront();
    }

    private void OpenBackupManager(object sender, EventArgs eventArgs)
    {
        foreach (Control control in applicationSectionControls) control.Visible = false;
        sectionHost.Visible = true;
        HideEmbeddedSections();
        if (backupManagerForm == null || backupManagerForm.IsDisposed)
        {
            backupManagerForm = new BackupManagerForm();
            EmbedForm(backupManagerForm);
        }
        backupManagerForm.Visible = true;
        backupManagerForm.BringToFront();
        headerPanel.BringToFront();
    }

    private void EmbedForm(Form form)
    {
        form.TopLevel = false;
        form.FormBorderStyle = FormBorderStyle.None;
        form.MinimumSize = Size.Empty;
        form.Dock = DockStyle.Fill;
        form.StartPosition = FormStartPosition.Manual;
        sectionHost.Controls.Add(form);
        form.Show();
    }

    private static Label NewLabel(string text, int left, int top, Color color)
    {
        Label label = new Label();
        label.Text = text;
        label.ForeColor = color;
        label.AutoSize = true;
        label.Location = new Point(left, top);
        return label;
    }

    private static Button NewButton(string text, int left, int top, int width)
    {
        Button button = new Button();
        button.Text = text;
        button.Location = new Point(left, top);
        button.Size = new Size(width, 34);
        return button;
    }

    private void AddField(string text, int top, TextBox input)
    {
        Controls.Add(NewLabel(text, 565, top, Color.WhiteSmoke));
        input.Location = new Point(565, top + 21);
        input.Size = new Size(405, 27);
        StyleInput(input);
        Controls.Add(input);
    }

    private static void StyleInput(TextBox input)
    {
        input.BackColor = Color.FromArgb(20, 24, 33);
        input.ForeColor = Color.WhiteSmoke;
        input.BorderStyle = BorderStyle.FixedSingle;
    }

    private bool EnsureAgent()
    {
        if (IsAgentOnline())
        {
            SetStatus(true);
            return true;
        }

        string launcherPath = Path.Combine(Application.StartupPath, "start-agent.vbs");
        try
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = Path.Combine(Environment.SystemDirectory, "wscript.exe");
            startInfo.Arguments = Quote(launcherPath);
            startInfo.WorkingDirectory = Application.StartupPath;
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;
            startInfo.WindowStyle = ProcessWindowStyle.Hidden;
            Process.Start(startInfo);
        }
        catch (Exception exception)
        {
            SetStatus(false);
            ShowError("Não foi possível iniciar o Jarvis Agent.", exception);
            return false;
        }

        for (int attempt = 0; attempt < 40; attempt++)
        {
            Thread.Sleep(500);
            Application.DoEvents();
            if (IsAgentOnline())
            {
                SetStatus(true);
                return true;
            }
        }

        SetStatus(false);
        MessageBox.Show("O Jarvis Agent não respondeu. Veja logs\\agent.log na pasta do Jarvis.", "Jarvis Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return false;
    }

    private bool IsAgentOnline()
    {
        try
        {
            using (WebClient client = NewWebClient())
            {
                return client.DownloadString(HealthUrl).Contains("\"status\":\"ok\"");
            }
        }
        catch
        {
            return false;
        }
    }

    private void SetStatus(bool online)
    {
        statusLabel.Text = online ? "Agent: online" : "Agent: offline";
        statusLabel.ForeColor = online ? Color.LightGreen : Color.LightCoral;
    }

    private void LoadApplications()
    {
        try
        {
            ArrayList applications = serializer.Deserialize<ArrayList>(Request("/applications", "GET", null));
            applicationList.Items.Clear();
            foreach (object entry in applications)
            {
                Dictionary<string, object> application = ToDictionary(entry);
                ListViewItem item = new ListViewItem(Value(application, "name"));
                item.SubItems.Add(Value(application, "identifier"));
                item.SubItems.Add(Value(application, "process_name"));
                item.SubItems.Add(ClosePolicyLabel(Value(application, "close_policy")));
                item.Tag = application;
                applicationList.Items.Add(item);
            }
            SetStatus(true);
        }
        catch (Exception exception)
        {
            SetStatus(false);
            ShowError("Não foi possível carregar os aplicativos.", exception);
        }
    }

    private void BrowseForExecutable(object sender, EventArgs eventArgs)
    {
        using (OpenFileDialog dialog = new OpenFileDialog())
        {
            dialog.Title = "Escolha o executável do aplicativo";
            dialog.Filter = "Executáveis (*.exe)|*.exe";
            dialog.CheckFileExists = true;
            dialog.Multiselect = false;
            if (dialog.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }

            executableInput.Text = dialog.FileName;
            if (String.IsNullOrWhiteSpace(processInput.Text))
            {
                processInput.Text = Path.GetFileName(dialog.FileName);
            }
            if (String.IsNullOrWhiteSpace(nameInput.Text))
            {
                nameInput.Text = Path.GetFileNameWithoutExtension(dialog.FileName);
            }
            if (String.IsNullOrWhiteSpace(identifierInput.Text))
            {
                identifierInput.Text = Path.GetFileNameWithoutExtension(dialog.FileName).ToLowerInvariant();
            }
        }
    }

    private void ApplicationListSelectionChanged(object sender, EventArgs eventArgs)
    {
        if (applicationList.SelectedItems.Count == 0)
        {
            return;
        }

        Dictionary<string, object> application = (Dictionary<string, object>)applicationList.SelectedItems[0].Tag;
        currentApplicationId = Convert.ToInt32(application["id"]);
        editorLabel.Text = "Editar aplicativo";
        nameInput.Text = Value(application, "name");
        identifierInput.Text = Value(application, "identifier");
        executableInput.Text = Value(application, "executable_path");
        processInput.Text = Value(application, "process_name");
        argumentsInput.Lines = ToStringArray(application.ContainsKey("arguments") ? application["arguments"] : null);
        enabledCheckbox.Checked = ToBoolean(application.ContainsKey("enabled") ? application["enabled"] : true);
        closePolicyInput.SelectedIndex = ClosePolicyIndex(Value(application, "close_policy"));
    }

    private void SaveApplication(object sender, EventArgs eventArgs)
    {
        if (!ValidateInputs())
        {
            return;
        }

        Dictionary<string, object> payload = new Dictionary<string, object>();
        payload["name"] = nameInput.Text.Trim();
        payload["identifier"] = identifierInput.Text.Trim();
        payload["executable_path"] = executableInput.Text.Trim();
        payload["process_name"] = processInput.Text.Trim();
        payload["arguments"] = NonEmptyLines(argumentsInput.Lines);
        payload["enabled"] = enabledCheckbox.Checked;
        payload["close_policy"] = ClosePolicyValue();

        try
        {
            string path = currentApplicationId.HasValue ? "/applications/" + currentApplicationId.Value : "/applications";
            Request(path, currentApplicationId.HasValue ? "PUT" : "POST", payload);
            LoadApplications();
            ClearEditor();
            MessageBox.Show("Aplicativo salvo.", "Jarvis Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível salvar o aplicativo.", exception);
        }
    }

    private bool ValidateInputs()
    {
        if (String.IsNullOrWhiteSpace(nameInput.Text) || String.IsNullOrWhiteSpace(identifierInput.Text) || String.IsNullOrWhiteSpace(executableInput.Text) || String.IsNullOrWhiteSpace(processInput.Text))
        {
            MessageBox.Show("Preencha Nome, Identificador, Executável e Processo antes de salvar.", "Jarvis Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
        if (!executableInput.Text.Trim().EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("O executável precisa terminar em .exe.", "Jarvis Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
        return true;
    }

    private void TestApplication(object sender, EventArgs eventArgs)
    {
        if (!currentApplicationId.HasValue)
        {
            MessageBox.Show("Salve e selecione o aplicativo antes de testar.", "Jarvis Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            Dictionary<string, object> response = serializer.Deserialize<Dictionary<string, object>>(Request("/applications/" + currentApplicationId.Value + "/test", "POST", new Dictionary<string, object>()));
            Dictionary<string, object> result = ToDictionary(response["result"]);
            MessageBox.Show(Value(result, "message"), "Teste do aplicativo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("O teste não foi executado.", exception);
        }
    }

    private void CloseApplication(object sender, EventArgs eventArgs)
    {
        if (!currentApplicationId.HasValue)
        {
            MessageBox.Show("Salve e selecione o aplicativo antes de fechar.", "Jarvis Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        string policy = ClosePolicyValue();
        if (policy == "never")
        {
            MessageBox.Show("Este aplicativo está protegido pela política Nunca fechar.", "Fechar aplicativo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        string warning = policy == "force"
            ? "Forçar o encerramento de todas as instâncias? Trabalho não salvo será perdido."
            : "Solicitar fechamento seguro? O aplicativo poderá pedir para salvar o trabalho.";
        if (MessageBox.Show(warning, "Fechar aplicativo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
        {
            return;
        }

        try
        {
            Dictionary<string, object> response = serializer.Deserialize<Dictionary<string, object>>(Request("/applications/" + currentApplicationId.Value + "/close", "POST", new Dictionary<string, object>()));
            Dictionary<string, object> result = ToDictionary(response["result"]);
            MessageBox.Show(Value(result, "message"), "Fechar aplicativo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("O aplicativo não foi fechado.", exception);
        }
    }

    private void CloseSessionApplications(object sender, EventArgs eventArgs)
    {
        if (MessageBox.Show("Fechar somente os aplicativos abertos pelo Jarvis nesta sessão? As políticas de proteção serão respeitadas.", "Fechar apps desta sessão", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            Dictionary<string, object> response = serializer.Deserialize<Dictionary<string, object>>(Request("/applications/close-session", "POST", new Dictionary<string, object>()));
            Dictionary<string, object> result = ToDictionary(response["result"]);
            MessageBox.Show(Value(result, "message"), "Jarvis", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível fechar os aplicativos desta sessão.", exception);
        }
    }

    private string ClosePolicyValue()
    {
        if (closePolicyInput.SelectedIndex == 1) return "force";
        if (closePolicyInput.SelectedIndex == 2) return "never";
        return "safe";
    }

    private static int ClosePolicyIndex(string value)
    {
        if (String.Equals(value, "force", StringComparison.OrdinalIgnoreCase)) return 1;
        if (String.Equals(value, "never", StringComparison.OrdinalIgnoreCase)) return 2;
        return 0;
    }

    private static string ClosePolicyLabel(string value)
    {
        int index = ClosePolicyIndex(value);
        return index == 1 ? "Forçado" : (index == 2 ? "Protegido" : "Seguro");
    }

    private void DeleteApplication(object sender, EventArgs eventArgs)
    {
        if (!currentApplicationId.HasValue)
        {
            MessageBox.Show("Selecione um aplicativo para excluir.", "Jarvis Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (MessageBox.Show("Excluir o aplicativo selecionado?", "Jarvis Dashboard", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
        {
            return;
        }

        try
        {
            Request("/applications/" + currentApplicationId.Value, "DELETE", new Dictionary<string, object>());
            LoadApplications();
            ClearEditor();
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível excluir o aplicativo.", exception);
        }
    }

    private void ClearEditor()
    {
        currentApplicationId = null;
        editorLabel.Text = "Novo aplicativo";
        nameInput.Clear();
        identifierInput.Clear();
        executableInput.Clear();
        processInput.Clear();
        argumentsInput.Clear();
        enabledCheckbox.Checked = true;
        closePolicyInput.SelectedIndex = 0;
        applicationList.SelectedItems.Clear();
    }

    private string Request(string path, string method, object payload)
    {
        try
        {
            using (WebClient client = NewWebClient())
            {
                string url = ApiBaseUrl + path;
                if (method == "GET")
                {
                    return client.DownloadString(url);
                }
                string json = serializer.Serialize(payload ?? new Dictionary<string, object>());
                return client.UploadString(url, method, json);
            }
        }
        catch (WebException exception)
        {
            throw new InvalidOperationException(ReadApiError(exception), exception);
        }
    }

    private static WebClient NewWebClient()
    {
        WebClient client = new WebClient();
        client.Encoding = Encoding.UTF8;
        client.Headers[HttpRequestHeader.ContentType] = "application/json; charset=utf-8";
        return client;
    }

    private string ReadApiError(WebException exception)
    {
        if (exception.Response == null)
        {
            return exception.Message;
        }
        try
        {
            using (StreamReader reader = new StreamReader(exception.Response.GetResponseStream(), Encoding.UTF8))
            {
                Dictionary<string, object> error = serializer.Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
                if (error.ContainsKey("detail"))
                {
                    return Convert.ToString(error["detail"]);
                }
            }
        }
        catch
        {
        }
        return exception.Message;
    }

    private static Dictionary<string, object> ToDictionary(object value)
    {
        return value as Dictionary<string, object> ?? new Dictionary<string, object>();
    }

    private static string Value(Dictionary<string, object> values, string key)
    {
        return values.ContainsKey(key) && values[key] != null ? Convert.ToString(values[key]) : String.Empty;
    }

    private static bool ToBoolean(object value)
    {
        if (value is bool)
        {
            return (bool)value;
        }
        return Convert.ToString(value) == "1" || Convert.ToString(value).Equals("true", StringComparison.OrdinalIgnoreCase);
    }

    private static string[] ToStringArray(object value)
    {
        ArrayList values = value as ArrayList;
        if (values == null)
        {
            return new string[0];
        }
        List<string> result = new List<string>();
        foreach (object entry in values)
        {
            result.Add(Convert.ToString(entry));
        }
        return result.ToArray();
    }

    private static string[] NonEmptyLines(string[] lines)
    {
        List<string> result = new List<string>();
        foreach (string line in lines)
        {
            if (!String.IsNullOrWhiteSpace(line))
            {
                result.Add(line.Trim());
            }
        }
        return result.ToArray();
    }

    private static string Quote(string value)
    {
        return "\"" + value.Replace("\"", "\\\"") + "\"";
    }

    private static void ShowError(string prefix, Exception exception)
    {
        MessageBox.Show(prefix + "\n\n" + exception.Message, "Jarvis Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}

internal sealed class HistoryManagerForm : Form
{
    private static string ApiBaseUrl { get { return JarvisEnv.ApiBaseUrl; } }
    private readonly JavaScriptSerializer serializer = new JavaScriptSerializer();
    private readonly ListView historyList = new ListView();
    private readonly Label statusLabel = new Label();
    private readonly System.Windows.Forms.Timer refreshTimer = new System.Windows.Forms.Timer();

    public HistoryManagerForm()
    {
        Text = "Jarvis - Histórico";
        Icon = SystemIcons.Application;
        ClientSize = new Size(1040, 640);
        MinimumSize = new Size(1040, 640);
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(28, 32, 42);
        ForeColor = Color.WhiteSmoke;
        Font = new Font("Segoe UI", 9.0f);
        BuildLayout();

        refreshTimer.Interval = 3000;
        refreshTimer.Tick += delegate { if (Visible) LoadHistory(false); };
        Shown += delegate { LoadHistory(false); refreshTimer.Start(); };
        VisibleChanged += delegate
        {
            if (Visible) refreshTimer.Start();
            else refreshTimer.Stop();
        };
    }

    public void RefreshData()
    {
        LoadHistory(false);
    }

    private void BuildLayout()
    {
        Panel header = new Panel();
        header.Location = new Point(0, 0);
        header.Size = new Size(1040, 78);
        header.BackColor = Color.FromArgb(39, 45, 60);
        Controls.Add(header);

        Label title = NewLabel("Histórico e Auditoria", 24, 15, Color.WhiteSmoke);
        title.Font = new Font("Segoe UI Semibold", 18.0f);
        header.Controls.Add(title);
        header.Controls.Add(NewLabel("Execuções locais e comandos da Bridge. Atualização automática a cada 3 segundos.", 27, 49, Color.Gainsboro));

        Button refreshButton = NewButton("Atualizar", 814, 21, 90);
        refreshButton.Click += delegate { LoadHistory(true); };
        header.Controls.Add(refreshButton);

        Button copyButton = NewButton("Copiar carregados", 678, 21, 130);
        copyButton.Click += CopyLoadedHistory;
        header.Controls.Add(copyButton);

        Button clearButton = NewButton("Limpar histórico", 910, 21, 110);
        clearButton.Click += ClearHistory;
        header.Controls.Add(clearButton);

        historyList.Location = new Point(20, 96);
        historyList.Size = new Size(1000, 455);
        historyList.View = View.Details;
        historyList.FullRowSelect = true;
        historyList.GridLines = true;
        historyList.HideSelection = false;
        historyList.BackColor = Color.FromArgb(20, 24, 33);
        historyList.ForeColor = Color.WhiteSmoke;
        historyList.Columns.Add("Data/Hora", 135);
        historyList.Columns.Add("Origem", 190);
        historyList.Columns.Add("Tipo", 65);
        historyList.Columns.Add("Comando / Alvo", 150);
        historyList.Columns.Add("Duração", 85);
        historyList.Columns.Add("Resultado", 80);
        historyList.Columns.Add("Detalhes / Erro", 285);
        Controls.Add(historyList);

        statusLabel.Text = "Retenção: até 1.000 registros | Logs em disco: 5 MB por arquivo + até 5 backups rotativos.";
        statusLabel.ForeColor = Color.FromArgb(194, 205, 223);
        statusLabel.AutoSize = true;
        statusLabel.Location = new Point(24, 572);
        Controls.Add(statusLabel);
    }

    private void LoadHistory(bool showErrors)
    {
        try
        {
            ArrayList response = serializer.Deserialize<ArrayList>(Request("/history", "GET", null));
            historyList.BeginUpdate();
            historyList.Items.Clear();
            foreach (object entry in response)
            {
                Dictionary<string, object> row = ToDictionary(entry);
                ListViewItem item = new ListViewItem(Value(row, "timestamp"));
                item.SubItems.Add(Value(row, "origin"));
                item.SubItems.Add(Value(row, "type"));
                item.SubItems.Add(Value(row, "command"));
                item.SubItems.Add(Value(row, "duration"));
                item.SubItems.Add(Value(row, "result"));
                item.SubItems.Add(Value(row, "details"));
                historyList.Items.Add(item);
            }
            historyList.EndUpdate();
            statusLabel.Text = "Registros carregados: " + historyList.Items.Count + " | Retenção: até 1.000 | Logs: 5 MB + até 5 backups.";
        }
        catch (Exception exception)
        {
            try { historyList.EndUpdate(); } catch { }
            if (showErrors)
            {
                ShowError("Não foi possível atualizar o histórico.", exception);
            }
        }
    }

    private void ClearHistory(object sender, EventArgs eventArgs)
    {
        if (MessageBox.Show("Limpar todo o histórico de execuções? Esta ação não altera aplicativos, modos ou dispositivos.", "Jarvis - Histórico", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
        {
            return;
        }
        try
        {
            Request("/history", "DELETE", new Dictionary<string, object>());
            LoadHistory(false);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível limpar o histórico.", exception);
        }
    }

    private void CopyLoadedHistory(object sender, EventArgs eventArgs)
    {
        if (historyList.Items.Count == 0)
        {
            MessageBox.Show("Nao ha registros carregados para copiar.", "Jarvis - Historico", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        StringBuilder text = new StringBuilder();
        text.AppendLine("Data/Hora\tOrigem\tTipo\tComando / Alvo\tDuracao\tResultado\tDetalhes / Erro");
        foreach (ListViewItem item in historyList.Items)
        {
            List<string> values = new List<string>();
            foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
            {
                values.Add((subItem.Text ?? String.Empty).Replace("\r", " ").Replace("\n", " ").Replace("\t", " "));
            }
            text.AppendLine(String.Join("\t", values.ToArray()));
        }
        try
        {
            Clipboard.SetText(text.ToString());
            statusLabel.Text = historyList.Items.Count + " registro(s) carregado(s) copiado(s) para a Area de Transferencia.";
        }
        catch (Exception exception)
        {
            ShowError("Nao foi possivel copiar os registros carregados.", exception);
        }
    }

    private string Request(string path, string method, object payload)
    {
        try
        {
            using (WebClient client = NewWebClient())
            {
                if (method == "GET")
                {
                    return client.DownloadString(ApiBaseUrl + path);
                }
                return client.UploadString(ApiBaseUrl + path, method, serializer.Serialize(payload ?? new Dictionary<string, object>()));
            }
        }
        catch (WebException exception)
        {
            throw new InvalidOperationException(ReadApiError(exception), exception);
        }
    }

    private static WebClient NewWebClient()
    {
        WebClient client = new WebClient();
        client.Encoding = Encoding.UTF8;
        client.Headers[HttpRequestHeader.ContentType] = "application/json; charset=utf-8";
        return client;
    }

    private string ReadApiError(WebException exception)
    {
        if (exception.Response == null) return exception.Message;
        try
        {
            using (StreamReader reader = new StreamReader(exception.Response.GetResponseStream(), Encoding.UTF8))
            {
                Dictionary<string, object> error = serializer.Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
                return error.ContainsKey("detail") ? Convert.ToString(error["detail"]) : exception.Message;
            }
        }
        catch { return exception.Message; }
    }

    private static Label NewLabel(string text, int left, int top, Color color)
    {
        Label label = new Label();
        label.Text = text;
        label.ForeColor = color;
        label.AutoSize = true;
        label.Location = new Point(left, top);
        return label;
    }

    private static Button NewButton(string text, int left, int top, int width)
    {
        Button button = new Button();
        button.Text = text;
        button.Location = new Point(left, top);
        button.Size = new Size(width, 34);
        return button;
    }

    private static Dictionary<string, object> ToDictionary(object value)
    {
        return value as Dictionary<string, object> ?? new Dictionary<string, object>();
    }

    private static string Value(Dictionary<string, object> values, string key)
    {
        return values.ContainsKey(key) && values[key] != null ? Convert.ToString(values[key]) : String.Empty;
    }

    private static void ShowError(string prefix, Exception exception)
    {
        MessageBox.Show(prefix + "\n\n" + exception.Message, "Jarvis - Histórico", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}

internal sealed class BackupManagerForm : Form
{
    private static string ApiBaseUrl { get { return JarvisEnv.ApiBaseUrl; } }
    private readonly JavaScriptSerializer serializer = new JavaScriptSerializer();

    public BackupManagerForm()
    {
        Text = "Jarvis - Backup";
        Icon = SystemIcons.Application;
        ClientSize = new Size(1040, 640);
        MinimumSize = new Size(1040, 640);
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(28, 32, 42);
        ForeColor = Color.WhiteSmoke;
        Font = new Font("Segoe UI", 9.0f);
        BuildLayout();
    }

    private void BuildLayout()
    {
        Panel header = new Panel();
        header.Location = new Point(0, 0);
        header.Size = new Size(1040, 78);
        header.BackColor = Color.FromArgb(39, 45, 60);
        Controls.Add(header);

        Label title = NewLabel("Backup e Portabilidade", 24, 15, Color.WhiteSmoke);
        title.Font = new Font("Segoe UI Semibold", 18.0f);
        header.Controls.Add(title);
        header.Controls.Add(NewLabel("Exporte aplicativos e modos para JSON ou importe em outro PC sem sobrescrever dados existentes.", 27, 49, Color.Gainsboro));

        Panel box = new Panel();
        box.Location = new Point(120, 145);
        box.Size = new Size(800, 340);
        box.BackColor = Color.FromArgb(20, 24, 33);
        box.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(box);

        Label exportTitle = NewLabel("Exportar configuração", 36, 34, Color.WhiteSmoke);
        exportTitle.Font = new Font("Segoe UI Semibold", 12.0f);
        box.Controls.Add(exportTitle);
        Label exportInfo = NewLabel("Cria um arquivo JSON com aplicativos, argumentos, modos e todas as etapas dos modos.", 36, 68, Color.FromArgb(194, 205, 223));
        exportInfo.MaximumSize = new Size(710, 45);
        box.Controls.Add(exportInfo);
        Button exportButton = NewButton("Exportar backup...", 36, 112, 155);
        exportButton.Click += ExportBackup;
        box.Controls.Add(exportButton);

        Label importTitle = NewLabel("Importar configuração", 36, 180, Color.WhiteSmoke);
        importTitle.Font = new Font("Segoe UI Semibold", 12.0f);
        box.Controls.Add(importTitle);
        Label importInfo = NewLabel("A importação é transacional. Se houver identificadores de aplicativos ou modos já existentes, nada é alterado.", 36, 214, Color.FromArgb(194, 205, 223));
        importInfo.MaximumSize = new Size(710, 45);
        box.Controls.Add(importInfo);
        Button importButton = NewButton("Importar backup...", 36, 260, 155);
        importButton.Click += ImportBackup;
        box.Controls.Add(importButton);

        Controls.Add(NewLabel("Tokens de dispositivos não são exportados: o Jarvis guarda somente o hash por segurança.", 120, 510, Color.FromArgb(255, 215, 0)));
    }

    private void ExportBackup(object sender, EventArgs eventArgs)
    {
        try
        {
            string json = Request("/backup", "GET", null);
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "Backup JSON do Jarvis (*.json)|*.json";
                dialog.FileName = "jarvis-backup-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".json";
                dialog.AddExtension = true;
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                File.WriteAllText(dialog.FileName, json, new UTF8Encoding(false));
                MessageBox.Show("Backup exportado com sucesso.\n\n" + dialog.FileName, "Jarvis - Backup", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível exportar o backup.", exception);
        }
    }

    private void ImportBackup(object sender, EventArgs eventArgs)
    {
        using (OpenFileDialog dialog = new OpenFileDialog())
        {
            dialog.Filter = "Backup JSON do Jarvis (*.json)|*.json|Arquivos JSON (*.json)|*.json";
            dialog.CheckFileExists = true;
            if (dialog.ShowDialog(this) != DialogResult.OK) return;
            if (MessageBox.Show("Importar este backup?\n\nO Jarvis não sobrescreve aplicativos ou modos existentes. Se encontrar conflito, a importação inteira será cancelada.", "Jarvis - Backup", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }
            try
            {
                string json = File.ReadAllText(dialog.FileName, Encoding.UTF8);
                string response = RequestRaw("/backup/import", "POST", json);
                Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(response);
                MessageBox.Show("Importação concluída.\n\nAplicativos: " + Value(result, "applications_imported") + "\nModos: " + Value(result, "modes_imported") + "\n\nAbra novamente as abas para atualizar as listas.", "Jarvis - Backup", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception exception)
            {
                ShowError("A importação foi cancelada. Nenhum dado existente foi sobrescrito.", exception);
            }
        }
    }

    private string Request(string path, string method, object payload)
    {
        if (method == "GET")
        {
            try
            {
                using (WebClient client = NewWebClient())
                {
                    return client.DownloadString(ApiBaseUrl + path);
                }
            }
            catch (WebException exception)
            {
                throw new InvalidOperationException(ReadApiError(exception), exception);
            }
        }
        return RequestRaw(path, method, serializer.Serialize(payload ?? new Dictionary<string, object>()));
    }

    private string RequestRaw(string path, string method, string json)
    {
        try
        {
            using (WebClient client = NewWebClient())
            {
                return client.UploadString(ApiBaseUrl + path, method, json);
            }
        }
        catch (WebException exception)
        {
            throw new InvalidOperationException(ReadApiError(exception), exception);
        }
    }

    private static WebClient NewWebClient()
    {
        WebClient client = new WebClient();
        client.Encoding = Encoding.UTF8;
        client.Headers[HttpRequestHeader.ContentType] = "application/json; charset=utf-8";
        return client;
    }

    private string ReadApiError(WebException exception)
    {
        if (exception.Response == null) return exception.Message;
        try
        {
            using (StreamReader reader = new StreamReader(exception.Response.GetResponseStream(), Encoding.UTF8))
            {
                Dictionary<string, object> error = serializer.Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
                return error.ContainsKey("detail") ? Convert.ToString(error["detail"]) : exception.Message;
            }
        }
        catch { return exception.Message; }
    }

    private static Label NewLabel(string text, int left, int top, Color color)
    {
        Label label = new Label();
        label.Text = text;
        label.ForeColor = color;
        label.AutoSize = true;
        label.Location = new Point(left, top);
        return label;
    }

    private static Button NewButton(string text, int left, int top, int width)
    {
        Button button = new Button();
        button.Text = text;
        button.Location = new Point(left, top);
        button.Size = new Size(width, 34);
        return button;
    }

    private static string Value(Dictionary<string, object> values, string key)
    {
        return values.ContainsKey(key) && values[key] != null ? Convert.ToString(values[key]) : String.Empty;
    }

    private static void ShowError(string prefix, Exception exception)
    {
        MessageBox.Show(prefix + "\n\n" + exception.Message, "Jarvis - Backup", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}

internal sealed class MobileSetupForm : Form
{
    private readonly PictureBox qrPicture = new PictureBox();
    private readonly TextBox urlInput = new TextBox();
    private readonly TextBox remoteUrlInput = new TextBox();
    private readonly TextBox authorizationInput = new TextBox();
    private readonly TextBox setupInput = new TextBox();
    private Image connectQrImage;
    private Image shortcutQrImage;

    public MobileSetupForm(Dictionary<string, object> data)
    {
        Text = "Jarvis - Configurar celular";
        Icon = SystemIcons.Application;
        ClientSize = new Size(850, 580);
        MinimumSize = new Size(850, 580);
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(28, 32, 42);
        ForeColor = Color.WhiteSmoke;
        Font = new Font("Segoe UI", 9.0f);

        Label title = NewLabel("QR Conectar Jarvis", 24, 18, Color.WhiteSmoke);
        title.Font = new Font("Segoe UI Semibold", 17.0f);
        Controls.Add(title);
        Controls.Add(NewLabel("Leia no celular para abrir a página de pareamento. O token fica no aparelho e não é enviado na URL ao servidor.", 27, 52, Color.Gainsboro));

        qrPicture.Location = new Point(28, 92);
        qrPicture.Size = new Size(340, 340);
        qrPicture.BackColor = Color.White;
        qrPicture.SizeMode = PictureBoxSizeMode.Zoom;
        Controls.Add(qrPicture);

        string imageBase64 = Value(data, "qr_png_base64");
        if (!String.IsNullOrWhiteSpace(imageBase64))
        {
            byte[] bytes = Convert.FromBase64String(imageBase64);
            using (MemoryStream stream = new MemoryStream(bytes))
            using (Image image = Image.FromStream(stream))
            {
                connectQrImage = new Bitmap(image);
                qrPicture.Image = connectQrImage;
            }
        }

        string shortcutImageBase64 = Value(data, "shortcut_qr_png_base64");
        if (!String.IsNullOrWhiteSpace(shortcutImageBase64))
        {
            byte[] shortcutBytes = Convert.FromBase64String(shortcutImageBase64);
            using (MemoryStream shortcutStream = new MemoryStream(shortcutBytes))
            using (Image shortcutImage = Image.FromStream(shortcutStream))
            {
                shortcutQrImage = new Bitmap(shortcutImage);
            }
            Button toggleQr = NewButton("Alternar: Conectar / Instalar atalho", 28, 448, 250);
            toggleQr.Click += delegate { qrPicture.Image = Object.ReferenceEquals(qrPicture.Image, connectQrImage) ? shortcutQrImage : connectQrImage; };
            Controls.Add(toggleQr);
        }

        Controls.Add(NewLabel("URL Local (LAN):", 400, 92, Color.FromArgb(100, 210, 255)));
        urlInput.Location = new Point(400, 114);
        urlInput.Size = new Size(420, 27);
        urlInput.ReadOnly = true;
        urlInput.Text = Value(data, "pair_url");
        StyleInput(urlInput);
        Controls.Add(urlInput);

        string remotePairUrl = Value(data, "remote_pair_url");
        Controls.Add(NewLabel("URL Remota (se configurada):", 400, 148, Color.FromArgb(130, 210, 130)));
        remoteUrlInput.Location = new Point(400, 170);
        remoteUrlInput.Size = new Size(420, 27);
        remoteUrlInput.ReadOnly = true;
        remoteUrlInput.Text = String.IsNullOrWhiteSpace(remotePairUrl) ? "(Acesso remoto não configurado)" : remotePairUrl;
        StyleInput(remoteUrlInput);
        Controls.Add(remoteUrlInput);

        Controls.Add(NewLabel("Authorization", 400, 208, Color.WhiteSmoke));
        authorizationInput.Location = new Point(400, 230);
        authorizationInput.Size = new Size(420, 27);
        authorizationInput.ReadOnly = true;
        authorizationInput.Text = Value(data, "authorization");
        StyleInput(authorizationInput);
        Controls.Add(authorizationInput);

        Button copyAuthorization = NewButton("Copiar Bearer", 400, 264, 120);
        copyAuthorization.Click += delegate { CopyText(authorizationInput.Text); };
        Controls.Add(copyAuthorization);

        Button copyLocalUrl = NewButton("Copiar URL Local", 530, 264, 130);
        copyLocalUrl.Click += delegate { CopyText(urlInput.Text); };
        Controls.Add(copyLocalUrl);

        if (!String.IsNullOrWhiteSpace(remotePairUrl))
        {
            Button copyRemoteUrl = NewButton("Copiar Remota", 670, 264, 120);
            copyRemoteUrl.Click += delegate { CopyText(remoteUrlInput.Text); };
            Controls.Add(copyRemoteUrl);
        }

        Controls.Add(NewLabel("Configuração completa / JSON do Atalho", 400, 305, Color.WhiteSmoke));
        setupInput.Location = new Point(400, 327);
        setupInput.Size = new Size(420, 105);
        setupInput.Multiline = true;
        setupInput.ScrollBars = ScrollBars.Vertical;
        setupInput.ReadOnly = true;
        setupInput.Text = Value(data, "setup_text");
        StyleInput(setupInput);
        Controls.Add(setupInput);

        Button copySetup = NewButton("Copiar JSON do Atalho", 400, 440, 170);
        copySetup.Click += delegate { CopyText(setupInput.Text); };
        Controls.Add(copySetup);

        Label hint = NewLabel("No Atalhos: POST + JSON. Use o valor Authorization exatamente como mostrado.", 28, 485, Color.FromArgb(255, 215, 0));
        hint.MaximumSize = new Size(780, 40);
        Controls.Add(hint);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && qrPicture.Image != null)
        {
            qrPicture.Image.Dispose();
        }
        base.Dispose(disposing);
    }

    private static void CopyText(string value)
    {
        try
        {
            Clipboard.SetText(value ?? String.Empty);
        }
        catch
        {
            MessageBox.Show("Não foi possível copiar para a Área de Transferência.", "Jarvis - QR", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private static void StyleInput(TextBox input)
    {
        input.BackColor = Color.FromArgb(20, 24, 33);
        input.ForeColor = Color.WhiteSmoke;
        input.BorderStyle = BorderStyle.FixedSingle;
    }

    private static Label NewLabel(string text, int left, int top, Color color)
    {
        Label label = new Label();
        label.Text = text;
        label.ForeColor = color;
        label.AutoSize = true;
        label.Location = new Point(left, top);
        return label;
    }

    private static Button NewButton(string text, int left, int top, int width)
    {
        Button button = new Button();
        button.Text = text;
        button.Location = new Point(left, top);
        button.Size = new Size(width, 34);
        return button;
    }

    private static string Value(Dictionary<string, object> values, string key)
    {
        return values.ContainsKey(key) && values[key] != null ? Convert.ToString(values[key]) : String.Empty;
    }
}

internal sealed class DeviceManagerForm : Form
{
    private static string ApiBaseUrl { get { return JarvisEnv.ApiBaseUrl; } }
    private readonly JavaScriptSerializer serializer = new JavaScriptSerializer();
    private readonly ListView deviceList = new ListView();
    private readonly TextBox nameInput = new TextBox();
    private readonly TextBox ipInput = new TextBox();
    private readonly TextBox additionalIpsInput = new TextBox();
    private readonly TextBox tokenInput = new TextBox();
    private readonly CheckBox rememberTokenCheckbox = new CheckBox();
    private readonly CheckBox autoIpCheckbox = new CheckBox();
    private readonly CheckBox tokenOnlyCheckbox = new CheckBox();
    private readonly CheckBox enabledCheckbox = new CheckBox();
    private readonly Label editorLabel = new Label();
    private readonly Label lastSeenLabel = new Label();
    private readonly Label tokenHintLabel = new Label();
    private readonly TextBox agentPortInput = new TextBox();
    private readonly TextBox bridgePortInput = new TextBox();
    private readonly CheckBox allowSensitiveActionsCheckbox = new CheckBox();
    private readonly Label networkLanLabel = new Label();
    private readonly Label networkUrlLabel = new Label();
    private readonly TextBox networkShortcutUrlInput = new TextBox();
    private readonly TextBox networkAuthorizationInput = new TextBox();
    // Acesso Remoto
    private readonly CheckBox remoteEnabledCheckbox = new CheckBox();
    private readonly TextBox remoteUrlInput = new TextBox();
    private readonly Label remoteStatusLabel = new Label();
    private string remoteAccessType = "custom";
    private int? currentDeviceId;
    private int? lastIssuedDeviceId;
    private string lastIssuedToken = String.Empty;
    private string localPanelUrl = String.Empty;

    public DeviceManagerForm()
    {
        Text = "Jarvis - Dispositivos e Rede";
        Icon = SystemIcons.Application;
        ClientSize = new Size(1040, 850);
        MinimumSize = new Size(760, 540);
        AutoScroll = true;
        AutoScrollMinSize = new Size(1020, 875);
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(28, 32, 42);
        ForeColor = Color.WhiteSmoke;
        Font = new Font("Segoe UI", 9.0f);
        BuildLayout();
        Load += delegate { FitToWorkingArea(); };
        Shown += delegate
        {
            LoadDevices();
            LoadNetworkSettings();
        };
    }

    public void RefreshData()
    {
        LoadDevices();
        LoadNetworkSettings();
    }

    private void BuildLayout()
    {
        Panel header = new Panel();
        header.Location = new Point(0, 0);
        header.Size = new Size(1040, 78);
        header.BackColor = Color.FromArgb(39, 45, 60);
        Controls.Add(header);

        Label title = NewLabel("Dispositivos e Rede", 24, 15, Color.WhiteSmoke);
        title.Font = new Font("Segoe UI Semibold", 18.0f);
        header.Controls.Add(title);
        Label subtitle = NewLabel("Autorize celulares, tablets e outros clientes e configure as portas de rede do Jarvis.", 27, 49, Color.Gainsboro);
        header.Controls.Add(subtitle);

        deviceList.Location = new Point(24, 95);
        deviceList.Size = new Size(570, 310);
        deviceList.View = View.Details;
        deviceList.FullRowSelect = true;
        deviceList.GridLines = true;
        deviceList.HideSelection = false;
        deviceList.BackColor = Color.FromArgb(20, 24, 33);
        deviceList.ForeColor = Color.WhiteSmoke;
        deviceList.Columns.Add("Nome", 105);
        deviceList.Columns.Add("IPs autorizados", 155);
        deviceList.Columns.Add("Ultimo IP", 95);
        deviceList.Columns.Add("Origem", 55);
        deviceList.Columns.Add("Ativo", 50);
        deviceList.Columns.Add("Ultimo acesso", 110);
        deviceList.SelectedIndexChanged += DeviceListSelectionChanged;
        Controls.Add(deviceList);

        // ── ACESSO LOCAL ──────────────────────────────────────────────────
        Panel localBox = new Panel();
        localBox.Location = new Point(24, 420);
        localBox.Size = new Size(570, 183);
        localBox.BackColor = Color.FromArgb(20, 24, 33);
        localBox.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(localBox);

        Label localTitle = NewLabel("Acesso Local (LAN)", 14, 10, Color.FromArgb(100, 210, 255));
        localTitle.Font = new Font("Segoe UI Semibold", 10.0f);
        localBox.Controls.Add(localTitle);

        Label agentPortLabel = NewLabel("Porta Agent:", 14, 38, Color.WhiteSmoke);
        localBox.Controls.Add(agentPortLabel);
        agentPortInput.Location = new Point(95, 35);
        agentPortInput.Size = new Size(55, 24);
        agentPortInput.BackColor = Color.FromArgb(28, 32, 42);
        agentPortInput.ForeColor = Color.WhiteSmoke;
        agentPortInput.BorderStyle = BorderStyle.FixedSingle;
        localBox.Controls.Add(agentPortInput);

        Label bridgePortLabel = NewLabel("Porta Bridge:", 165, 38, Color.WhiteSmoke);
        localBox.Controls.Add(bridgePortLabel);
        bridgePortInput.Location = new Point(250, 35);
        bridgePortInput.Size = new Size(55, 24);
        bridgePortInput.BackColor = Color.FromArgb(28, 32, 42);
        bridgePortInput.ForeColor = Color.WhiteSmoke;
        bridgePortInput.BorderStyle = BorderStyle.FixedSingle;
        localBox.Controls.Add(bridgePortInput);

        networkLanLabel.Location = new Point(14, 68);
        networkLanLabel.AutoSize = true;
        networkLanLabel.ForeColor = Color.FromArgb(100, 210, 255);
        networkLanLabel.Text = "Instância: detectando...";
        localBox.Controls.Add(networkLanLabel);

        networkUrlLabel.Location = new Point(14, 90);
        networkUrlLabel.AutoSize = true;
        networkUrlLabel.ForeColor = Color.FromArgb(255, 215, 0);
        networkUrlLabel.Text = "URL (LAN-only): http://...local:PORT";
        localBox.Controls.Add(networkUrlLabel);

        Button copyLocalButton = NewButton("Copiar URL LAN", 14, 111, 135);
        copyLocalButton.Height = 25;
        copyLocalButton.Click += CopyLocalPanelUrl;
        localBox.Controls.Add(copyLocalButton);

        allowSensitiveActionsCheckbox.Text = "Permitir fechar aplicativos remotamente (ações sensíveis)";
        allowSensitiveActionsCheckbox.AutoSize = true;
        allowSensitiveActionsCheckbox.Location = new Point(14, 138);
        allowSensitiveActionsCheckbox.ForeColor = Color.FromArgb(255, 215, 0);
        localBox.Controls.Add(allowSensitiveActionsCheckbox);

        Label localHint = NewLabel("Disponível apenas na mesma rede local. Reinicie após alterar portas.", 14, 159, Color.FromArgb(140, 150, 170));
        localHint.MaximumSize = new Size(540, 25);
        localBox.Controls.Add(localHint);

        // ── ACESSO REMOTO ─────────────────────────────────────────────────
        Panel remoteBox = new Panel();
        remoteBox.Location = new Point(24, 613);
        remoteBox.Size = new Size(570, 205);
        remoteBox.BackColor = Color.FromArgb(20, 24, 33);
        remoteBox.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(remoteBox);

        Label remoteTitle = NewLabel("Painel fora de casa (Opcional)", 14, 10, Color.FromArgb(130, 210, 130));
        remoteTitle.Font = new Font("Segoe UI Semibold", 10.0f);
        remoteBox.Controls.Add(remoteTitle);

        remoteEnabledCheckbox.Text = "Já tenho uma URL acessível pela minha VPN ou rede privada";
        remoteEnabledCheckbox.AutoSize = true;
        remoteEnabledCheckbox.Location = new Point(14, 35);
        remoteEnabledCheckbox.ForeColor = Color.WhiteSmoke;
        remoteBox.Controls.Add(remoteEnabledCheckbox);

        remoteBox.Controls.Add(NewLabel("URL que será aberta no celular:", 14, 62, Color.WhiteSmoke));
        remoteUrlInput.Location = new Point(14, 80);
        remoteUrlInput.Size = new Size(458, 24);
        remoteUrlInput.BackColor = Color.FromArgb(28, 32, 42);
        remoteUrlInput.ForeColor = Color.WhiteSmoke;
        remoteUrlInput.BorderStyle = BorderStyle.FixedSingle;
        remoteBox.Controls.Add(remoteUrlInput);

        Button testRemoteBtn = NewButton("Testar", 480, 78, 76);
        testRemoteBtn.Height = 27;
        testRemoteBtn.Click += TestRemoteAccess;
        remoteBox.Controls.Add(testRemoteBtn);

        remoteStatusLabel.Location = new Point(14, 112);
        remoteStatusLabel.AutoSize = true;
        remoteStatusLabel.MaximumSize = new Size(540, 20);
        remoteStatusLabel.ForeColor = Color.FromArgb(194, 205, 223);
        remoteStatusLabel.Text = "";
        remoteBox.Controls.Add(remoteStatusLabel);

        Label remoteSecNote = NewLabel("Ao abrir essa URL, o painel solicita o token do dispositivo.", 14, 132, Color.FromArgb(130, 140, 160));
        remoteSecNote.MaximumSize = new Size(540, 25);
        remoteBox.Controls.Add(remoteSecNote);

        Button copyRemoteButton = NewButton("Copiar URL do painel", 14, 160, 170);
        copyRemoteButton.Height = 28;
        copyRemoteButton.Click += CopyRemotePanelUrl;
        remoteBox.Controls.Add(copyRemoteButton);

        Button remoteHelpButton = NewButton("Como funciona?", 194, 160, 130);
        remoteHelpButton.Height = 28;
        remoteHelpButton.Click += ShowRemoteHelp;
        remoteBox.Controls.Add(remoteHelpButton);

        Button advancedRemoteButton = NewButton("Avançado", 334, 160, 110);
        advancedRemoteButton.Height = 28;
        advancedRemoteButton.Click += ShowAdvancedRemoteOptions;
        remoteBox.Controls.Add(advancedRemoteButton);

        // Botão salvar tudo (portas + remoto)
        Button saveNetButton = NewButton("Salvar Configurações de Rede", 24, 828, 230);
        saveNetButton.Height = 30;
        saveNetButton.Click += SaveNetworkSettings;
        Controls.Add(saveNetButton);

        // Painel Direito: Editor de Dispositivos
        editorLabel.Text = "Novo dispositivo";
        editorLabel.Font = new Font("Segoe UI Semibold", 11.0f);
        editorLabel.AutoSize = true;
        editorLabel.Location = new Point(625, 95);
        Controls.Add(editorLabel);

        AddField("Nome do dispositivo", 125, nameInput);
        AddField("IP local autorizado", 185, ipInput);

        AddField("IPs adicionais de ponte/VPN (um por linha)", 245, additionalIpsInput);
        additionalIpsInput.Multiline = true;
        additionalIpsInput.Height = 48;

        autoIpCheckbox.Text = "Atualizar IP automaticamente quando este token autenticar na LAN";
        autoIpCheckbox.Checked = true;
        autoIpCheckbox.AutoSize = true;
        autoIpCheckbox.Location = new Point(625, 322);
        Controls.Add(autoIpCheckbox);

        tokenOnlyCheckbox.Text = "Autenticar por token no Direct/Relay (IP não identifica o dispositivo)";
        tokenOnlyCheckbox.AutoSize = true;
        tokenOnlyCheckbox.Location = new Point(625, 349);
        tokenOnlyCheckbox.ForeColor = Color.FromArgb(130, 210, 130);
        Controls.Add(tokenOnlyCheckbox);

        enabledCheckbox.Text = "Dispositivo autorizado";
        enabledCheckbox.Checked = true;
        enabledCheckbox.AutoSize = true;
        enabledCheckbox.Location = new Point(625, 376);
        Controls.Add(enabledCheckbox);

        AddField("Token (vazio = gerar ao criar / manter ao editar)", 402, tokenInput);
        tokenInput.UseSystemPasswordChar = true;

        tokenHintLabel.Text = "Token salvo: -";
        tokenHintLabel.ForeColor = Color.FromArgb(194, 205, 223);
        tokenHintLabel.AutoSize = true;
        tokenHintLabel.Location = new Point(625, 460);
        Controls.Add(tokenHintLabel);

        rememberTokenCheckbox.Text = "Guardar tokens neste PC (protegido)";
        rememberTokenCheckbox.AutoSize = true;
        rememberTokenCheckbox.Location = new Point(625, 484);
        rememberTokenCheckbox.ForeColor = Color.FromArgb(130, 210, 130);
        rememberTokenCheckbox.Checked = TokenVault.RememberTokensEnabled();
        rememberTokenCheckbox.CheckedChanged += delegate { TokenVault.SetRememberTokensEnabled(rememberTokenCheckbox.Checked); };
        Controls.Add(rememberTokenCheckbox);

        lastSeenLabel.Text = "Tokens guardados ficam disponíveis para copiar e gerar QR.";
        lastSeenLabel.ForeColor = Color.FromArgb(194, 205, 223);
        lastSeenLabel.AutoSize = true;
        lastSeenLabel.Location = new Point(625, 514);
        Controls.Add(lastSeenLabel);

        Button copyStoredTokenButton = NewButton("Copiar token", 625, 548, 110);
        copyStoredTokenButton.Click += CopyStoredToken;
        Controls.Add(copyStoredTokenButton);

        Button saveButton = NewButton("Salvar", 745, 548, 90);
        saveButton.Click += SaveDevice;
        Controls.Add(saveButton);

        Button rotateButton = NewButton("Novo token", 840, 548, 100);
        rotateButton.Click += RotateToken;
        Controls.Add(rotateButton);

        Button clearButton = NewButton("Limpar", 625, 592, 75);
        clearButton.Click += delegate { ClearEditor(); };
        Controls.Add(clearButton);

        Button deleteButton = NewButton("Revogar", 710, 592, 80);
        deleteButton.Click += DeleteDevice;
        Controls.Add(deleteButton);

        Button qrButton = NewButton("QR / Configurar", 800, 592, 140);
        qrButton.Click += ShowQrSetup;
        Controls.Add(qrButton);

        Label hint = NewLabel("Copiar token e QR permitem escolher um dispositivo salvo, sem selecionar a tabela.", 625, 634, Color.FromArgb(194, 205, 223));
        hint.MaximumSize = new Size(390, 52);
        Controls.Add(hint);

        Label footer = NewLabel("Tokens e Relays entram em vigor imediatamente. Apenas mudanças de porta exigem reinício.", 625, 690, Color.FromArgb(194, 205, 223));
        Controls.Add(footer);
    }

    private static Label NewLabel(string text, int left, int top, Color color)
    {
        Label label = new Label();
        label.Text = text;
        label.ForeColor = color;
        label.AutoSize = true;
        label.Location = new Point(left, top);
        return label;
    }

    private static Button NewButton(string text, int left, int top, int width)
    {
        Button button = new Button();
        button.Text = text;
        button.Location = new Point(left, top);
        button.Size = new Size(width, 33);
        button.FlatStyle = FlatStyle.Flat;
        return button;
    }

    private static void ConfigureCopyField(TextBox input, int top, string text)
    {
        input.Location = new Point(115, top);
        input.Size = new Size(435, 24);
        input.ReadOnly = true;
        input.Text = text;
        input.BackColor = Color.FromArgb(28, 32, 42);
        input.ForeColor = Color.FromArgb(255, 215, 0);
        input.BorderStyle = BorderStyle.FixedSingle;
    }

    private static string ShortcutCommandUrl(string localUrl)
    {
        return (localUrl ?? String.Empty).TrimEnd('/') + "/bridge/v1/command";
    }

    private void AddField(string text, int top, TextBox input)
    {
        Controls.Add(NewLabel(text, 625, top, Color.WhiteSmoke));
        input.Location = new Point(625, top + 22);
        input.Size = new Size(390, 27);
        input.BackColor = Color.FromArgb(20, 24, 33);
        input.ForeColor = Color.WhiteSmoke;
        input.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(input);
    }

    private void LoadNetworkSettings()
    {
        try
        {
            Dictionary<string, object> net = serializer.Deserialize<Dictionary<string, object>>(Request("/network", "GET", null));
            string agentPort = Value(net, "port");
            string bridgePort = Value(net, "bridge_port");
            string localIp = Value(net, "local_ip");
            string instanceName = Value(net, "instance_name");
            string localUrl = Value(net, "local_url");
            bool remoteEnabled = ToBoolean(net.ContainsKey("remote_access_enabled") ? net["remote_access_enabled"] : false);
            string remoteUrl = Value(net, "remote_access_url");
            string remoteType = Value(net, "remote_access_type");

            allowSensitiveActionsCheckbox.Checked = ToBoolean(net.ContainsKey("allow_sensitive_actions") ? net["allow_sensitive_actions"] : false);
            if (String.IsNullOrWhiteSpace(agentPort)) agentPort = JarvisEnv.AgentPort;
            if (String.IsNullOrWhiteSpace(bridgePort)) bridgePort = JarvisEnv.BridgePort;
            if (String.IsNullOrWhiteSpace(localIp)) localIp = "127.0.0.1";

            agentPortInput.Text = agentPort;
            bridgePortInput.Text = bridgePort;
            networkLanLabel.Text = "Jarvis local: " + instanceName + ".local  |  IP atual: " + localIp;
            networkUrlLabel.Text = "URL (LAN-only): " + localUrl;
            localPanelUrl = localUrl;
            networkShortcutUrlInput.Text = ShortcutCommandUrl(localUrl);

            remoteEnabledCheckbox.Checked = remoteEnabled;
            remoteUrlInput.Text = remoteUrl;
            remoteAccessType = String.IsNullOrWhiteSpace(remoteType) ? "custom" : remoteType;
            remoteStatusLabel.Text = remoteEnabled && !String.IsNullOrWhiteSpace(remoteUrl) ? "Painel remoto pronto: " + remoteUrl : "Painel remoto desativado.";
            remoteStatusLabel.ForeColor = remoteEnabled && !String.IsNullOrWhiteSpace(remoteUrl) ? Color.FromArgb(100, 220, 100) : Color.FromArgb(194, 205, 223);
        }
        catch
        {
            agentPortInput.Text = JarvisEnv.AgentPort;
            bridgePortInput.Text = JarvisEnv.BridgePort;
            allowSensitiveActionsCheckbox.Checked = false;
            networkLanLabel.Text = "IP do PC na rede local (LAN): 127.0.0.1";
            string fallbackUrl = "http://127.0.0.1:" + JarvisEnv.BridgePort;
            networkUrlLabel.Text = "URL (LAN-only): " + fallbackUrl;
            localPanelUrl = fallbackUrl;
            networkShortcutUrlInput.Text = ShortcutCommandUrl(fallbackUrl);
            remoteEnabledCheckbox.Checked = false;
            remoteUrlInput.Text = "";
            remoteAccessType = "custom";
        }
    }

    private void SaveNetworkSettings(object sender, EventArgs eventArgs)
    {
        int aPort, bPort;
        if (!int.TryParse(agentPortInput.Text.Trim(), out aPort) || aPort < 1024 || aPort > 65535)
        {
            MessageBox.Show("Informe uma porta válida para o Agent (entre 1024 e 65535).", "Jarvis - Portas de Rede", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (!int.TryParse(bridgePortInput.Text.Trim(), out bPort) || bPort < 1024 || bPort > 65535)
        {
            MessageBox.Show("Informe uma porta válida para a Bridge (entre 1024 e 65535).", "Jarvis - Portas de Rede", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (aPort == bPort)
        {
            MessageBox.Show("A porta do Agent e da Bridge devem ser diferentes.", "Jarvis - Portas de Rede", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        string rawRemoteUrl = remoteUrlInput.Text.Trim();
        if (remoteEnabledCheckbox.Checked && !String.IsNullOrWhiteSpace(rawRemoteUrl))
        {
            if (!rawRemoteUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase) && !rawRemoteUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("A URL de acesso remoto deve começar com http:// ou https:// (ex: https://jarvis.exemplo.com).", "Jarvis - Acesso Remoto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        Dictionary<string, object> payload = new Dictionary<string, object>();
        payload["port"] = aPort;
        payload["bridge_port"] = bPort;
        payload["allow_sensitive_actions"] = allowSensitiveActionsCheckbox.Checked;
        payload["remote_access_enabled"] = remoteEnabledCheckbox.Checked;
        payload["remote_access_url"] = rawRemoteUrl;
        payload["remote_access_type"] = remoteAccessType;

        try
        {
            Dictionary<string, object> res = serializer.Deserialize<Dictionary<string, object>>(Request("/network", "PUT", payload));
            string localIp = Value(res, "local_ip");
            string instanceName = Value(res, "instance_name");
            string localUrl = Value(res, "local_url");
            if (String.IsNullOrWhiteSpace(localIp)) localIp = "127.0.0.1";
            networkLanLabel.Text = "Jarvis local: " + instanceName + ".local  |  IP atual: " + localIp;
            networkUrlLabel.Text = "URL (LAN-only): " + localUrl;
            localPanelUrl = localUrl;
            networkShortcutUrlInput.Text = ShortcutCommandUrl(localUrl);

            bool remEnabled = ToBoolean(res.ContainsKey("remote_access_enabled") ? res["remote_access_enabled"] : false);
            string remUrl = Value(res, "remote_access_url");
            remoteStatusLabel.Text = remEnabled && !String.IsNullOrWhiteSpace(remUrl) ? "Painel remoto pronto: " + remUrl : "Painel remoto desativado.";
            remoteStatusLabel.ForeColor = remEnabled && !String.IsNullOrWhiteSpace(remUrl) ? Color.FromArgb(100, 220, 100) : Color.FromArgb(194, 205, 223);

            MessageBox.Show("Configurações de rede atualizadas com sucesso!\n\nPainel local: " + localUrl + "\nPainel fora de casa: " + (remEnabled ? remUrl : "desativado") + "\nFechamento remoto: " + (allowSensitiveActionsCheckbox.Checked ? "permitido" : "bloqueado") + "\n\nBasta abrir a URL no navegador e informar o token. Se alterou portas, reinicie o Agent pelo ícone da bandeja.", "Jarvis - Rede Salva", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível salvar as configurações de rede.", exception);
        }
    }

    private void TestRemoteAccess(object sender, EventArgs eventArgs)
    {
        string rawUrl = remoteUrlInput.Text.Trim();
        if (String.IsNullOrWhiteSpace(rawUrl))
        {
            MessageBox.Show("Informe a URL do endpoint remoto para testar (ex: https://jarvis.exemplo.com).", "Jarvis - Teste de Acesso Remoto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        remoteStatusLabel.Text = "Testando conexão com " + rawUrl + "...";
        remoteStatusLabel.ForeColor = Color.FromArgb(255, 215, 0);
        Application.DoEvents();

        Dictionary<string, object> payload = new Dictionary<string, object>();
        payload["url"] = rawUrl;

        try
        {
            Dictionary<string, object> res = serializer.Deserialize<Dictionary<string, object>>(Request("/network/test-remote", "POST", payload));
            bool success = ToBoolean(res.ContainsKey("success") ? res["success"] : false);
            string statusMsg = Value(res, "message");
            string statusCode = Value(res, "status");

            if (success)
            {
                remoteStatusLabel.Text = "Conectado: " + statusMsg;
                remoteStatusLabel.ForeColor = Color.FromArgb(100, 220, 100);
                MessageBox.Show("Teste bem-sucedido!\n\n" + statusMsg + "\n\nURL testada: " + rawUrl, "Jarvis - Teste de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                remoteStatusLabel.Text = "Falha: " + statusMsg;
                remoteStatusLabel.ForeColor = Color.FromArgb(255, 120, 120);
                MessageBox.Show("Não foi possível conectar ao endpoint remoto.\n\nStatus: " + statusCode + "\nDetalhes: " + statusMsg + "\n\nVerifique se o host está online e apontando para a porta da Bridge.", "Jarvis - Teste de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        catch (Exception exception)
        {
            remoteStatusLabel.Text = "Erro ao testar: " + exception.Message;
            remoteStatusLabel.ForeColor = Color.FromArgb(255, 120, 120);
            ShowError("Falha ao executar teste de conexão remota.", exception);
        }
    }

    private void CopyRemotePanelUrl(object sender, EventArgs eventArgs)
    {
        string baseUrl = remoteUrlInput.Text.Trim().TrimEnd('/');
        if (String.IsNullOrWhiteSpace(baseUrl))
        {
            MessageBox.Show("Informe primeiro a URL acessível pela VPN ou rede privada.", "Jarvis - Painel Remoto", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        string panelUrl = baseUrl + "/pair";
        try
        {
            Clipboard.SetText(panelUrl);
            MessageBox.Show("URL do painel copiada:\n\n" + panelUrl + "\n\nAbra no celular e informe o token do dispositivo.", "Jarvis - Painel Remoto", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível copiar a URL do painel.", exception);
        }
    }

    private void CopyLocalPanelUrl(object sender, EventArgs eventArgs)
    {
        if (String.IsNullOrWhiteSpace(localPanelUrl))
        {
            MessageBox.Show("A URL local ainda está sendo detectada.", "Jarvis - Acesso Local", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        try
        {
            Clipboard.SetText(localPanelUrl);
            MessageBox.Show("URL LAN copiada. Abra-a no celular conectado à mesma rede.", "Jarvis - Acesso Local", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível copiar a URL local.", exception);
        }
    }

    private void ShowRemoteHelp(object sender, EventArgs eventArgs)
    {
        MessageBox.Show(
            "Uso simples:\n\n1. Sua VPN ou rede privada precisa alcançar este PC.\n2. Cole aqui o endereço fornecido por ela.\n3. Salve e clique em Copiar URL do painel.\n4. No celular, abra a URL e informe o token.\n\nSe a VPN estiver somente em outro aparelho da casa, esse aparelho precisa estar configurado como gateway. Essa configuração fica em Avançado e não é obrigatória para quem usa VPN diretamente no PC.",
            "Jarvis - Como abrir o painel fora de casa",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }

    private void ShowAdvancedRemoteOptions(object sender, EventArgs eventArgs)
    {
        DialogResult choice = MessageBox.Show(
            "Estas opções são somente para quando a VPN termina em outro aparelho da rede.\n\nSim: gerar configuração de gateway/Relay.\nNão: revogar todos os gateways.\nCancelar: voltar sem alterar nada.",
            "Jarvis - Acesso remoto avançado",
            MessageBoxButtons.YesNoCancel,
            MessageBoxIcon.Information);
        if (choice == DialogResult.Yes)
        {
            GenerateRelayBootstrap(sender, eventArgs);
        }
        else if (choice == DialogResult.No)
        {
            RevokeRelays(sender, eventArgs);
        }
    }

    private void FitToWorkingArea()
    {
        Rectangle workingArea = Screen.FromControl(this).WorkingArea;
        int availableWidth = Math.Max(MinimumSize.Width, workingArea.Width - 20);
        int availableHeight = Math.Max(MinimumSize.Height, workingArea.Height - 20);
        Size = new Size(Math.Min(Width, availableWidth), Math.Min(Height, availableHeight));
    }

    private void GenerateRelayBootstrap(object sender, EventArgs eventArgs)
    {
        if (MessageBox.Show("Gerar uma nova credencial de Relay? O token completo será exibido e copiado somente agora.", "Jarvis - Relay", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
        {
            return;
        }
        try
        {
            remoteAccessType = "relay";
            Dictionary<string, object> payload = new Dictionary<string, object>();
            payload["name"] = "Relay remoto";
            Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(Request("/relays/bootstrap", "POST", payload));
            Dictionary<string, object> environment = result.ContainsKey("environment") ? result["environment"] as Dictionary<string, object> : null;
            if (environment == null) throw new InvalidOperationException("O Jarvis não retornou a configuração do Relay.");
            List<string> lines = new List<string>();
            foreach (KeyValuePair<string, object> entry in environment)
            {
                lines.Add(entry.Key + "=" + Convert.ToString(entry.Value));
            }
            string configuration = String.Join(Environment.NewLine, lines.ToArray());
            try { Clipboard.SetText(configuration); } catch { }
            MessageBox.Show("Configuração copiada para a Área de Transferência. Guarde o token com segurança:\n\n" + configuration + "\n\nExecute python -m relay a partir da pasta _arquivos no dispositivo gateway.", "Jarvis - Relay", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível gerar a configuração do Relay.", exception);
        }
    }

    private void RevokeRelays(object sender, EventArgs eventArgs)
    {
        if (MessageBox.Show("Revogar todas as credenciais de Relay? Clientes locais e tokens de celulares não serão alterados.", "Jarvis - Relay", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
        {
            return;
        }
        try
        {
            Request("/relays/revoke-all", "POST", new Dictionary<string, object>());
            MessageBox.Show("Todas as credenciais de Relay foram revogadas.", "Jarvis - Relay", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível revogar os Relays.", exception);
        }
    }

    private void LoadDevices()
    {
        try
        {
            ArrayList response = serializer.Deserialize<ArrayList>(Request("/devices", "GET", null));
            deviceList.Items.Clear();
            foreach (object entry in response)
            {
                Dictionary<string, object> device = ToDictionary(entry);
                ListViewItem item = new ListViewItem(Value(device, "name"));
                item.SubItems.Add(AuthorizedIpsText(device));
                item.SubItems.Add(Value(device, "last_ip"));
                item.SubItems.Add(Value(device, "source_policy") == "token" ? "Token" : "IP");
                item.SubItems.Add(ToBoolean(device.ContainsKey("enabled") ? device["enabled"] : false) ? "Sim" : "Nao");
                item.SubItems.Add(String.IsNullOrWhiteSpace(Value(device, "last_seen_at")) ? "Nunca" : Value(device, "last_seen_at"));
                item.Tag = device;
                deviceList.Items.Add(item);
            }
        }
        catch (Exception exception)
        {
            ShowError("Nao foi possivel carregar os dispositivos.", exception);
        }
    }

    private void DeviceListSelectionChanged(object sender, EventArgs eventArgs)
    {
        if (deviceList.SelectedItems.Count == 0)
        {
            return;
        }
        Dictionary<string, object> device = (Dictionary<string, object>)deviceList.SelectedItems[0].Tag;
        currentDeviceId = Convert.ToInt32(device["id"]);
        editorLabel.Text = "Editar dispositivo";
        nameInput.Text = Value(device, "name");
        ipInput.Text = Value(device, "configured_ip");
        additionalIpsInput.Lines = ToStringArray(device.ContainsKey("additional_ips") ? device["additional_ips"] : null);
        autoIpCheckbox.Checked = ToBoolean(device.ContainsKey("auto_update_ip") ? device["auto_update_ip"] : false);
        tokenOnlyCheckbox.Checked = Value(device, "source_policy") == "token";
        enabledCheckbox.Checked = ToBoolean(device.ContainsKey("enabled") ? device["enabled"] : true);
        tokenInput.Clear();
        bool tokenIsStored = TokenVault.TryGet(currentDeviceId.Value, out lastIssuedToken);
        lastIssuedDeviceId = tokenIsStored ? currentDeviceId : null;
        string hint = Value(device, "token_hint");
        tokenHintLabel.Text = tokenIsStored ? "Token deste dispositivo guardado neste PC (protegido)." : (String.IsNullOrWhiteSpace(hint) ? "Token salvo: configurado" : "Token salvo: ..." + hint);
        string lastSeen = Value(device, "last_seen_at");
        string lastIp = Value(device, "last_ip");
        lastSeenLabel.Text = "Ultimo acesso: " + (String.IsNullOrWhiteSpace(lastSeen) ? "nunca" : lastSeen) + (String.IsNullOrWhiteSpace(lastIp) ? "" : " | IP " + lastIp);
    }

    private void SaveDevice(object sender, EventArgs eventArgs)
    {
        if (String.IsNullOrWhiteSpace(nameInput.Text))
        {
            MessageBox.Show("Informe um nome para o dispositivo.", "Jarvis - Dispositivos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (!tokenOnlyCheckbox.Checked && !autoIpCheckbox.Checked && String.IsNullOrWhiteSpace(ipInput.Text))
        {
            MessageBox.Show("Informe o IP local ou habilite a atualizacao automatica de IP.", "Jarvis - Dispositivos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        Dictionary<string, object> payload = new Dictionary<string, object>();
        payload["name"] = nameInput.Text.Trim();
        payload["ip_address"] = ipInput.Text.Trim();
        payload["additional_ip_addresses"] = NonEmptyLines(additionalIpsInput.Lines);
        payload["auto_update_ip"] = autoIpCheckbox.Checked;
        payload["source_policy"] = tokenOnlyCheckbox.Checked ? "token" : "ip";
        payload["enabled"] = enabledCheckbox.Checked;
        payload["token"] = tokenInput.Text.Trim();

        try
        {
            if (currentDeviceId.HasValue && !rememberTokenCheckbox.Checked) TokenVault.Remove(currentDeviceId.Value);
            string path = currentDeviceId.HasValue ? "/devices/" + currentDeviceId.Value : "/devices";
            Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(Request(path, currentDeviceId.HasValue ? "PUT" : "POST", payload));
            HandleIssuedToken(result);
            LoadDevices();
            ClearEditor();
        }
        catch (Exception exception)
        {
            ShowError("Nao foi possivel salvar o dispositivo.", exception);
        }
    }

    private void RotateToken(object sender, EventArgs eventArgs)
    {
        if (!currentDeviceId.HasValue)
        {
            MessageBox.Show("Selecione um dispositivo antes de gerar outro token.", "Jarvis - Dispositivos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (MessageBox.Show("Gerar um token novo? O token anterior deixara de funcionar imediatamente.", "Jarvis - Dispositivos", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
        {
            return;
        }
        try
        {
            Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(Request("/devices/" + currentDeviceId.Value + "/rotate-token", "POST", new Dictionary<string, object>()));
            HandleIssuedToken(result);
            LoadDevices();
        }
        catch (Exception exception)
        {
            ShowError("Nao foi possivel gerar o novo token.", exception);
        }
    }

    private void HandleIssuedToken(Dictionary<string, object> result)
    {
        if (!result.ContainsKey("issued_token") || result["issued_token"] == null)
        {
            MessageBox.Show("Dispositivo salvo. As alteracoes ja estao ativas.", "Jarvis - Dispositivos", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        string token = Convert.ToString(result["issued_token"]);
        lastIssuedToken = token;
        int issuedId;
        if (result.ContainsKey("id") && Int32.TryParse(Convert.ToString(result["id"]), out issuedId))
        {
            lastIssuedDeviceId = issuedId;
        }
        if (rememberTokenCheckbox.Checked && lastIssuedDeviceId.HasValue)
        {
            TokenVault.Save(lastIssuedDeviceId.Value, token);
            tokenHintLabel.Text = "Token salvo neste PC (protegido).";
        }
        try { Clipboard.SetText(token); } catch { }
        MessageBox.Show("Token gerado e copiado para a Area de Transferencia.\n\n" + token + "\n\n" + (rememberTokenCheckbox.Checked ? "Ele também foi guardado de forma protegida neste PC." : "Marque Guardar token neste PC se quiser copiar e gerar o QR novamente depois."), "Token do dispositivo", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void CopyStoredToken(object sender, EventArgs eventArgs)
    {
        string token = InstallationToken();
        if (String.IsNullOrWhiteSpace(token)) return;
        try
        {
            Clipboard.SetText(token);
            lastIssuedToken = token;
            MessageBox.Show("Token único desta instalação copiado para a Área de Transferência.", "Jarvis - Token", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível copiar o token.", exception);
        }
    }

    private int? ChooseStoredTokenDevice()
    {
        Form chooser = new Form();
        chooser.Text = "Jarvis - Escolher dispositivo";
        chooser.StartPosition = FormStartPosition.CenterParent;
        chooser.ClientSize = new Size(360, 245);
        chooser.BackColor = Color.FromArgb(28, 32, 42);
        chooser.ForeColor = Color.WhiteSmoke;
        chooser.Font = new Font("Segoe UI", 9.0f);
        chooser.FormBorderStyle = FormBorderStyle.FixedDialog;
        chooser.MaximizeBox = false;
        chooser.MinimizeBox = false;
        chooser.Controls.Add(NewLabel("Escolha o dispositivo com token guardado:", 16, 14, Color.WhiteSmoke));
        ListBox devices = new ListBox();
        devices.Location = new Point(16, 42);
        devices.Size = new Size(328, 145);
        devices.BackColor = Color.FromArgb(20, 24, 33);
        devices.ForeColor = Color.WhiteSmoke;
        foreach (ListViewItem item in deviceList.Items)
        {
            Dictionary<string, object> device = item.Tag as Dictionary<string, object>;
            if (device == null || !device.ContainsKey("id")) continue;
            int id = Convert.ToInt32(device["id"]);
            string token;
            if (TokenVault.TryGet(id, out token)) devices.Items.Add(new DeviceChoice(Value(device, "name"), id));
        }
        chooser.Controls.Add(devices);
        Button choose = NewButton("Usar", 180, 202, 78); choose.DialogResult = DialogResult.OK; chooser.Controls.Add(choose);
        Button cancel = NewButton("Cancelar", 266, 202, 78); cancel.DialogResult = DialogResult.Cancel; chooser.Controls.Add(cancel);
        chooser.AcceptButton = choose;
        chooser.CancelButton = cancel;
        if (devices.Items.Count == 0)
        {
            MessageBox.Show("Nenhum token foi guardado neste PC ainda.", "Jarvis - Token", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return null;
        }
        devices.SelectedIndex = 0;
        if (chooser.ShowDialog(this) != DialogResult.OK || devices.SelectedItem == null) return null;
        return ((DeviceChoice)devices.SelectedItem).Id;
    }

    private sealed class DeviceChoice
    {
        public readonly int Id;
        private readonly string name;
        public DeviceChoice(string deviceName, int deviceId) { name = deviceName; Id = deviceId; }
        public override string ToString() { return name; }
    }

    private void ShowQrSetup(object sender, EventArgs eventArgs)
    {
        lastIssuedToken = InstallationToken();
        if (String.IsNullOrWhiteSpace(lastIssuedToken)) return;
        try
        {
            Dictionary<string, object> payload = new Dictionary<string, object>();
            payload["token"] = lastIssuedToken;
            Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(Request("/mobile-setup", "POST", payload));
            using (MobileSetupForm form = new MobileSetupForm(result))
            {
                form.ShowDialog(this);
            }
        }
        catch (Exception exception)
        {
            ShowError("Nao foi possivel gerar o QR local.", exception);
        }
    }

    private string InstallationToken()
    {
        string token;
        if (TokenVault.TryGetInstallation(out token)) return token;
        if (!String.IsNullOrWhiteSpace(lastIssuedToken)) return lastIssuedToken;
        try
        {
            Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(Request("/installation-token", "POST", new Dictionary<string, object>()));
            token = Value(result, "token");
            if (String.IsNullOrWhiteSpace(token)) throw new InvalidOperationException("O Jarvis não retornou o token da instalação.");
            lastIssuedToken = token;
            if (rememberTokenCheckbox.Checked) TokenVault.SaveInstallation(token);
            return token;
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível preparar o token único da instalação.", exception);
            return String.Empty;
        }
    }

    private void DeleteDevice(object sender, EventArgs eventArgs)
    {
        if (!currentDeviceId.HasValue)
        {
            MessageBox.Show("Selecione um dispositivo para revogar.", "Jarvis - Dispositivos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (MessageBox.Show("Revogar este dispositivo? Ele perdera acesso a Bridge.", "Jarvis - Dispositivos", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
        {
            return;
        }
        try
        {
            int deletedId = currentDeviceId.Value;
            Request("/devices/" + deletedId, "DELETE", new Dictionary<string, object>());
            if (lastIssuedDeviceId.HasValue && lastIssuedDeviceId.Value == deletedId)
            {
                lastIssuedDeviceId = null;
                lastIssuedToken = String.Empty;
            }
            LoadDevices();
            ClearEditor();
        }
        catch (Exception exception)
        {
            ShowError("Nao foi possivel revogar o dispositivo.", exception);
        }
    }

    private void ClearEditor()
    {
        currentDeviceId = null;
        editorLabel.Text = "Novo dispositivo";
        nameInput.Clear();
        ipInput.Clear();
        additionalIpsInput.Clear();
        tokenInput.Clear();
        autoIpCheckbox.Checked = true;
        tokenOnlyCheckbox.Checked = false;
        enabledCheckbox.Checked = true;
        tokenHintLabel.Text = "Token salvo: -";
        lastSeenLabel.Text = "Ultimo acesso: nunca";
        deviceList.SelectedItems.Clear();
    }

    private string Request(string path, string method, object payload)
    {
        try
        {
            using (WebClient client = NewWebClient())
            {
                if (method == "GET")
                {
                    return client.DownloadString(ApiBaseUrl + path);
                }
                if (method == "DELETE")
                {
                    return client.UploadString(ApiBaseUrl + path, "DELETE", serializer.Serialize(payload ?? new Dictionary<string, object>()));
                }
                return client.UploadString(ApiBaseUrl + path, method, serializer.Serialize(payload ?? new Dictionary<string, object>()));
            }
        }
        catch (WebException exception)
        {
            throw new InvalidOperationException(ReadApiError(exception), exception);
        }
    }

    private static WebClient NewWebClient()
    {
        WebClient client = new WebClient();
        client.Encoding = Encoding.UTF8;
        client.Headers[HttpRequestHeader.ContentType] = "application/json; charset=utf-8";
        return client;
    }

    private string ReadApiError(WebException exception)
    {
        if (exception.Response == null)
        {
            return exception.Message;
        }
        try
        {
            using (StreamReader reader = new StreamReader(exception.Response.GetResponseStream(), Encoding.UTF8))
            {
                Dictionary<string, object> error = serializer.Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
                return error.ContainsKey("detail") ? Convert.ToString(error["detail"]) : exception.Message;
            }
        }
        catch
        {
            return exception.Message;
        }
    }

    private static Dictionary<string, object> ToDictionary(object value)
    {
        return value as Dictionary<string, object> ?? new Dictionary<string, object>();
    }

    private static string Value(Dictionary<string, object> values, string key)
    {
        return values.ContainsKey(key) && values[key] != null ? Convert.ToString(values[key]) : String.Empty;
    }

    private static string AuthorizedIpsText(Dictionary<string, object> device)
    {
        List<string> values = new List<string>();
        string primary = Value(device, "configured_ip");
        if (!String.IsNullOrWhiteSpace(primary)) values.Add(primary);
        values.AddRange(ToStringArray(device.ContainsKey("additional_ips") ? device["additional_ips"] : null));
        return String.Join(", ", values.ToArray());
    }

    private static string[] ToStringArray(object value)
    {
        ArrayList values = value as ArrayList;
        if (values == null) return new string[0];
        List<string> result = new List<string>();
        foreach (object entry in values) result.Add(Convert.ToString(entry));
        return result.ToArray();
    }

    private static string[] NonEmptyLines(string[] lines)
    {
        List<string> result = new List<string>();
        foreach (string line in lines)
        {
            if (!String.IsNullOrWhiteSpace(line)) result.Add(line.Trim());
        }
        return result.ToArray();
    }

    private static bool ToBoolean(object value)
    {
        if (value is bool)
        {
            return (bool)value;
        }
        return Convert.ToString(value) == "1" || Convert.ToString(value).Equals("true", StringComparison.OrdinalIgnoreCase);
    }

    private static void ShowError(string prefix, Exception exception)
    {
        MessageBox.Show(prefix + "\n\n" + exception.Message, "Jarvis - Dispositivos", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}

internal sealed class ModeManagerForm : Form
{
    private static string ApiBaseUrl { get { return JarvisEnv.ApiBaseUrl; } }

    private readonly JavaScriptSerializer serializer = new JavaScriptSerializer();
    private readonly ListView modeList = new ListView();
    private readonly TextBox nameInput = new TextBox();
    private readonly TextBox slugInput = new TextBox();
    private readonly CheckedListBox openApplicationChoices = new CheckedListBox();
    private readonly CheckedListBox closeApplicationChoices = new CheckedListBox();
    private readonly CheckBox enabledCheckbox = new CheckBox();
    private readonly Label editorLabel = new Label();
    private readonly List<Dictionary<string, object>> applications = new List<Dictionary<string, object>>();
    private int? currentModeId;

    public ModeManagerForm()
    {
        Text = "Jarvis - Modos";
        Icon = SystemIcons.Application;
        ClientSize = new Size(850, 560);
        MinimumSize = new Size(850, 560);
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(28, 32, 42);
        ForeColor = Color.WhiteSmoke;
        Font = new Font("Segoe UI", 9.0f);

        BuildLayout();
        Shown += delegate
        {
            LoadApplications();
            LoadModes();
        };
    }

    public void RefreshData()
    {
        LoadApplications();
        LoadModes();
    }

    private void BuildLayout()
    {
        Panel header = new Panel();
        header.Location = new Point(0, 0);
        header.Size = new Size(850, 78);
        header.BackColor = Color.FromArgb(39, 45, 60);
        Controls.Add(header);

        Label title = NewLabel("Modos do Jarvis", 24, 14, Color.WhiteSmoke);
        title.Font = new Font("Segoe UI Semibold", 18.0f);
        header.Controls.Add(title);

        Label subtitle = NewLabel("Escolha os aplicativos que devem fechar e abrir em cada modo.", 27, 49, Color.Gainsboro);
        header.Controls.Add(subtitle);

        Label instructions = NewLabel("1. Dê um nome  2. Marque o que fecha e abre  3. Salve  4. Clique em Testar", 24, 95, Color.FromArgb(194, 205, 223));
        Controls.Add(instructions);

        Label modesLabel = NewLabel("Modos cadastrados", 24, 128, Color.WhiteSmoke);
        modesLabel.Font = new Font("Segoe UI Semibold", 11.0f);
        Controls.Add(modesLabel);

        modeList.Location = new Point(24, 154);
        modeList.Size = new Size(380, 325);
        modeList.View = View.Details;
        modeList.FullRowSelect = true;
        modeList.GridLines = true;
        modeList.HideSelection = false;
        modeList.BackColor = Color.FromArgb(20, 24, 33);
        modeList.ForeColor = Color.WhiteSmoke;
        modeList.Columns.Add("Nome", 145);
        modeList.Columns.Add("Identificador", 120);
        modeList.Columns.Add("Apps", 70);
        modeList.SelectedIndexChanged += ModeListSelectionChanged;
        Controls.Add(modeList);

        editorLabel.Text = "Novo modo";
        editorLabel.Font = new Font("Segoe UI Semibold", 11.0f);
        editorLabel.AutoSize = true;
        editorLabel.Location = new Point(440, 128);
        Controls.Add(editorLabel);

        AddField("Nome", 154, nameInput);
        AddField("Identificador (ex.: trabalho)", 211, slugInput);

        Controls.Add(NewLabel("Fechar primeiro", 440, 268, Color.WhiteSmoke));
        closeApplicationChoices.Location = new Point(440, 289);
        closeApplicationChoices.Size = new Size(180, 145);
        closeApplicationChoices.CheckOnClick = true;
        closeApplicationChoices.BackColor = Color.FromArgb(20, 24, 33);
        closeApplicationChoices.ForeColor = Color.WhiteSmoke;
        closeApplicationChoices.BorderStyle = BorderStyle.FixedSingle;
        closeApplicationChoices.ItemCheck += CloseApplicationItemCheck;
        Controls.Add(closeApplicationChoices);

        Controls.Add(NewLabel("Abrir depois", 635, 268, Color.WhiteSmoke));
        openApplicationChoices.Location = new Point(635, 289);
        openApplicationChoices.Size = new Size(180, 145);
        openApplicationChoices.CheckOnClick = true;
        openApplicationChoices.BackColor = Color.FromArgb(20, 24, 33);
        openApplicationChoices.ForeColor = Color.WhiteSmoke;
        openApplicationChoices.BorderStyle = BorderStyle.FixedSingle;
        openApplicationChoices.ItemCheck += OpenApplicationItemCheck;
        Controls.Add(openApplicationChoices);

        enabledCheckbox.Text = "Modo ativo";
        enabledCheckbox.Checked = true;
        enabledCheckbox.AutoSize = true;
        enabledCheckbox.Location = new Point(440, 448);
        Controls.Add(enabledCheckbox);

        Button saveButton = NewButton("Salvar modo", 440, 485, 115);
        saveButton.Click += SaveMode;
        Controls.Add(saveButton);

        Button testButton = NewButton("Testar", 565, 485, 80);
        testButton.Click += TestMode;
        Controls.Add(testButton);

        Button clearButton = NewButton("Limpar", 655, 485, 75);
        clearButton.Click += delegate { ClearEditor(); };
        Controls.Add(clearButton);

        Button deleteButton = NewButton("Excluir", 740, 485, 75);
        deleteButton.Click += DeleteMode;
        Controls.Add(deleteButton);

        Label footer = NewLabel("O modo fecha os aplicativos marcados à esquerda e depois abre os marcados à direita.", 24, 520, Color.FromArgb(190, 201, 220));
        Controls.Add(footer);
    }

    private static Label NewLabel(string text, int left, int top, Color color)
    {
        Label label = new Label();
        label.Text = text;
        label.ForeColor = color;
        label.AutoSize = true;
        label.Location = new Point(left, top);
        return label;
    }

    private static Button NewButton(string text, int left, int top, int width)
    {
        Button button = new Button();
        button.Text = text;
        button.Location = new Point(left, top);
        button.Size = new Size(width, 34);
        return button;
    }

    private void AddField(string text, int top, TextBox input)
    {
        Controls.Add(NewLabel(text, 440, top, Color.WhiteSmoke));
        input.Location = new Point(440, top + 21);
        input.Size = new Size(375, 27);
        input.BackColor = Color.FromArgb(20, 24, 33);
        input.ForeColor = Color.WhiteSmoke;
        input.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(input);
    }

    private void LoadApplications()
    {
        try
        {
            ArrayList response = serializer.Deserialize<ArrayList>(Request("/applications", "GET", null));
            applications.Clear();
            openApplicationChoices.Items.Clear();
            closeApplicationChoices.Items.Clear();
            foreach (object entry in response)
            {
                Dictionary<string, object> application = ToDictionary(entry);
                if (!ToBoolean(application.ContainsKey("enabled") ? application["enabled"] : true))
                {
                    continue;
                }
                applications.Add(application);
                string label = Value(application, "name") + " (" + Value(application, "identifier") + ")";
                openApplicationChoices.Items.Add(label);
                closeApplicationChoices.Items.Add(label);
            }
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível carregar os aplicativos.", exception);
        }
    }

    private void LoadModes()
    {
        try
        {
            ArrayList response = serializer.Deserialize<ArrayList>(Request("/modes", "GET", null));
            modeList.Items.Clear();
            foreach (object entry in response)
            {
                Dictionary<string, object> mode = ToDictionary(entry);
                ListViewItem item = new ListViewItem(Value(mode, "name"));
                item.SubItems.Add(Value(mode, "slug"));
                item.SubItems.Add(Value(mode, "step_count"));
                item.Tag = mode;
                modeList.Items.Add(item);
            }
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível carregar os modos.", exception);
        }
    }

    private void ModeListSelectionChanged(object sender, EventArgs eventArgs)
    {
        if (modeList.SelectedItems.Count == 0)
        {
            return;
        }

        Dictionary<string, object> mode = (Dictionary<string, object>)modeList.SelectedItems[0].Tag;
        currentModeId = Convert.ToInt32(mode["id"]);
        editorLabel.Text = "Editar modo";
        nameInput.Text = Value(mode, "name");
        slugInput.Text = Value(mode, "slug");
        enabledCheckbox.Checked = ToBoolean(mode.ContainsKey("enabled") ? mode["enabled"] : true);
        for (int index = 0; index < openApplicationChoices.Items.Count; index++)
        {
            openApplicationChoices.SetItemChecked(index, false);
            closeApplicationChoices.SetItemChecked(index, false);
        }

        HashSet<string> selectedApplications = new HashSet<string>(ToStringArray(mode.ContainsKey("applications") ? mode["applications"] : null), StringComparer.OrdinalIgnoreCase);
        HashSet<string> selectedCloseApplications = new HashSet<string>(ToStringArray(mode.ContainsKey("close_applications") ? mode["close_applications"] : null), StringComparer.OrdinalIgnoreCase);
        for (int index = 0; index < applications.Count; index++)
        {
            openApplicationChoices.SetItemChecked(index, selectedApplications.Contains(Value(applications[index], "identifier")));
            closeApplicationChoices.SetItemChecked(index, selectedCloseApplications.Contains(Value(applications[index], "identifier")));
        }
    }

    private void SaveMode(object sender, EventArgs eventArgs)
    {
        if (String.IsNullOrWhiteSpace(nameInput.Text))
        {
            MessageBox.Show("Informe um nome para o modo.", "Jarvis - Modos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        List<string> selectedApplications = new List<string>();
        List<string> selectedCloseApplications = new List<string>();
        for (int index = 0; index < applications.Count; index++)
        {
            if (openApplicationChoices.GetItemChecked(index))
            {
                selectedApplications.Add(Value(applications[index], "identifier"));
            }
            if (closeApplicationChoices.GetItemChecked(index))
            {
                selectedCloseApplications.Add(Value(applications[index], "identifier"));
            }
        }
        if (selectedApplications.Count == 0 && selectedCloseApplications.Count == 0)
        {
            MessageBox.Show("Marque pelo menos um aplicativo para abrir ou fechar.", "Jarvis - Modos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        Dictionary<string, object> payload = new Dictionary<string, object>();
        payload["name"] = nameInput.Text.Trim();
        payload["slug"] = slugInput.Text.Trim();
        payload["enabled"] = enabledCheckbox.Checked;
        payload["applications"] = selectedApplications.ToArray();
        payload["close_applications"] = selectedCloseApplications.ToArray();

        try
        {
            string path = currentModeId.HasValue ? "/modes/" + currentModeId.Value : "/modes";
            Request(path, currentModeId.HasValue ? "PUT" : "POST", payload);
            LoadModes();
            ClearEditor();
            MessageBox.Show("Modo salvo. Selecione-o na lista e clique em Testar.", "Jarvis - Modos", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível salvar o modo.", exception);
        }
    }

    private void TestMode(object sender, EventArgs eventArgs)
    {
        if (!currentModeId.HasValue)
        {
            MessageBox.Show("Salve e selecione o modo antes de testar.", "Jarvis - Modos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(Request("/modes/" + currentModeId.Value + "/test", "POST", new Dictionary<string, object>()));
            bool success = ToBoolean(result.ContainsKey("success") ? result["success"] : false);
            ArrayList steps = result.ContainsKey("steps") ? result["steps"] as ArrayList : null;
            string message = success ? "Modo executado. As ações de fechar e abrir foram concluídas." : "O modo terminou com falha. Confira os aplicativos configurados.";
            if (steps != null)
            {
                message += "\nEtapas executadas: " + steps.Count + ".";
            }
            MessageBox.Show(message, "Teste do modo", MessageBoxButtons.OK, success ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }
        catch (Exception exception)
        {
            ShowError("O teste do modo não foi executado.", exception);
        }
    }

    private void DeleteMode(object sender, EventArgs eventArgs)
    {
        if (!currentModeId.HasValue)
        {
            MessageBox.Show("Selecione um modo para excluir.", "Jarvis - Modos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (MessageBox.Show("Excluir o modo selecionado?", "Jarvis - Modos", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
        {
            return;
        }

        try
        {
            Request("/modes/" + currentModeId.Value, "DELETE", new Dictionary<string, object>());
            LoadModes();
            ClearEditor();
        }
        catch (Exception exception)
        {
            ShowError("Não foi possível excluir o modo.", exception);
        }
    }

    private void ClearEditor()
    {
        currentModeId = null;
        editorLabel.Text = "Novo modo";
        nameInput.Clear();
        slugInput.Clear();
        enabledCheckbox.Checked = true;
        for (int index = 0; index < openApplicationChoices.Items.Count; index++)
        {
            openApplicationChoices.SetItemChecked(index, false);
            closeApplicationChoices.SetItemChecked(index, false);
        }
        modeList.SelectedItems.Clear();
    }

    private void OpenApplicationItemCheck(object sender, ItemCheckEventArgs eventArgs)
    {
        if (eventArgs.NewValue == CheckState.Checked)
        {
            BeginInvoke((MethodInvoker)delegate { closeApplicationChoices.SetItemChecked(eventArgs.Index, false); });
        }
    }

    private void CloseApplicationItemCheck(object sender, ItemCheckEventArgs eventArgs)
    {
        if (eventArgs.NewValue == CheckState.Checked)
        {
            BeginInvoke((MethodInvoker)delegate { openApplicationChoices.SetItemChecked(eventArgs.Index, false); });
        }
    }

    private string Request(string path, string method, object payload)
    {
        try
        {
            using (WebClient client = NewWebClient())
            {
                if (method == "GET")
                {
                    return client.DownloadString(ApiBaseUrl + path);
                }
                return client.UploadString(ApiBaseUrl + path, method, serializer.Serialize(payload ?? new Dictionary<string, object>()));
            }
        }
        catch (WebException exception)
        {
            throw new InvalidOperationException(ReadApiError(exception), exception);
        }
    }

    private static WebClient NewWebClient()
    {
        WebClient client = new WebClient();
        client.Encoding = Encoding.UTF8;
        client.Headers[HttpRequestHeader.ContentType] = "application/json; charset=utf-8";
        return client;
    }

    private string ReadApiError(WebException exception)
    {
        if (exception.Response == null)
        {
            return exception.Message;
        }
        try
        {
            using (StreamReader reader = new StreamReader(exception.Response.GetResponseStream(), Encoding.UTF8))
            {
                Dictionary<string, object> error = serializer.Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
                return error.ContainsKey("detail") ? Convert.ToString(error["detail"]) : exception.Message;
            }
        }
        catch
        {
            return exception.Message;
        }
    }

    private static Dictionary<string, object> ToDictionary(object value)
    {
        return value as Dictionary<string, object> ?? new Dictionary<string, object>();
    }

    private static string Value(Dictionary<string, object> values, string key)
    {
        return values.ContainsKey(key) && values[key] != null ? Convert.ToString(values[key]) : String.Empty;
    }

    private static bool ToBoolean(object value)
    {
        if (value is bool)
        {
            return (bool)value;
        }
        return Convert.ToString(value) == "1" || Convert.ToString(value).Equals("true", StringComparison.OrdinalIgnoreCase);
    }

    private static string[] ToStringArray(object value)
    {
        ArrayList values = value as ArrayList;
        if (values == null)
        {
            return new string[0];
        }
        List<string> result = new List<string>();
        foreach (object entry in values)
        {
            result.Add(Convert.ToString(entry));
        }
        return result.ToArray();
    }

    private static void ShowError(string prefix, Exception exception)
    {
        MessageBox.Show(prefix + "\n\n" + exception.Message, "Jarvis - Modos", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
