# Atalho oficial do Jarvis para iPhone

O QR **Conectar Jarvis** já abre o painel local e configura o token no navegador do iPhone. O atalho compartilhado é uma camada opcional para Siri, Tela de Início e Automações.

## Publicação única pelo proprietário

1. No app Atalhos, crie `Jarvis`. Quando receber texto JSON com `jarvis=setup`, ele deve salvar `url` e `token` em um arquivo privado do Atalhos no iCloud Drive.
2. Sem entrada de configuração, o atalho lê esses valores, consulta `/bridge/v1/modes` e executa `/bridge/v1/modes/{modo}/run` com o token Bearer do dispositivo.
3. Adicione perguntas de importação como alternativa: `Onde está seu Jarvis?` e `Token do dispositivo`.
4. Compartilhe o atalho por link do iCloud.
5. Defina esse link como `JARVIS_IOS_SHORTCUT_URL` no `.env` da instalação.

Depois disso, o painel de pareamento mostra **1. Instalar atalho** e **2. Configurar automaticamente**. O segundo botão envia nome, porta e token diretamente ao atalho já instalado, sem editar IP manualmente. O iOS sempre exige que a pessoa confirme `Adicionar Atalho`; essa etapa não pode ser silenciosa.

Não publique tokens, IPs, nomes pessoais ou dados de uma instalação dentro do atalho compartilhado. Use perguntas de importação para todos os campos locais.
